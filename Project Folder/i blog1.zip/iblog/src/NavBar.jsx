import React, { useState, useEffect } from 'react'
import { Navigate, NavLink } from 'react-router-dom'
// import * as React from 'react';
import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import axios from 'axios';
import { BaseUrl } from './Baseurl';
import { useNavigate } from 'react-router-dom';

const NavBar = () => {
   
  const Navigate = useNavigate();

  const [student, setStudent] = useState([])
   

  const studentData = async () => {
      const res = await axios.get(`${BaseUrl}/blog/blogCount`)
      .then((r) => {
           console.log(r.data.data)
           setStudent(r.data.data)
      }).catch((error) => {
          console.log(error)
      })
     
  }
  
  useEffect(() => {
      studentData()
  }, []);


const onLogout = ()=>{
  console.log("CLICK");
  localStorage.removeItem("token");
  Navigate("/login");
}



  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };



  return (
    <>
      <div className='container-fluid nav_bg'>
        <div className='row m-0'>
          <div className='col-10 mx-auto'>
            <nav className="navbar navbar-expand-lg navbar-light p-2">
              <NavLink className="navbar-brand" to="/"><img className='nav_logo' src='/images/png-transparent.png' /></NavLink>
              <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span className="navbar-toggler-icon"></span>
              </button>

              <div className="collapse navbar-collapse" id="navbarSupportedContent">
                <ul className="navbar-nav ml-auto mb-2 mb-lg-0">
                  <li className="nav-item active">
                    <NavLink className="nav-link" to="/blog"><button className='btn btn-outline-primary'>Blog</button></NavLink>
                  </li>
                  <li>
                    {/* <NavLink to='/data'><button>hello</button></NavLink> */}
                  </li>
                  <li className="nav-item active">

                    <div>
                      <Button
                        id="basic-button"
                        aria-controls={open ? 'basic-menu' : undefined}
                        aria-haspopup="true"
                        aria-expanded={open ? 'true' : undefined}
                        onClick={handleClick}
                      >
                        <AccountCircleIcon className='logo' />
                      </Button>
                      <Menu
                        id="basic-menu"
                        anchorEl={anchorEl}
                        open={open}
                        onClose={handleClose}
                        MenuListProps={{
                          'aria-labelledby': 'basic-button',
                        }}
                      >
                        <NavLink to='/profile' className='profile' ><MenuItem onClick={handleClose}>Profile</MenuItem></NavLink>
                        <MenuItem onClick={onLogout}>Logout</MenuItem>
                      </Menu>
                    </div>
                  </li>
                  <li className="nav-item active">
                      <div className='navv-link'>
                         <h5>Blog: {student}</h5>
                      </div>
                  </li>
                </ul>

              </div>
            </nav>

          </div>
        </div>
      </div>
    </>
  )
}

export default NavBar