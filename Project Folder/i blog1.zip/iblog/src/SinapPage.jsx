import axios from 'axios'
import React, { useState } from 'react'
import { BaseUrl } from './Baseurl'

const SinapPage = () => {

  const [sign, setSign] = useState({
    email: '',
    username: '',
    password: '',
    gender: 'male',
    age: '',
    flied: '',
  })

  const oninput = (event) => {
    const name = event.target.name
    const value = event.target.value

    console.log(name, value)

    setSign({ ...sign, [name]: value })
  }



  const onSubmmit = async (event) => {
    event.preventDefault()
    console.log(sign)

    await axios.post(`${BaseUrl}/iblog/user/register`,sign)
      .then((res) => {
        console.log(res);
        setSign({
          email: '',
          username: '',
          password: '',
          gender: 'male',
          age: '',
          flied: '',
        })
      }).catch((erroe) => {
        console.log(erroe)
      })


  }


  return (
    <>

      <h1 className='text-center m-5'>Sign Up Page</h1>

      <div>
        <form onSubmit={onSubmmit}>
          <div className="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input type="email" className="form-control" required name='email' value={sign.email} onChange={oninput} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
          </div>
          <div className="form-group">
            <label for="exampleInputUsername1">User Name</label>
            <input type="text" className="form-control" required name='username' value={sign.username} onChange={oninput} id="exampleInputUsername1" aria-describedby="usernameHelp" placeholder="Enter User Name" />
          </div>
          <div className="form-group">
            <label for="exampleInputPassword1">Password</label>
            <input type="password" className="form-control" required name='password' value={sign.password} onChange={oninput} id="exampleInputPassword1" placeholder="Password" />
          </div>
          <div className='from-group'>
            <label>Gender</label><br />
            <select name="gender" required value={sign.email} onChange={oninput} id="cars">
              <option value="male">Male</option>
              <option value="Female">Female</option>
            </select>
          </div>
          <div className="form-group mt-3">
            <label for="exampleInputage1">Age</label>
            <input type="number" required className="form-control" name='age' value={sign.age} onChange={oninput} id="exampleInputage1" placeholder="Enter Age" />
          </div>

          <div className="form-group">
            <label for="exampleInputfild1">Fild</label>
            <input type="text" required className="form-control" name='flied' value={sign.flied} onChange={oninput} id="exampleInputfild1" placeholder="Enter Fild" />
          </div>

          <button type="submit" className="btn btn-primary mt-3">Submit</button>
        </form>
      </div>
    </>
  )
}

export default SinapPage