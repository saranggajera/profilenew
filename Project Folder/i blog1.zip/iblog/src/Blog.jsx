import React, { useEffect, useState } from 'react'
import axios from 'axios';
// import * as React from 'react';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TableRow from '@mui/material/TableRow';
import Paper from '@mui/material/Paper';
import { NavLink } from 'react-router-dom';
import { BaseUrl } from './Baseurl';

const Blog = () => {


    const [student, setStudent] = useState([])

    const studentData = async () => {
        const res = await axios.get(`${BaseUrl}/blog/blogViewAll`)
        .then((r) => {
             console.log(r.data.data)
             setStudent(r.data.data.reverse())
        }).catch((error) => {
            console.log(error)
        })
       
    }
    
    useEffect(() => {
        studentData()
    }, []);


   
    const deleteUser = async (id) =>{
        const student =  await axios.delete(`${BaseUrl}/blog/blogDeleteById/${id}`).then((res)=>{
          console.log(res)
          studentData();
        }).catch((err)=>{
          console.log(err)
        })
     
    }


  return (
   <>
   <div><NavLink to="/blogs"><button className='add_btn  btn btn-outline-primary my-3'>Add iBlog</button></NavLink></div>
    <TableContainer component={Paper}>
      <Table sx={{ minWidth: 650 }} aria-label="simple table">
        <TableHead>
          <TableRow>
            <TableCell>Title</TableCell>
            <TableCell align="right">Category</TableCell>
            <TableCell align="right">View</TableCell>
            <TableCell align="right">Edit</TableCell>
            <TableCell align="right">Delete</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {student.map((row,ind) => (
            <TableRow
              key={ind}
              sx={{ '&:last-child td, &:last-child th': { border: 0 } }}
            >
              <TableCell component="th" scope="row">
                {row.title}
              </TableCell>
              <TableCell align="right">{row.category}</TableCell>
              <TableCell align="right"><NavLink to={`/users/${row._id}`}><button className='btn btn-outline-primary'>View</button></NavLink></TableCell>
              <TableCell align="right"><NavLink to={`/user/${row._id}`}><button className='btn btn-outline-info'>Edit</button></NavLink></TableCell>
              <TableCell align="right"><button className='btn btn-outline-dark' onClick={() => deleteUser(row._id)}>Delete</button></TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>

   </>
  )
}

export default Blog