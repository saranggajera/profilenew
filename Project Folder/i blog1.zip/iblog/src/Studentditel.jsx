import React, { useEffect,useState } from 'react'
import axios from 'axios'
import {useParams } from 'react-router-dom'
import { BaseUrl } from './Baseurl'

const Studentditel = () => {

  // const { id } = useParams()
  //   console.log("heloooooo",id)

  //   const [student, setStudent] = useState([])

  //   const studentData = async (id) => {
  //       const res = await axios.get(`${BaseUrl}/blog/blogViewById/${id}`)
  //           .then((r) => {
  //               console.log(r.data.info)
  //               setStudent(r.data.info)

  //           }).catch((error) => {
  //               console.log(error)
  //           })

  //   }

  //   useEffect(() => {
  //       studentData(id)
  //   }, []);

  const { id } = useParams()
  console.log("heloooooo",id)

  const [data, setData] = useState([]);

  const alldata = async (id) => {
    const res = await axios.get(`${BaseUrl}/blog/blogViewById/${id}`)
    .then((e) => {
      setData(e.data.info)
         console.log("helllllllllllo",e.data.info)
    })
    .then((error) => {
      console.log(error)
    })
  }

  useEffect(() => {
    alldata(id)
  }, [])




  return (
    <>


            {/* <div className="card border-success mb-3" style={{maxWidth:'50rem'}}>
                <div className="card-header bg-transparent border-success">Title: {student.title}</div>
                <div className="card-footer bg-transparent border-success">Category: {student.category}</div>
            </div> */}
        
    
      <div className='container'>
      <h1 className='title text-center'></h1>
      <div className='d-flex justify-content-between my-4'>
        <div><h4>Category: {data.category}</h4></div>
        <div><h4>Date: {data.date}</h4></div>
      </div>
      <h2 className='author'>Author: {data.author}</h2>
       <img className='img_div' src='/images/domenico-loia-hGV2TfOh0ns-unsplash.jpg' alt='images'/>
       <h2 className='Description text-center text-capitalize text-break'>Description: {data.description}</h2>
      </div>
   
    </>
  )
}

export default Studentditel