import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useParams } from 'react-router-dom'
import { BaseUrl } from './Baseurl'
// import { isValidDateValue } from '@testing-library/user-event/dist/utils'

const Editblog = () => {

    const {id} = useParams()
    console.log(id)

    const [student, setStudent] = useState({
        title: '',
        description: '',
        author: '',
        date: '',
        category: '',
    })

    const studentData = async (id) => {
        const res = await axios.get(`${BaseUrl}/blog/blogViewById/${id}`)
        .then((r) => {
            console.log(r.data.info)
            setStudent(r.data.info)
        }).catch((error) => {
            console.log(error)
        })
    }
    
    useEffect(() => {
        studentData(id)
    }, []);



    
    
      const Inputeve = (event) => {
        const name = event.target.name
        const value = event.target.value
    
        console.log(name, value);
        setStudent({ ...student, [name]: value })
      }
    
      const onSubmit = async (event) => {
        event.preventDefault()
    
    
        await axios.patch(`${BaseUrl}/blog/blogUpdates/${id}`, student)
          .then((res) => {
            console.log(res)
            
            setStudent({
              title: '',
              description: '',
              author: '',
              date: '',
              category: '',
            })
          })
          .catch((error) => {
            console.log(error)
          })

         
      }



  return (
    <>
<form onSubmit={onSubmit}>
        <div className="form-group">
          <label for="exampleInputTitle1">Title</label>
          <input type="text" required className="form-control" name='title' value={student.title} onChange={Inputeve} id="exampleInputTitle1" aria-describedby="titleHelp" placeholder="Enter Titlt" />
        </div>
        <div className="form-group">
          <label for="exampleInputDescription1">Description</label>
          <input type="text" required className="form-control" name='description' value={student.description} onChange={Inputeve} id="exampleInputDescription1" placeholder="Enter Description" />
        </div>
        <div className="form-group">
          <label for="exampleInputAuthor1">Author</label>
          <input type="text" required className="form-control" name='author' value={student.author} onChange={Inputeve} id="exampleInputAuthor1" placeholder="Enter Author" />
        </div>
        <div className="form-group">
          <label for="date">Date</label><br />
          <input type="date" required id="date" name="date" value={student.date} onChange={Inputeve} />
        </div>
        <div className="form-group">
          <label for="exampleInputCategory1">Category</label>
          <input type="text" required className="form-control" name='category' value={student.category} onChange={Inputeve} id="exampleInputCategory1" placeholder="Enter Category" />
        </div>
        <button type="submit" className="btn btn-primary">Submit</button>
      </form>
    </>
  )
}

export default Editblog