import React, { useState } from 'react'
import { NavLink } from 'react-router-dom'
import { BaseUrl } from './Baseurl'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const Login = () => {
  let navigate = useNavigate();
 
  const [login, setlogin] = useState({
    email:'',
    password:'',
  })


  const loginInput = (event) => {
    const name = event.target.name
    const value = event.target.value

    console.log(name, value)

    setlogin({ ...login, [name]: value })
  }

 const onSub = async (event) => {
  event.preventDefault()
    console.log(login)

     await axios.post(`${BaseUrl}/user/userLogin`,login)
     .then((res) => {
        console.log("hello",res.data) 
        navigate("/") 
        if (res.data.status === 200){
          localStorage.setItem("token",res.data.token);
          // setWidth(false)
        }
        
        setlogin({
          email:'',
          password:'',
        })
     })
     .catch((error) => {
        console.log(error)
     })
 }


  return (
    <>
        <div className='login_page'>
        <div className='main_div'>
            <div className='logo_div'>
               <NavLink to='/login'>
               <img src='/images/blogger-logo.png' alt='images'/>
               </NavLink>
            </div>
            <NavLink to='/sinaap'><div className='btn_sing'><button>Sign Up</button></div></NavLink>
        </div>
        <div className='login'>
          <div className='images_divv'>
            <img src='/images/domenico-loia-hGV2TfOh0ns-unsplash.jpg' alt='images' />
          </div>
          <div className='form_div'>
          <div className='text-center mb-5'><h1>Login</h1></div>
          <form onSubmit={onSub}>
            <div>
              <input type="email" id="email" name="email" onChange={loginInput} value={login.email} placeholder='Enter Email' required />
            </div>
            
            <div className='pass'>
              <input type="password" id="password" name="password" onChange={loginInput} value={login.password} placeholder='Enter Password' />
            </div>
            <div className='text-center submit_btn'><button type='submit'>Submit</button></div>
          </form>
          </div>
        </div>
      </div>
    </>
  )
}

export default Login