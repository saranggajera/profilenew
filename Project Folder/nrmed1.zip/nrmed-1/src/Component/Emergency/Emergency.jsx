import React from 'react'
import './emergency.css'
import PhoneInTalkIcon from '@mui/icons-material/PhoneInTalk';
import { NavLink } from 'react-router-dom';

const Emergency = () => {
  return (
    <div className='emergency'>
        <div className='container-fluid'>
             <div className='row'>
                <div className='col-lg-6 col-md-12 col-sm-12 p-0'>
                    <div className='heart_photo'>
                      <div className='here_div'>
                      <h6 className='are_title'>We are here for you</h6>
                      <h1 className='text_book my-3'>Book Appointment</h1>
                      <NavLink to='/appoinment'><button className='book_aappoint mt-3'>Book Appointment</button></NavLink>
                      </div>
                    </div>
                </div>
                <div className='col-lg-6 col-md-12 col-sm-12 p-0'>
                  <div className='docoter_divv'>
                       <div>
                          <PhoneInTalkIcon className='icon_phone' sx={{ fontSize: 120 }}/>
                       </div>
                       <div>
                          <h5 className='emergency_div'>Emergency Medical Care</h5>
                          <a href="tel:+1-465 4545" className='phone_div'>+1-465 4545</a>
                       </div>
                  </div>
                </div>
             </div>
        </div>
    </div>
  )
}

export default Emergency