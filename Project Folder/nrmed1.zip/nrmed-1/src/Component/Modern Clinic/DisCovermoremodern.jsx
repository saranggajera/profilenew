import React from 'react'

const DisCovermoremodern = () => {
  return (
    <div className='container'>
        <div className='row'>
           <div className='col-md-6 col-sm-6'>
            <div className='color_div'> </div>
            <img className='imag_modern' src='/images/istockphoto-1189304032-612x612.jpg' alt='images'/>
           
           </div>
           <div className='modern_div col-md-6 col-sm-6'>
               <h1 className='welcom_div'>Welcome to <br/>
                  <span className='clinic_div'>Modern Clinic.</span>
               </h1>
               <p className='my-4'>
               Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veni.
               </p>
               <div>
                    <p><span className='right_icon'>✓</span>Lorem ipsum dolor sit amet</p>
                    <p><span className='right_icon'>✓</span>Consectetur adipisicing elit, sed do</p>
                    <p><span className='right_icon'>✓</span>Eiusmod tempor incididunt ut labore</p>
               </div>
               <button className='mt-4 btn_about'>About Us</button>
           </div>
        </div>
    </div>
  )
}

export default DisCovermoremodern