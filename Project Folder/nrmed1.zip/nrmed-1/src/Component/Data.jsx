import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';

export const data = [
   {
      images: "/images/tooth.png",
      title: "Dentistry",
      link: "/doctor"
   },
   {
      images: "/images/heart.png",
      title: "Cardiology",
      link: "/cardiology"
   },
   {
      images: "/images/ear.png",
      title: "ENT Specialists",
      link: "/specialists"
   },
   {
      images: "/images/joint.png",
      title: "Astrology",
      link: "/astrology"
   },
   {
      images: "/images/lungs.png",
      title: "Neuroanatomy",
      link: "/neuroanatomy"
   },
   {
      images: "/images/virus.png",
      title: "Blood Screening",
      link: "/screening"
   },
];

export const moreData = [
   {
      images: "/images/toothh.png",
      title: "Dentistry",
      links: "/doctorr"
   },
   {
      images: "/images/heartt.png",
      title: "Cardiology",
      links: "/cardiologyy"
   },
   {
      images: "/images/earr.png",
      title: "ENT Specialists",
      links: "/specialistss"
   },
   {
      images: "/images/arthritiss.png",
      title: "Astrology",
      links: "/astrologyy"
   },
   {
      images: "/images/lungss.png",
      title: "Neuroanatomy",
      links: "/neuroanatomyy"
   },
   {
      images: "/images/viruss.png",
      title: "Blood Screening",
      links: "/screeningg"
   },
];

export const ourData = [
   {
      image: "/images/DSC_6086.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      image: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      image: "/images/mature-doctor-hospital_256588-179.webp",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
];


export const Quality = [
   {
      image: "/images/doctor-1.png",
      title: "Health Consultation",
      text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt."
   },
   {
      image: "/images/doctor-2.png",
      title: "Find Health",
      text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt."
   },
   {
      image: "/images/doctor-3.png",
      title: "Search Deoctor",
      text: "Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt."
   },
]


export const dentist = [
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },{
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
   {
      img: "/images/istockphoto-1327024466-170667a.jpg",
      title:"Jhon Smith",
      text:"Dentist",
      icon: <FacebookIcon/>,
      iconn: <LinkedInIcon/>,
      icoon: <TwitterIcon/>
   },
]