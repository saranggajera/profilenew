import React, { useEffect, useState } from 'react'
import Navbar from '../NavBar-1/Naavbar'
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';
import Footer from "../Footer/Footer"
import './doctoer.css'
import axios from 'axios';
import { BaseUrl } from '../BaseUrl';

const Docoter = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  const [data,setData]= useState("Dentistry")

  const [store, setStore] = useState([])

  const postdata = async()=>{
    const body={
      speacilization:data
    }
   await axios.post(`${BaseUrl}/doctor/doctorByspecialization`,body).then((res)=>{
      console.log("resssss",res.data.data)
      // setData(res)
      setStore(res.data.data)
    }).catch((err)=>{
      console.log(err)
    })
  }

  useEffect(()=>{
    postdata()
  },[])

  return (
    <div className='docoter'>
      <Navbar />
      <h5>{}</h5>
      <div className='container'>
        <div className='row my-4'>
          {
            store.map((val, ind) => {
              return (
                <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                  <div className='doco_div'>
                    <div className='halo'>
                      <div className='img_docooer'>
                        <img src='/images/istockphoto-1327024466-170667a.jpg' alt='images' />
                      </div>
                      <div className='titlle_name'>
                        <h2 className='titlt_div'>{val.doctorName}</h2>
                        <h5 className='text_div'>{val.speacilization}</h5>
                        <h5 className='text_div'>Phone: {val.phone}</h5>
                        <div className='hr_lline my-2'></div>
                        <div className='icon_div'>
                          <div className='icon'>
                            <a href='https://www.facebook.com/campaign/landing.php?campaign_id=14884913640&extra_1=s%7Cc%7C589460569900%7Ce%7Cfacebook%20login%7C&placement=&creative=589460569900&keyword=facebook%20login&partner_id=googlesem&extra_2=campaignid%3D14884913640%26adgroupid%3D128696221912%26matchtype%3De%26network%3Dg%26source%3Dnotmobile%26search_or_content%3Ds%26device%3Dc%26devicemodel%3D%26adposition%3D%26target%3D%26targetid%3Dkwd-1409285535%26loc_physical_ms%3D9062198%26loc_interest_ms%3D%26feeditemid%3D%26param1%3D%26param2%3D&gclid=Cj0KCQjwxIOXBhCrARIsAL1QFCY7QShqL3XhHrTe0HuQ5ETBvrRW9BM-9huieFt0q1pOAPXXwLlePQ8aAn_IEALw_wcB' target="_blank"><FacebookIcon/></a>
                          </div>
                          <div className='icon mx-5'>
                            <a href='https://www.linkedin.com/login' target="_blank"><LinkedInIcon/></a>
                          </div>
                          <div className='icon'>
                            <a href='https://twitter.com/i/flow/login' target="_blank"><TwitterIcon/></a>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
      <Footer/>
    </div>

  )
}

export default Docoter