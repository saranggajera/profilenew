import React, { useEffect, useState } from 'react'
import Footer from '../Footer/Footer'
import Naavbar from '../NavBar-1/Naavbar'
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';
import axios from 'axios';
import { BaseUrl } from '../BaseUrl';

const Astrology = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  const [astrology, setAstrology] = useState("Astrology")

  const [astrolstore, setAstrolstore] = useState([])

  const astrologyData = async () => {
    const body = {
      speacilization: astrology
    }
    await axios.post(`${BaseUrl}/doctor/doctorByspecialization`, body)
      .then((res) => {
        console.log(res.data.data);
        setAstrolstore(res.data.data)
      })
      .catch((error) => {
        console.log(error);
      })
  }

  useEffect(() => {
    astrologyData()
  })

  return (
    <div className='astrology'>
      <Naavbar />
      <div className='container'>
        <div className='row my-4'>
          {
            astrolstore.map((eve, ind) => {
              return (
                <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                  <div className='astrol_divv'>
                    <div className='astrology_img'>
                      <img src='/images/istockphoto-1327024466-170667a.jpg' alt='images' />
                    </div>
                    <div className='astrology_maindivv'>
                      <h1 className='doctor_namme'>{eve.doctorName}</h1>
                      <h5>{eve.speacilization}</h5>
                      <h5>Phone: {eve.phone}</h5>
                      <hr className='diiv_line my-2' />
                      <div>
                        <FacebookIcon className='fase_icon' />
                        <LinkedInIcon className='mx-5 fase_icon' />
                        <TwitterIcon className='fase_icon' />
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
      <Footer/>
    </div>
  )
}

export default Astrology