import React, { useEffect, useState } from 'react'
import Naavbar from '../NavBar-1/Naavbar'
import FacebookIcon from '@mui/icons-material/Facebook';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import TwitterIcon from '@mui/icons-material/Twitter';
import axios from 'axios';
import { BaseUrl } from '../BaseUrl';
import Footer from '../Footer/Footer';

const Cardiology = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  const [cardiology, setCardiology] = useState("Cardiology")

  const [carstore, setCarstore] = useState([])

  const PostCardiology = async () => {
    const body = {
      speacilization: cardiology
    }
    await axios.post(`${BaseUrl}/doctor/doctorByspecialization`, body)
      .then((res) => {
        console.log(res.data.data)
        setCarstore(res.data.data)
      })
      .catch((error) => {
        console.log(error)
      })
  }
  useEffect(() => {
    PostCardiology()
  }, [])



  return (
    <div className='cardiology'>
      <Naavbar />
      <div className='container'>
        <div className='row my-5'>
          {
            carstore.map((val, ind) => {
              return (
                <div key={ind} className='col-lg-4 col-md-6 col-sm-12 mx-auto'>
                  <div className='cardiology_mandivv'>
                    <div className='divv_iimgs'>
                      <img src='/images/istockphoto-1327024466-170667a.jpg' alt='images' />
                    </div>
                    <div className='content_divv'>
                      <h1 className='cardiology_namee'>{val.doctorName}</h1>
                      <h5>{val.speacilization}</h5>
                      <h5>Phone: {val.phone}</h5>
                      <hr className='linne_div my-2' />
                      <div className='socily_icon'>
                        <FacebookIcon className='iconn' />
                        <LinkedInIcon className='mx-5 iconn' />
                        <TwitterIcon className='iconn' />
                      </div>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
      <Footer />
    </div>
  )
}

export default Cardiology