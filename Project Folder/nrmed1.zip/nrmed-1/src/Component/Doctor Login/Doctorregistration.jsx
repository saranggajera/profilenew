import axios from 'axios'
import React, { useState } from 'react'
import { BaseUrl } from '../BaseUrl'
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const Doctorregistration = () => {

    const Navigate = useNavigate()

    const [doctorr, setdoctorr] = useState({
        doctorName: "",
        phone: "",
        email: "",
        password: "",
        qualification: "",
        speacilization: "",
        zipCode: ""
    })

    const ondoctor = (event) => {
        const name = event.target.name
        const value = event.target.value

        // console.log(name, value)

        setdoctorr({ ...doctorr, [name]: value })
    }

    const onsubmitt = async (event) => {
        event.preventDefault()
        console.log(doctorr)

        await axios.post(`${BaseUrl}/doctor/doctorRegistration`, doctorr)
            .then((e) => {
                console.log("hellggggggggggggggggggggggggggggggggggggggggggg",e.data.status)
                
                if(e.data.status === 201){
					localStorage.setItem("Signup_id", e.data.data._id)
					toast.success("Signup Successfully", {
                        position:"top-right"
                    })
				}
                setdoctorr({
                    doctorName: "",
                    phone: "",
                    email: "",
                    password: "",
                    qualification: "",
                    speacilization: "",
                    zipCode: ""
                })
            })
            Navigate("/")
            .catch((error) => {
                console.log(error)
            })
    }

    const [passwordShown, setPasswordShown] = useState(false);
    const togglePassword = () => {
        setPasswordShown(!passwordShown);
    };

    return (
        <div className='doctorregistration'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12 '>
                        <div className='signup_divv'>
                            <form onSubmit={onsubmitt}>
                                <div className="form-group">
                                    <label className="lable_div" for="exampleInputDoctorName1">DoctorName</label>
                                    <input type="text" className="form-control"  name="doctorName" value={doctorr.doctorName} onChange={ondoctor} id="exampleInputDoctorName1" aria-describedby="DoctorNameHelp" placeholder="Enter DoctorName" />
                                </div>
                                <div className="form-group">
                                    <label className="lable_div" for="exampleInputPhone1">Phone  Number</label>
                                    <input type="tel"
                                        onKeyPress={(event) => {
                                            if (!/[0-9]/.test(event.key)) {
                                                event.preventDefault();
                                            }
                                        }}
                                        maxLength="10" minLength="10"
                                        className="form-control" name="phone" value={doctorr.phone}  onChange={ondoctor} id="exampleInputPhone1" aria-describedby="PhoneHelp" placeholder="Enter Phone Number" />
                                </div>
                                <div className="form-group">
                                    <label className="lable_div" for="exampleInputEmail1">email</label>
                                    <input type="email" className="form-control"  name="email" value={doctorr.email} onChange={ondoctor} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                </div>
                                <div className="form-group">
                                    <label className="lable_div" for="exampleInputPassword1">Password</label>
                                    <input type={passwordShown ? "text" : "password"} class="form-control"  name="password" value={doctorr.password} onChange={ondoctor} id="exampleInputPassword1" placeholder="Password" />
                                    <i className='Pass_bitton' onClick={togglePassword}>{passwordShown ? <VisibilityOffIcon /> : <VisibilityIcon />}</i>
                                    {/* <button  onClick={togglePassword}>{passwordShown ? <VisibilityOffIcon /> : <VisibilityIcon />}</button> */}
                                </div>
                                <div className="form-group">
                                    <label className="lable_div" for="exampleInputQualification1">Qualification</label>
                                    <input type="text" className="form-control"  name="qualification" value={doctorr.qualification} onChange={ondoctor} id="exampleInputQualification1" placeholder="Qualification" />
                                </div>
                                <div className="form-group">
                                    <label className="lable_div" for="exampleInputSpeacilization1">Speacilization</label>
                                    {/* <input type="Speacilization" class="form-control" name="speacilization"  value={doctorr.speacilization} onChange={ondoctor} id="exampleInputSpeacilization1" placeholder="Speacilization" /> */}
                                    <select className="form-select form-select-lg"  name="speacilization" value={doctorr.speacilization} onChange={ondoctor} aria-label=".form-select-lg example" style={{ outline: "none", width: "100%", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }}>
                                        <option selected>Select Speacilization</option>
                                        <option value="Dentistry">Dentistry</option>
                                        <option value="Cardiology">Cardiology</option>
                                        <option value="ENT Specialists">ENT Specialists</option>
                                        <option value="Astrology">Astrology</option>
                                        <option value="Neuroanatomy">Neuroanatomy</option>
                                        <option value="Blood Screening">Blood Screening</option>
                                    </select>
                                </div>
                                <div className="form-group">
                                    <label className="lable_div" for="exampleInputzipCode1">zipCode</label>
                                    <input type="tel"
                                    
                                        onKeyPress={(event) => {
                                            if (!/[0-9]/.test(event.key)) {
                                                event.preventDefault();
                                            }
                                        }}
                                        maxLength="6" minLength="4"
                                        className="form-control" name="zipCode" value={doctorr.zipCode} onChange={ondoctor} id="exampleInputzipCode1" placeholder="ZipCode" />
                                </div>
                                <button type="submit" className="btn_doco">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Doctorregistration