import React, { useEffect, useState } from 'react'
import './navbar.css'
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import axios from 'axios';
import { BaseUrl } from '../BaseUrl';
import { NavLink, useNavigate } from 'react-router-dom'
// import Button from '@mui/material/Button';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import Backdrop from '@mui/material/Backdrop';
// import Box from '@mui/material/Box';
// import Modal from '@mui/material/Modal';
import Fade from '@mui/material/Fade';
// import Button from '@mui/material/Button';
// import Typography from '@mui/material/Typography';


const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

const Navbar = () => {

    useEffect(() => {
        window.scrollTo({ top: 0, left: 0, });
    }, []);

    var z = localStorage.getItem("Signup_id")

    console.log("aaaaaaaaaaaaaaasssss", z);
    
    const [oppen, setOppen] = React.useState(false);

    const [doctorget, setDoctorget] = useState([])


    const hanndleClose = () => setOppen(false);

    var x = localStorage.getItem("accessToken");
    console.log("hhhhhhhhhhhhhhhhhhhhhhh",x);


    const Navigate = useNavigate()

    const haandleClose = () => {
        localStorage.removeItem("Signup_id")
        localStorage.removeItem("accessToken")
        Navigate("/")
    }

    const [anchorEl, setAnchorEl] = React.useState(null);
    const oopen = Boolean(anchorEl);
    const handleClick = (event) => {
        setAnchorEl(event.currentTarget);
    };
    const hhandleClose = () => {
        setAnchorEl(null);
    };

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);


    const [appoinment, setappoinment] = useState({
        patientName: "",
        doctorName: "",
        patientAddress: "",
        patientNumber: "",
        patientEmail: "",
        deases: "",
        ambulance: "",
        date: "",
        book: "",
        city: "",
        state: "",
        country: "India"
    })

    const onappoi = (event) => {
        const name = event.target.name
        const value = event.target.value

        // console.log(name, value)

        setappoinment({ ...appoinment, [name]: value })
    }


    const onsubapp = async (event) => {
        event.preventDefault()
        console.log(appoinment)

        await axios.post(`${BaseUrl}/appoinment/appoinmentInsert`, appoinment)
            .then((e) => {
                console.log("hello Appoinment", e)
                setappoinment({
                    patientName: "",
                    doctorName: "",
                    patientAddress: "", 
                    patientNumber: "",
                    patientEmail: "",
                    deases: "",
                    ambulance: "",
                    date: "",
                    book: "",
                    city: "",
                    state: "",
                    country: "India"
                })
            })
            .catch((error) => {
                console.log(error)
            })
    }





    // <------------------------state---------------------------------->

    const [state, setState] = useState([])
    const arr = []
    const stateData = async () => {
        const res = await axios.get(`${BaseUrl}/stateCities/stateCitiesViewAll`)
            .then((r) => {
                setState(r.data.data)
                console.log("hello stateData", r.data.data)
            })
            .catch((error) => {
                console.log(error)
            })
    }

    useEffect(() => {
        stateData()
    }, [])


    // <------------------------country---------------------------------->

    const [country, setCountry] = useState([])


    const countryData = async () => {
        const res = await axios.get(`${BaseUrl}/country/countryViewAll`)
            .then((r) => {
                setCountry(r.data.data)
                console.log("hello countryData", r.data.data)
            })
            .catch((error) => {
                console.log(error)
            })
    }

    useEffect(() => {
        countryData()
    }, [])


    //-----------------------------------doctorData-------------------------------------

    const [doctornamee, setDoctornamee] = useState([])

    const doctorData = async () => {
        const res = await axios.get(`${BaseUrl}/doctor/viewAll`)
            .then((res) => {
                console.log("hello", res.data.data)
                setDoctornamee(res.data.data)
            })
            .catch((error) => {
                console.log(error)
            })
    }

    useEffect(() => {
        doctorData()
    }, [])





    const [togg, setTogg] = useState(true)

    const editTogg = () => {
        setTogg(!togg)
    }


    const [doctorVieww, setdoctorVieww] = useState({
        doctorName: "",
        doctorAddress: "",
        phone: "",
        email: "",
        yearOfField: "",
        hospitalName: "",
        speacilization: "",
    })

    const onchangeview = (event) => {
        const name = event.target.name
        const value = event.target.value

        setdoctorVieww({ ...doctorVieww, [name]: value })
    }

    const onsubview = async (event) => {
        event.preventDefault()
        console.log(doctorVieww)


        await axios.put(`${BaseUrl}/doctor/update/${z}`, doctorVieww)
            .then((res) => {
                console.log("gggggggggggggggggggggggg", res.data.status);
                if (res.data.status === 200) {
                    hanndleOpen();
                    setTogg(true);
                }
                setdoctorVieww({
                    doctorName: "",
                    doctorAddress: "",
                    phone: "",
                    email: "",
                    yearOfField: "",
                    hospitalName: "",
                    speacilization: "",
                })
            })
            .catch((error) => {
                console.log("hellohhhhhhhhhhhhhhhhhhhhhhhhhhhhh", error);
            })
    }


    const hanndleOpen = async () => {
        setOppen(true)
        const res = await axios.get(`${BaseUrl}/doctor/viewById/${z}`)
            .then((res) => {
                console.log("helloyyyyyyyyyyyyyyyyyyyyyy", res.data.info)
                setDoctorget(res.data.info)
                setdoctorVieww(res.data.info)
            })
            .catch((error) => {
                console.log("xsjhvbdsuvbsvbswv", error)
            })
    };



    return (
        <div className=''>
            <nav className="navbar naavbar navbar-expand-lg fixed-top">
                <div className='container-fluid'>
                    <NavLink to='/' className="navbar-brand"><LocalHospitalIcon sx={{ fontSize: 40 }} />Nrmed</NavLink>
                    <button className="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                        hello
                    </button>

                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav ml-auto">
                            <li className="nav-item active">
                                <NavLink className="nav-link" to="/">Home</NavLink>
                            </li>
                            <li className="nav-item">
                                <NavLink className="nav-link" to="/about">About Us</NavLink>
                            </li>
                            <li className="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Departments
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <NavLink className="dropdown-item" to="/doctorlogin">Doctor</NavLink>
                                    <NavLink className="dropdown-item" to="/patientviewall">Doctor</NavLink>
                                    {/* <NavLink className="dropdown-item" to="/patientviewall">Patient</NavLink> */}
                                    <a className="dropdown-item" href="#">Ambulance</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <NavLink className="nav-link" to="/contact">Contact</NavLink>
                            </li>
                        </ul>
                        <div className='appoi_buttons'>
                            <Button onClick={handleOpen} className='book_appoidoctor'>Book Appoinment</Button>
                            <Modal
                                open={open}
                                onClose={handleClose}
                                aria-labelledby="modal-modal-title"
                                aria-describedby="modal-modal-description"
                            >
                                <Box sx={style}>
                                    <Typography id="modal-modal-description">
                                        <h1 className='titlee_name'><span className='book_divv'>Book an</span> <br />Appointment</h1>
                                        <div>
                                            <form onSubmit={onsubapp}>
                                                <div className='d-flex justify-content-between'>
                                                    <div className="form-group">
                                                        <label className="lable_app" for="exampleInputPatientName1">Patient Name</label>
                                                        <input type="text" className="form-control" id="exampleInputPatientName1" name="patientName" value={appoinment.patientName} onChange={onappoi} aria-describedby="PatientNameHelp" placeholder="Enter PatientName" />
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="lable_app" for="exampleInputEmail1">Patient Email</label>
                                                        <input type="email" className="form-control" id="exampleInputEmail1" name="patientEmail" value={appoinment.patientEmail} onChange={onappoi} aria-describedby="emailHelp" placeholder="Enter email" />
                                                    </div>
                                                    <div className="form-group" style={{ width: "220px" }}>
                                                        <label className="lable_app" for="exampleInputDoctorName1">Doctor Name</label>

                                                        <select className="form-select w-100" name="doctorName" required value={appoinment.doctorName} onChange={onappoi} style={{ outline: "none", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }} aria-label="Default select example">
                                                            {
                                                                doctornamee.map((val, ind) => {
                                                                    return (
                                                                        <>
                                                                            <option key={ind}>{val.doctorName}</option>
                                                                        </>
                                                                    )
                                                                })
                                                            }
                                                        </select>
                                                    </div>

                                                </div>
                                                <div className="form-group">
                                                    <label className="lable_app" for="exampleInputPatientAddress1">Patient Address</label>
                                                    <input type="text" className="form-control" id="exampleInputPatientAddress1" name="patientAddress" value={appoinment.patientAddress} onChange={onappoi} aria-describedby="PatientAddressHelp" placeholder="Enter PatientAddress" />
                                                </div>
                                                <div className='d-flex justify-content-between'>
                                                    <div className="form-group">
                                                        <label className="lable_app" for="exampleInputPatientNumber1">Patient Number</label>
                                                        <input type="number" className="form-control" id="exampleInputPatientNumber1" name="patientNumber" value={appoinment.patientNumber} onChange={onappoi} aria-describedby="PatientNumberHelp" placeholder="Enter PatientNumber" />
                                                    </div>
                                                    <div className="form-group" style={{ width: "220px" }}>
                                                        <label className="lable_app" for="exampleInputDate1">Date</label>
                                                        <input type="date" className="form-control" id="exampleInputDate1" name="date" value={appoinment.date} onChange={onappoi} aria-describedby="DateHelp" placeholder="Enter Date" />
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="lable_app" for="exampleInputAmbulance1">Ambulance</label>
                                                        <input type="number" className="form-control" id="exampleInputAmbulance1" name="ambulance" value={appoinment.ambulance} onChange={onappoi} aria-describedby="AmbulanceHelp" placeholder="Enter Ambulance" />
                                                    </div>
                                                </div>

                                                <div className='d-flex justify-content-between'>
                                                    <div className="form-group">
                                                        <label className="lable_app" for="exampleInputDeases1">Deases</label>
                                                        <input type="text" className="form-control" id="exampleInputDeases1" name="deases" value={appoinment.deases} onChange={onappoi} aria-describedby="DeasesHelp" placeholder="Enter Deases" />
                                                    </div>
                                                    <div className="form-group">
                                                        <label className="lable_app" for="exampleInputBook1">Book</label>
                                                        <input type="number" className="form-control" id="exampleInputBook1" name="book" value={appoinment.book} onChange={onappoi} aria-describedby="BookHelp" placeholder="Enter Book" />
                                                    </div>
                                                    <div className="form-group" style={{ width: "220px" }}>
                                                        <label className="lable_app" for="exampleInputState1">State</label>

                                                        <select className="form-select w-100" name="state" required value={appoinment.state} onChange={onappoi} style={{ outline: "none", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }} aria-label="Default select example">

                                                            {state.map((eve, ind) => {
                                                                if (arr.includes(eve.state)) {
                                                                    arr.push(eve.state);
                                                                } else {
                                                                    arr.push(eve.state);
                                                                    return <option key={ind}>{eve.state}</option>
                                                                }
                                                            })}

                                                        </select>
                                                    </div>
                                                </div>

                                                <div className='d-flex justify-content-between'>
                                                    <div className="form-group" style={{ width: "220px" }}>
                                                        <label className="lable_app" for="exampleInputCity1">City</label>

                                                        <select className="form-select w-100" name="city" required value={appoinment.city} onChange={onappoi} style={{ outline: "none", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }} aria-label="Default select example">
                                                            <option>select city</option>
                                                            {state.map((val, i) => {
                                                                if (val.state == appoinment.state) {

                                                                    return <option key={i}>{val.city}</option>
                                                                }
                                                            })}

                                                        </select>
                                                    </div>
                                                    <div className="form-group" style={{ width: "220px" }}>
                                                        <label className="lable_app" for="exampleInputCountry1">Country</label>

                                                        <select className="form-select w-100" name="country" required value={appoinment.country} onChange={onappoi} style={{ outline: "none", height: "40px", border: "1px solid lightgrey", 'borderRadius': '5px' }} aria-label="Default select example">
                                                            {
                                                                country.map((val, ind) => {
                                                                    return (
                                                                        <>
                                                                            <option key={ind}>{val.name}</option>
                                                                        </>
                                                                    )
                                                                })
                                                            }
                                                        </select>
                                                    </div>
                                                </div>

                                                <button type="submit" className="btn_app">Submit</button>
                                            </form>
                                        </div>
                                    </Typography>
                                </Box>
                            </Modal>
                        </div>

                        {
                            (x == null && z == null) ?
                                <div className=''><button className='btn_log'>Login</button></div>
                                :
                                <div className='ml-3'>
                                    <Button
                                        id="basic-button"
                                        aria-controls={oopen ? 'basic-menu' : undefined}
                                        aria-haspopup="true"
                                        aria-expanded={oopen ? 'true' : undefined}
                                        onClick={handleClick}
                                    >
                                        <AccountCircleIcon className='login_iconss' sx={{ fontSize: 50 }} />
                                    </Button>
                                    <Menu
                                        id="basic-menu"
                                        anchorEl={anchorEl}
                                        open={oopen}
                                        onClose={hhandleClose}
                                        MenuListProps={{
                                            'aria-labelledby': 'basic-button',
                                        }}
                                    >
                                        <MenuItem>
                                            <Button className='profile_divv' onClick={hanndleOpen}>Profile</Button>
                                            <Modal
                                                aria-labelledby="transition-modal-title"
                                                aria-describedby="transition-modal-description"
                                                open={oppen}
                                                onClose={hanndleClose}
                                                closeAfterTransition
                                                BackdropComponent={Backdrop}
                                                BackdropProps={{
                                                    timeout: 500,
                                                }}
                                            >
                                                <Fade in={oppen}>
                                                    <Box className='xyz' sx={style}>
                                                        <div className='update_btn'>
                                                            <button onClick={editTogg} className='btn btn-primary'>Edit</button>
                                                        </div>
                                                        {
                                                            togg ? (
                                                                <Typography className='hello' id="transition-modal-title" variant="h6" component="h2">
                                                                    <div className='doctor_view'>
                                                                        <div className='img_viewdoctor'>
                                                                            <img src='/images/istockphoto-1327024466-170667a.jpg' alt='images' />
                                                                            <div className='doctor_brand_name'>
                                                                                <h2><span className='view_divv'>Dr:</span> {doctorget.doctorName}</h2>
                                                                                <h4><span className='view_divv'>speacilization:</span> {doctorget.speacilization}</h4>
                                                                            </div>
                                                                        </div>
                                                                        <div>
                                                                            <h3><span className='view_divv'>Email:</span> {doctorget.email}</h3>
                                                                            <h3><span className='view_divv'>Phone:</span> {doctorget.phone}</h3>
                                                                            <h3><span className='view_divv'>DoctorAddress:</span> {doctorget.doctorAddress}</h3>
                                                                            <h3><span className='view_divv'>HospitalName:</span> {doctorget.hospitalName}</h3>
                                                                            <h3><span className='view_divv'>YearOfField:</span> {doctorget.yearOfField}</h3>
                                                                        </div>
                                                                    </div>
                                                                </Typography>
                                                            ) : (
                                                                <div>
                                                                    <form onSubmit={onsubview}>
                                                                        <div className='d-flex justify-content-between'>
                                                                            <div className="form-group">
                                                                                <label for="exampleInputdoctorName1">DoctorName</label>
                                                                                <input type="text" className="form-control" name='doctorName' value={doctorVieww.doctorName} onChange={onchangeview} id="exampleInputdoctorName1" aria-describedby="doctorNameHelp" placeholder="Enter doctorName" />
                                                                            </div>
                                                                            <div className="form-group">
                                                                                <label for="exampleInputspeacilization1">Speacilization</label>
                                                                                <input type="text" className="form-control" name='speacilization' value={doctorVieww.speacilization} onChange={onchangeview} id="exampleInputSpeacilization1" placeholder="Speacilization" />
                                                                            </div>
                                                                            <div className="form-group">
                                                                                <label for="exampleInputEmail1">Email</label>
                                                                                <input type="Email" className="form-control" name='email' value={doctorVieww.email} onChange={onchangeview} id="exampleInputEmail1" placeholder="Email" />
                                                                            </div>
                                                                        </div>
                                                                        <div className='d-flex justify-content-between'>
                                                                            <div className="form-group">
                                                                                <label for="exampleInputPhone1">Phone</label>
                                                                                <input type="tel"
                                                                                    maxLength="10"
                                                                                    minLength="10"
                                                                                    onKeyPress={(event) => {
                                                                                        if (!/[0-9]/.test(event.key)) {
                                                                                            event.preventDefault();
                                                                                        }
                                                                                    }}
                                                                                    className="form-control" name='phone' value={doctorVieww.phone} onChange={onchangeview} id="exampleInputPhone1" placeholder="Phone" />
                                                                            </div>
                                                                            <div className="form-group">
                                                                                <label for="exampleInputHospitalName1">HospitalName</label>
                                                                                <input type="text" className="form-control" name='hospitalName' value={doctorVieww.hospitalName} onChange={onchangeview} id="exampleInputHospitalName1" placeholder="HospitalName" />
                                                                            </div>
                                                                            <div className="form-group">
                                                                                <label for="exampleInputYearOfField1">YearOfField</label>
                                                                                <input type="number" className="form-control" name='yearOfField' value={doctorVieww.yearOfField} onChange={onchangeview} id="exampleInputYearOfField1" placeholder="YearOfField" />
                                                                            </div>
                                                                        </div>
                                                                        <div className="form-group">
                                                                            <label for="exampleInputDoctorAddress1">DoctorAddress</label>
                                                                            <input type="text" className="form-control" name='doctorAddress' value={doctorVieww.doctorAddress} onChange={onchangeview} id="exampleInputDoctorAddress1" placeholder="DoctorAddress" />
                                                                        </div>

                                                                        <button type="submit" className="btn btn-primary">Submit</button>
                                                                    </form>
                                                                </div>
                                                            )
                                                        }

                                                    </Box>
                                                </Fade>
                                            </Modal>
                                        </MenuItem>
                                        <MenuItem onClick={haandleClose} className="ml-2">Logout</MenuItem>
                                    </Menu>
                                </div>
                        }
                    </div>
                </div>
            </nav>
        </div>
    )
}

export default Navbar