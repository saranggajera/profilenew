import React from 'react'
import '../Navbar/navbar.css'
import LocalHospitalIcon from '@mui/icons-material/LocalHospital';
import '../home/doctoer.css'
import HomeIcon from '@mui/icons-material/Home';
import { NavLink } from 'react-router-dom';

const Naavbar = () => {
    return (
        <div>
            <nav class="navbar eexpand navbar-expand-lg">
            <div className='container'>
            <NavLink to="/" class="naavbar-brand"><HomeIcon sx={{ fontSize: 40 }} className="icon_home"/></NavLink>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mx-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#"><LocalHospitalIcon sx={{ fontSize: 40 }}/>Nrmed</a>
                    </li>
                    {/* <li class="nav-item">
                        <a class="nav-link" href="#">Link</a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Dropdown
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="#">Action</a>
                            <a class="dropdown-item" href="#">Another action</a>
                            <div class="dropdown-divider"></div>
                            <a class="dropdown-item" href="#">Something else here</a>
                        </div>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="#">Disabled</a>
                    </li> */}
                </ul>
            </div>
            </div>
        </nav>
        </div>
    )
}

export default Naavbar