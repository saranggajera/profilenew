import React, { useEffect } from 'react'
import Navbar from '../Navbar/Navbar'
import './about.css'

const About = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  return (
    <div className='about'>
       <Navbar/>
       <div className='container'>
        <div className='row'>
            <div className='col-md-12 col-sm-12'>
                <h1 className='about_divv'>About Us</h1>
            </div>
        </div>
       </div>
    </div>
  )
}

export default About