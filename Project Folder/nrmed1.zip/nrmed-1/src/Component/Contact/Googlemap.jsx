import React, { useEffect } from 'react'

const Googlemap = () => {
 
    useEffect(() => {
         const ifameData=document.getElementById("iframeId")
         const lat=21.212545;
         const lon=72.889519;

         ifameData.src=`https://maps.google.com/maps?q=${lat},${lon}&hl=es;&output=embed`
    })

  return (
    <div className='googlemap'>
        <div className='container'>
           <div className='row'>
              <div className='col-md-12 col-sm-12'>
                   <iframe id='iframeId' height="500px" width="100%"></iframe>
              </div>
           </div>
        </div>
    </div>
  )
}

export default Googlemap