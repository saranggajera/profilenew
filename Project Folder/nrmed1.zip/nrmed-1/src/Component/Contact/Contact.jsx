import React from 'react'
import Navbar from '../Navbar/Navbar'
import './contact.css'

const Contact = () => {
  return (
    <div className='contact'>
    <Navbar/>
        <div className='container'>
           <div className='row'>
               <div className='col-md-12 col-sm-12'>
                   <h1 className='contact_divv'>Contact</h1>
               </div>
           </div>
        </div>
    </div>
  )
}

export default Contact