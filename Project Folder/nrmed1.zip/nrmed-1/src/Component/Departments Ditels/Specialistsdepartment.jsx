import React, { useEffect } from 'react'
import Navbar from '../Navbar/Navbar'
import Footerdepartments from './Footerdepartments'

const Specialistsdepartment = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  return (
    <div className='specialistsdepartment'>
      <Navbar />
      <div className='container'>
        <div className='row'>
          <div className='col-md-12 col-sm-12 ear_divv'>
            {/* <img className='ear_images' src='/images/earr.png' alt='images' /> */}
            <h1 className='specialistss_divv'>ENT Specialists</h1>
          </div>
        </div>
        <div className='row mt-5'>
          <h1 className='mt-5 range'>Who is a ENT Specialists</h1>
          <p className='mt-5 ml-5'>
            Imagine a singer not being able to sing, or you not being able to hear her beautiful music. <br /><br />

            Imagine not being able to smell the earth after a spring rain, or not being able to taste and enjoy your favorite holiday meal. <br /><br />

            Imagine not being able to sleep through the night next to your loved one because they snore. <br /><br />

            These are some of the fundamental functions of life that make living so rich and wonderful. Yet when one or more of these functions no longer work the way they should, living is diminished or even jeopardized. <br /><br />

            Hearing and balance, swallowing and speech, breathing and sleep issues, allergies and sinuses, head and neck cancer, skin disorders, even facial plastic surgery are just some of the conditions that “ENT” (ear, nose, and throat) specialists treat. Professionally, ENT specialists are called “otolaryngologists” (pronounced: oh/toe/lair/in/goll/oh/jists), but it’s easier just to say “ENT.” <br /><br />

            Did you know that nearly half of patients going to primary care offices have some sort of ENT issue? <br /><br />

            Think about it. Almost everyone has had a stuffy nose, clogged ears, or sore throat, but ENT specialists treat a diverse range of conditions and disorders of the ears, nose, throat, head, and neck region—from simple to severe, for all persons, at all stages of life. <br /><br />

            ENT specialists are not only medical doctors who can treat your sinus headache, your child’s swimmer’s ear, or your dad’s sleep apnea. They are also surgeons who can perform extremely delicate operations to restore hearing of the middle ear, open blocked airways, remove head, neck, and throat cancers, and rebuild these essential structures. This requires an additional five to eight years of intensive, post-graduate training beyond medical school. <br /><br />

            Organized ENTs have been setting the treatment standards that pediatric and primary care providers have been following since 1896, making otolaryngology one of the oldest medical specialties in the United States.<br /><br /><br />
          </p>
          <h1>What is  ENT Specialists</h1>
          <p className='ml-5 mt-5'>
            Ear infections are one of the most common reasons why parents to take kids to the doctor. ENTs usually treat them with antibiotics, but if the infections keep coming back, they may recommend surgery. <br /><br />

            Tonsillitis is an infection of the tonsils. Again, doctors often treat it with antibiotics, but if it persists, they may recommend that you get your tonsils taken out. <br /><br />

            Sinus problems that last more than 4 months are called chronic sinusitis. ENTs can help get to the bottom of the issue and treat the underlying problem. <br /><br />

            Hearing loss <br /><br />

            Hearing loss is normal as you age. But sudden hearing problems can be a sign of something more serious. Either way, an otolaryngologist will be able to figure out what’s going on and help you get any treatments you need to hear better. If you need hearing aids, your ENT may send you to an audiologist to get fitted for them. <br /><br />

            A lump in your neck <br /><br />

            A lump in the neck that lasts more than 2 weeks could be a sign of mouth, throat, thyroid, or blood cancer. Cancers that start in these areas often spread to the lymph nodes in your throat first. <br /><br />

            A lump is different from swollen lymph nodes, which can also be a sign of a serious illness but often happen due to common conditions like strep throat or an ear infection. <br /><br />

            A child who is a heavy snorer <br /><br />

            Snoring is common in adults but unusual in children. It may not be a sign of a serious problem, but it's best to talk to your pediatrician about whether they recommend seeing an ENT. It may be a sign of sleep apnea, which can lead to a problem with bones in the face, or bedwetting. <br /><br />
          </p>
        </div>
      </div>
      <Footerdepartments/>
    </div>
  )
}

export default Specialistsdepartment