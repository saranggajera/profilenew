import React, { useEffect } from 'react'
import Navbar from '../Navbar/Navbar'
import Footerdepartments from './Footerdepartments'

const Astrologydepartment = () => {

    useEffect(() => {
        window.scrollTo({top: 0, left: 0,});
      }, []);

    return (
        <div className='astrologydepartment'>
            <Navbar />
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12 lungs_divv'>
                        {/* <img className='joint_imag' src='/images/arthritiss.png' alt='images' /> */}
                        <h1 className='astrol_divv'>Astrology</h1>
                    </div>
                </div>
                <div className='row mt-5'>
                    <div className='col-md-12 col-sm-12 mt-5 range'>
                        <h1>Astrology</h1>
                        <p className='mt-5 ml-5'>
                            Astrology is a range of divinatory practices, recognized as pseudoscientific since the 18th century,[1] that claim to discern information about human affairs and terrestrial events by studying the apparent positions of celestial objects.[2][3][4][5][6] Different cultures have employed forms of astrology since at least the 2nd millennium BCE, these practices having originated in calendrical systems used to predict seasonal shifts and to interpret celestial cycles as signs of divine communications.[7] Most, if not all, cultures have attached importance to what they observed in the sky, and some—such as the Hindus, Chinese, and the Maya—developed elaborate systems for predicting terrestrial events from celestial observations. Western astrology, one of the oldest astrological systems still in use, can trace its roots to 19th–17th century BCE Mesopotamia, from where it spread to Ancient Greece, Rome, the Islamicate world and eventually Central and Western Europe. Contemporary Western astrology is often associated with systems of horoscopes that purport to explain aspects of a person's personality and predict significant events in their lives based on the positions of celestial objects; the majority of professional astrologers rely on such systems.[8]: 83 <br /><br />

                            Throughout most of its history, astrology was considered a scholarly tradition and was common in academic circles, often in close relation with astronomy, alchemy, meteorology, and medicine.[9] It was present in political circles and is mentioned in various works of literature, from Dante Alighieri and Geoffrey Chaucer to William Shakespeare, Lope de Vega, and Calderón de la Barca. During the Enlightenment, however, astrology disappeared as an area of legitimate scientific pursuit.[10][11] Following the end of the 19th century and the wide-scale adoption of the scientific method, researchers have successfully challenged astrology on both theoretical[12]: 249 [13] and experimental grounds,[14][15] and have shown it to have no scientific validity or explanatory power.[8] Astrology thus lost its academic and theoretical standing, and common belief in it has largely declined, until a resurgence starting in the 1960s. <br /><br />
                            Astrology, in its broadest sense, is the search for meaning in the sky.[20]: 2, 3  Early evidence for humans making conscious attempts to measure, record, and predict seasonal changes by reference to astronomical cycles, appears as markings on bones and cave walls, which show that lunar cycles were being noted as early as 25,000 years ago.[21]: 81ff  This was a first step towards recording the Moon's influence upon tides and rivers, and towards organising a communal calendar.[21] Farmers addressed agricultural needs with increasing knowledge of the constellations that appear in the different seasons—and used the rising of particular star-groups to herald annual floods or seasonal activities.[22] By the 3rd millennium BCE, civilisations had sophisticated awareness of celestial cycles, and may have oriented temples in alignment with heliacal risings of the stars. <br /><br />
                            The system of Chinese astrology was elaborated during the Zhou dynasty (1046–256 BCE) and flourished during the Han Dynasty (2nd century BCE to 2nd century CE), during which all the familiar elements of traditional Chinese culture – the Yin-Yang philosophy, theory of the five elements, Heaven and Earth, Confucian morality – were brought together to formalise the philosophical principles of Chinese medicine and divination, astrology, and alchemy.<br /><br />
                            With the occupation by Alexander the Great in 332 BCE, Egypt became Hellenistic. The city of Alexandria was founded by Alexander after the conquest, becoming the place where Babylonian astrology was mixed with Egyptian Decanic astrology to create Horoscopic astrology. This contained the Babylonian zodiac with its system of planetary exaltations, the triplicities of the signs and the importance of eclipses. It used the Egyptian concept of dividing the zodiac into thirty-six decans of ten degrees each, with an emphasis on the rising decan, and the Greek system of planetary Gods, sign rulership and four elements.[37] 2nd century BCE texts predict positions of planets in zodiac signs at the time of the rising of certain decans, particularly Sothis.[38] The astrologer and astronomer Ptolemy lived in Alexandria. Ptolemy's work the Tetrabiblos formed the basis of Western astrology, and, "...enjoyed almost the authority of a Bible among the astrological writers of a thousand years or more. <br /><br />
                        </p>
                        <h1 className='mt-5'>What is Astrology</h1>
                        <p className='mt-4 ml-5'>
                            Astrology is the study of the influence that distant cosmic objects, usually stars and planets, have on human lives. The position of the sun, stars, moon and planets at the time of people's birth (not their conception) is said to shape their personality, affect their romantic relationships and predict their economic fortunes, among other divinations. <br/><br/>

                            What most people know about astrology is their "sign," which refers to one of the 12 constellations of the zodiac. This is a form of sun-sign astrology, which is the astrology upon which newspaper horoscopes are based. It is probably the simplest form, because nothing more than the date of someone's birthday is needed to generate a sun-sign horoscope. Many astrologers will tell you that this form of astrology is so simplistic that it produces very limited results. <br/><br/>

                            To produce a more accurate reading, astrologers check to see what sign each planet was in at the time of birth. The planets and signs combine with other elements, such as houses and angles, to form a complex and often very specific profile of a subject's personality, life and future prospects.

                            There is no single unified theory or practice of astrology. Ancient cultures all practiced their own forms, some of which combined and evolved into today's common western astrology. Eastern cultures continue to practice their own forms of astrology: Chinese, Vedic and Tibetan astrology are among the most well-known. <br/><br/>

                            Even within Western astrology, there is a considerable diversity of methods and philosophies. Some divide astrology by the end result that is intended: <br/><br/>

                            Mundane Astrology - This is used to examine world events and make predictions about national affairs, wars and economies. <br/><br/>
                            Interrogatory Astrology - This branch can be further subdivided, but generally refers to astrology that seeks to make specific predictions or analyses about the subject's objectives or events within the subject's life. <br/><br/>
                            Natal Astrology - This is what most people think of when they think of astrology. Natal Astrology seeks to make predictions and analyses based on the date of a person's birth. It's based on the idea that everything that happens to something is expressed at the very beginning of that thing, sometimes known as the Law of Beginnings (Burk, pg. 5). <br/><br/>
                        </p>
                    </div>
                </div>
            </div>
            <Footerdepartments/>
        </div>
    )
}

export default Astrologydepartment