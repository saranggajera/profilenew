import React, { useEffect } from 'react'
import Navbar from '../Navbar/Navbar'
import Footerdepartments from './Footerdepartments'

const CardiologyDepartments = () => {

  useEffect(() => {
    window.scrollTo({top: 0, left: 0,});
  }, []);

  return (
    <div className='cardiollogy'>
      <Navbar />
      <div className='container'>
        <div className='row'>
          <div className='col-md-12 col-sm-12 heart_divv'>
            {/* <img className='heart_images' src='/images/heartt.png' alt='images' /> */}
            <h1 className='cardiology_divvs'>cardiology</h1>
          </div>
        </div>
        <div className='row'>
          <div className='col-md-12 col-sm-12 mt-5'>
            <h1 className='mt-5 mb-4 range'>What is a cardiologist?</h1>
            <p className='ml-5'>
              A cardiologist is a doctor who’s an expert in heart and blood vessel diseases. They can treat heart diseases and help keep you from getting heart diseases. <br /> <br />
              After 10 years of training, a cardiologist can take an American Board of Internal Medicine exam. Even after achieving board certification, cardiologists keep learning for as long as they practice. They must keep up with the latest advances in how to treat patients to provide the best care. <br /> <br />
              A cardiologist is a healthcare provider who can treat chest pain, high blood pressure and heart failure, as well as problems with your heart valves, blood vessels and other heart and vascular issues. They can order tests like electrocardiograms, echocardiograms and CTs (computed tomography) to find out what’s wrong. With their diagnosis, they can order medicine, help you start healthier exercise and eating habits or do cardiac catheterization. <br /> <br />
              A cardiologist will do a physical exam and discuss your symptoms, medical history and family history with you. It’s important to let your cardiologist know if other people in your family have had heart problems because that can increase the chances of you having a heart problem. <br /> <br />
              Some basic information can give your cardiologist valuable information about your cardiovascular health, such as your: <br /> <br />
              Your provider will look at all of this information and any test results to figure out your risk factors for heart problems. They’ll also want to know if you smoke, how much you exercise, what you eat and which medicines you’re taking. <br /> <br />
              A cardiologist will do a physical exam, paying special attention to listening to your heart. They can hear how well blood flows throughout your heart and whether you have an irregular heart rhythm. <br /> <br />
              Be ready to answer questions about your family history and your own medical history. Your cardiologist will want to know if your siblings, parents or others in your family have had heart problems. Having this information can help your cardiologist know what types of heart problems you could have. <br /> <br />
            </p>
            <h1 className='mt-5'>What is cardiologist?</h1>
            <p className='ml-5 mt-4'>
              Cardiology is a medical specialty and a branch of internal medicine concerned with disorders of the heart. It deals with the diagnosis and treatment of such conditions as congenital heart defects, coronary artery disease, electrophysiology, heart failure and valvular heart disease. Subspecialties of the cardiology field include cardiac electrophysiology, echocardiography, interventional cardiology and nuclear cardiology. <br /> <br />

              Cardiovascular system <br /> <br />

              The basic functioning of the cardiovascular system includes the way the heart processes oxygen and nutrients in the blood, which is called coronary circulation. The circulation system consists of coronary arteries and coronary veins. <br /> <br />

              There are a range of disorders of the cardiovascular system that are treated and studied under the field of cardiology. Among them are acute coronary syndrome, which encompasses the broad range of myocardial infarction symptoms. Angina pectoris, atherosclerosis, coronary heart disease and restenosis are other common disorders. Broader categories of disorders in the field of cardiology include cardiac arrest; disorders of the myocardium, <br /> <br />

              Several devices are used in cardiology, including various types of balloons and defibrillators, a pacemaker, and a stethoscope. Artificial hearts also are used and studied in the field of cardiology. <br /> <br />

              Cardiologists <br /> <br />

              Specialists in cardiology are called cardiologists. Some of the strategies used by cardiologists to combat cardiovascular diseases include coronary artery bypass surgery, percutaneous coronary intervention, percutaneous transluminal angioplasty and stenting. Cardiologists also may diagnose cardiovascular disorders using blood tests, cardiac stress tests, echocardiography or electrocardiography or computed tomography and magnetic resonance imaging techniques. <br /> <br />

              The training required to become a cardiologist involves more than 10 years of studying internal medicine and specialized programs.
            </p>
          </div>
        </div>
      </div>
      <Footerdepartments />
    </div>
  )
}

export default CardiologyDepartments