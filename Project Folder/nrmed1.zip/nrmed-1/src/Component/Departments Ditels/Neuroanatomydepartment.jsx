import React, { useEffect } from 'react'
import Navbar from '../Navbar/Navbar'
import Footerdepartments from './Footerdepartments'

const Neuroanatomydepartment = () => {

    useEffect(() => {
        window.scrollTo({top: 0, left: 0,});
      }, []);

    return (
        <div className='neuroanatomydepartment'>
            <Navbar />
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12 lungs_divv'>
                        {/* <img className='lungs_images' src='/images/lungss.png' alt='images' /> */}
                        <h1 className='neuroana_divv'>Neuroanatomy</h1>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12 col-sm-12 mt-5'>
                        <h1 className='mt-5 range'>Who is Neuroanatomy</h1>
                        <p className='mt-5 ml-5'>
                            Neuroanatomy is the study of the relationship between structure and function in the nervous system. Neuroanatomy includes the study of macroscopic and microscopic structures. Macroscopic structures are larger structures, such as folds of the brain. On the other hand, microscopic structures include those at the cellular and molecular level, like interactions between neurons and glia. <br /><br />
                            The Edwin Smith Surgical Papyrus, from ancient Egypt, represents the first known record of a neuroanatomy study. It dates to around 1600 BCE. It was the Greek philosopher Alcmaeon who first understood that it is not the heart, but the brain in charge of human body and the senses. Alcmaeon’s work dates to the 5th century BCE. Other scientists and philosophers have built on those works. For example, in the 17th century Thomas Willis (who was a professor and neuroanatomist at Oxford University) published Cerebri Anatome, which is still considered the foundation text of neuroanatomy. <br /><br />
                            Three components form the foundation of the nervous system: neurons (or  nerve cells), neuroglia (glial cells) and extracellular constituents. Neurons process information by sensing the environment, communicating through neurotransmitters, and originating our thoughts and memories. <br /><br />
                            Neurons have a cell body (soma) and two types of extensions, or processes. One is called a dendrite, and the other one is an axon. Neurons usually have more than one dendrite and one axon. Dendrites receive signals which they then send towards the cell body. The axon also transmit signals, but over longer distances. <br /><br />
                            The nervous system is comprised of fiber bundles that originate from the brain, but also from the spinal cord. These fibers are called nerves, and they are made of neurons plus membranes that separate them into fascicles. Moreover, they form branches to reach every part of the body.

                            In vertebrates, the nervous system is commonly divided into central part (or central system) and peripheral part (or peripheral system). The central nervous system (often abbreviated as CNS) entails the brain, the spinal cord and the retina, and spinal cord, whereas the peripheral nervous system (often abbreviated as PNS) contains all the other nerves that connect the CNS to the remainder of the body. <br /><br />

                            Humans have 31 pairs of spinal nerves emanating from the spinal cord. Twelve pairs of nerves emanate from the brain. One of those, the vagus nerve, descends into the trunk and innervates the inner organs (along with other fibers that come from the spinal cord). <br /><br />

                            The PNS, in turn, is comprised of somatic (controls muscle movement) and autonomic (controls involuntary actions) nervous systems. The somatic system contains neurons which are afferent and which gather sensory data from the environment in order to deliver it in the central nervous system. It also contains neurons which are efferent and that convey motor commands to muscles. <br /><br />
                        </p>
                        <h1 className='mt-5'>What is Neuroanatomy</h1>
                        <p className='ml-5 mt-4'>
                            The brain is the body’s command center. This specialized organ is responsible for every thought, every feeling, and the vast majority of our actions. Its unique (and complex) three-dimensional architecture plays an important role in deciding upon and issuing those important commands. Over the past few hundred years, scientists have learned that the brain has dedicated regions responsible for specific tasks like understanding and producing speech or processing visual and spatial information. Each part of the brain’s intricate configuration works together to govern sensation and perception, information processing, and the initiation of a wide variety of behaviors—and helps us make sense of the world around us. While a complete discussion of neuroanatomy is worthy of a thick textbook full of elaborate illustrations, here are some of the basics. <br /><br />

                            The nervous system. The nervous system is a complex network of nerves and cells that carry messages to and from the brain to the rest of the body. The nervous system has two main parts: the central nervous system (CNS), made up of the spinal cord and the brain; and the peripheral nervous system (PNS), the nerves and other types of supporting cells that branch throughout the rest of the body and communicate back to the CNS. <br /><br />

                            cartoon of nervous systemSome further break down the CNS into the hindbrain, the lower part of the brainstem; the midbrain, the central part of the brainstem; and the forebrain, which includes the cerebral hemispheres. But the CNS may also be discussed in terms of these three sections: the brain stem, the cerebellum, and the cerebral hemispheres. The brain stem is responsible for autonomic processes, or processes that occur reflexively, like breathing and heart rate. It also helps conduct information from the brain to the PNS. The cerebellum, the so-called “little brain,” next to the brain stem, handles balance and coordination of movement.  Finally, perched above the brain stem and cerebellum, is the cerebral cortex. This is probably what you think of when you picture the brain—and it is responsible for sensory perception, information processing, and memory, learning, and decision-making. The parts of the CNS work together seamlessly in healthy individuals, allowing the brain to govern functions and behaviors ranging from breathing to reading. <br /><br />
 
                            The hemispheres. The cerebral cortex is divided into two hemispheres. These two sides of the brain are connected by the corpus callosum, a bridge of wide, flat neural fibers that help relay signals between them. While several popular books suggest these two sides of the brain are important to specific functions—that is, the right side of the brain is responsible for creativity while the left side handles your more analytical-type processing (sometimes referred to as “lateralization”)—activity for most cognitive tasks is seen on both hemispheres. The exception is language. Two key areas involved in language—Broca’s Area, responsible for language grammar and syntax, and Wernicke’s Area, implicated in language content and meaning processing—reside on the left side of the brain for most. (Those areas may be on the right side in some left-handed individuals). Otherwise, the two cerebral hemispheres are nearly symmetrical. [To learn more about lateralization, read our fact sheet “Right Brain, Left Brain: A Misnomer.”] <br /><br />

                            The lobes. The cerebral hemispheres are further subdivided into four major lobes: the occipital, towards the back of the brain; the parietal, just above the ear; the temporal, just <br /><br />
                        </p>
                    </div>
                </div>
            </div>
            <Footerdepartments/>
        </div>
    )
}

export default Neuroanatomydepartment