import React from 'react'
import './bookappointment.css'





const Bookappointment = () => {
    return (
        <>
            <div class="bgimg-1">
                <div class="caption">
                    <div className='container'>
                        <div className='row'>
                            <div className='col-lg-12 col-md-12 col-sm-12'>
                                <div className='book_appoint'>
                                    <h1 className='mb-4 book_div'>
                                        Book an <br />
                                        <span className='appoint_div'>Appointment</span>
                                    </h1>
                                    <form>
                                        <div className="form-group">
                                            <select className="form-select select_box" aria-label="Default select example">
                                                <option selected>Open this select menu</option>
                                                <option value="1">One</option>
                                                <option value="2">Two</option>
                                                <option value="3">Three</option>
                                            </select>
                                        </div>
                                        <div className='d-flex justify-content-between'>
                                            <div className="form-group" style={{ width: "80%" }}>
                                                <input type="text" className="form-control select_box" id="exampleInputEmailName1" aria-describedby="EmailHelp" placeholder="Your name" />
                                            </div>
                                            <div className="form-group" style={{ width: "15%" }}>
                                                <input type="number" className="form-control select_box" id="exampleInputPassword1" placeholder="Your age" />
                                            </div>
                                        </div>
                                        <div className='d-flex justify-content-between'>
                                            <div className="form-group" style={{ width: "47%" }}>
                                                <input type="tel" maxLength="10" minLength="10" onKeyPress={(event) => {
                                                    if (!/[0-9]/.test(event.key)) {
                                                        event.preventDefault();
                                                    }
                                                }} className="form-control select_box" id="exampleInputNumber1" placeholder="Phone number" />
                                            </div>
                                            <div className="form-group" style={{ width: "47%" }}>
                                                <input type="email" className="form-control select_box" id="exampleInputEmail1" placeholder="Email Address" />
                                            </div>
                                        </div>
                                        <div className='d-flex justify-content-between'>
                                            <div className="form-group" style={{ width: "47%" }}>
                                                <input type="Date" className="form-control select_box" id="exampleInputDate1" placeholder="Appointment Date" />
                                            </div>
                                            <div className="form-group" style={{ width: "47%" }}>
                                                <input type="time" className="form-control select_box" id="exampleInputPassword1" placeholder="Password" />
                                            </div>
                                        </div>
                                        <button type="submit" className="btn_submitts">Submit</button>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default Bookappointment