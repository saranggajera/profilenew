import React, { useEffect, useState } from 'react'
import Navbar from '../Navbar/Navbar'
import './home.css'
import { NavLink } from 'react-router-dom'
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';
import axios from 'axios';

const Home = () => {

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, });
  }, []);



  // const [like, setLike] = useState(100)
  // const [dislike, setDislike] = useState(4)


  // const [likeactive, setLikeactive] = useState(false)
  // const [diselikeactive, setDiselikeactive] = useState(false)


  // function likef() {
  //   if (likeactive) {
  //     setLikeactive(false)
  //   } else {
  //     setLikeactive(true)
  //     if (diselikeactive) {
  //       setDiselikeactive(false)
  //     }
  //   }
  // }

  // function dislikef() {
  //   if (diselikeactive) {
  //     setDiselikeactive(false)
  //   } else {
  //     setDiselikeactive(true)
  //     if (likeactive) {
  //       setLikeactive(false)
  //     }
  //   }
  // }

  return (
    <div className='home'>
      <Navbar />
      <div className='container'>
        <div className='row'>
          <div className='the_best col-md-12 col-sm-12'>
            <h5>THE BEST MEDICALCENTER</h5>
            <h1>Bringing health <br />
              <span className='health_to'>to life for the whole family.</span>
            </h1>
            <NavLink to="/discoverhome"><button className='btn_discover'>Hospital <ArrowRightAltIcon /></button></NavLink>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Home