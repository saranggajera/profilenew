import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { BaseUrl } from '../../BaseUrl';
import Footer from '../../Footer/Footer';
import Navbar from '../../Navbar/Navbar';

const Discoverdetels = () => {
  const { id } = useParams()
  console.log("ssssssssssssss", id);

  const [detels, setdetels] = useState([])

  const viewdetels = async (id) => {
    const res = await axios.get(`${BaseUrl}/hospital/ViewById/${id}`)
      .then((res) => {
        console.log("bbbbbbbbbbbbbbbbbbbbbbbbb", res.data.info);
        setdetels(res.data.info)
      })
      .catch((error) => {
        console.log(error);
      })
  }

  useEffect(() => {
    viewdetels(id)
  }, [])


  return (

    <div className='discoverdetels'>
      <Navbar />
      <div className='container'>
        <div className='row'>
          <div className='col-md-12 col-sm-12'>
            <div className='hospital_name'>
              <h1>{detels.name}</h1>
            </div>
          </div>
        </div>
        <div className='row mt-5'>
          <div className='col-md-6 col-sm-6'>
            <div className='color_div'> </div>
            <img className='imag_modern mb-5' src='/images/dalton-ngangi-ZCztndOWdjs-unsplash.jpg' alt='images' />

          </div>
          <div className='modern_div col-md-6 col-sm-6'>
            <h1 className='welcom_div'>Welcome to <br />
              <span className='clinic_div'>{detels.name}</span>
            </h1>
            <p className='my-4'>
              Lorem ipsum dolor sit amet, consectetur Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veni.
            </p>
            <div>
              <p><span className='right_icon'>✓</span>Lorem ipsum dolor sit amet</p>
              <p><span className='right_icon'>✓</span>Consectetur adipisicing elit, sed do</p>
              <p><span className='right_icon'>✓</span>Eiusmod tempor incididunt ut labore</p>
            </div>
          </div>
        </div>
      </div>
      <div className='mt-5'>
      <Footer/>
      </div>
    </div>
  )
}

export default Discoverdetels