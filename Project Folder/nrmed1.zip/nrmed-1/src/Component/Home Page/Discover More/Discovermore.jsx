import React, { useEffect, useState } from 'react'
import './discovermore.css'
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import axios from 'axios';
import { BaseUrl } from '../../BaseUrl';
import Navbar from '../../Navbar/Navbar';
import { NavLink, useParams } from 'react-router-dom';


const Discovermore = () => {
    
    const {id} = useParams()
    console.log("ddddddddddddddddd",id);

    const [hospital, setHospital] = useState([])
    const [showmor, setShowmor] = useState(2)

    const slice = hospital.slice(0, showmor);
    const loadmore = () => {
        setShowmor(showmor + showmor)
        if (hospital.length == slice.length) {
            toast.error("No show more Data", {
                position: "top-right"
            })
        }
    }






    const Hospital = async () => {
        const res = await axios.get(`${BaseUrl}/hospital/ViewAll`)
            .then((res) => {
                console.log("aaaaaaaaaaaaaaaaaaaaaaa", res.data.data);
                setHospital(res.data.data)
            })
            .catch((error) => {
                console.log("helloooooooooo",error);
            })
    }

    useEffect(() => {
        Hospital()
    }, [])

    return (
        <div className='discovermore'>
            <Navbar />
            <div className='container'>
                <div className='row hosplit_divv'>
                    {
                        slice.map((eve, ind) => {
                            return (
                                <div key={ind} className='col-lg-6 col-md-6 col-sm-12 mt-5'>
                                    <NavLink to={`/discoverdetels/${eve._id}`}>
                                    <div className='img_disco_divv'>
                                        <img src='/images/erik-mclean-AW7p7dXwG5U-unsplash.jpg' alt='images' />
                                    </div>
                                    <div className='hosplita_main_divv'>
                                        <h2>{eve.name}</h2>
                                        <h5>{eve.address}</h5>
                                    </div>
                                    </NavLink>
                                </div>
                            )
                        })
                    }
                </div>
                <button className='btn_success mb-5' onClick={() => loadmore()}>more</button>
                <ToastContainer />
            </div>
        </div>
    )
}

export default Discovermore