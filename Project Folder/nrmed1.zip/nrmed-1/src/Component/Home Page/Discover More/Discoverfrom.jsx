import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { BaseUrl } from '../../BaseUrl'

const Discoverfrom = (props) => {

    const [discover, setDiscover] = useState({
        name: "",
        email: "",
        mobile: "",
        whoYouAre: "",
        whatYouWant: "",
        zipCode: "",
        moblie_code: "",
    })


    const ondiscover = (event) => {
        const name = event.target.name
        const value = event.target.value

        // console.log(name, value)

        setDiscover({ ...discover, [name]: value })
    }

    const OnDiscover = async (event) => {
        event.preventDefault()
        console.log(discover)

        await axios.post(`${BaseUrl}/quickConnect/insert`, discover)
            .then((res) => {
                // props.subbmit
                console.log(res);
                setDiscover({
                    name: "",
                    email: "",
                    mobile: "",
                    whoYouAre: "",
                    whatYouWant: "",
                    zipCode: "",
                    moblie_code: "",
                })
            })
            .catch((error) => {
                console.log(error);
            })
    }

    const [mobliecode, setMobliecode] = useState([])


    const code = async () => {
        const res = await axios.get(`${BaseUrl}/country/countryViewAll`)
            .then((res) => {
                console.log("hello jjjjjjjj", res.data.data);
                setMobliecode(res.data.data)
            })
            .catch((error) => {
                console.log(error);
            })
    }

    useEffect(() => {
        code()
    }, [])

    return (
        <div className='discoverfrom'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12 col-sm-12'>
                        <div className='from_hosp'>
                        <h1 className='my-4'>Query</h1>
                            <form className='mt-5' onSubmit={OnDiscover}>
                               <div className="d-flex justify-content-between">
                               <div className="form-group">
                                    <label for="exampleInputName1">Name</label>
                                    <input style={{height:'50px'}} type="text" className="form-control" name='name' value={discover.name} onChange={ondiscover} id="exampleInputName1" aria-describedby="NameHelp" placeholder="Enter Name" />
                                </div>
                                <div className="form-group">
                                    <label for="exampleInputemail1">Email</label>
                                    <input style={{height:'50px'}} type="email" required className="form-control" name='email' value={discover.email} onChange={ondiscover} id="exampleInputemail1" placeholder="Email" />
                                </div>
                               </div>
                                <div className='d-flex justify-content-between'>
                                    <div className="form-group" style={{ width: "10%" }}>
                                        <label for="exampleInputMobile1">Moblie_code</label>

                                        <select class="form-select" aria-label="Default select example" name='moblie_code' value={discover.moblie_code} onChange={ondiscover} style={{ width: "100%", height: "50px" }}>
                                            {
                                                mobliecode.map((eve, ind) => {
                                                    return (
                                                        <option key={ind}>{eve.dial_code}</option>
                                                    )
                                                })
                                            }
                                        </select>
                                    </div>
                                    <div className="form-group" style={{ width: "80%" }}>
                                        <label for="exampleInputMobile1">Mobile</label>
                                        <input style={{height:'50px'}} type="tel" className="form-control" name='mobile' maxLength="10" minLength="10"
                                            onKeyPress={(event) => {
                                                if (!/[0-9]/.test(event.key)) {
                                                    event.preventDefault();
                                                }
                                            }}
                                            value={discover.mobile} onChange={ondiscover} id="exampleInputMobile1" placeholder="Mobile" />
                                    </div>
                                </div>
                                <div className="d-flex justify-content-between">
                                <div className="form-group">
                                    <label for="exampleInputWhoYouAre1">Who You Are</label>
                                    <select className="form-select" aria-label="Default select example" name='who You Are' value={discover.whoYouAre} onChange={ondiscover} style={{ width: "140%", height: "50px" }}>
                                        <option selected>select whoYouAre</option>
                                        <option value="Hospital">Hospital</option>
                                        <option value="Doctore">Doctore</option>
                                        <option value="patient">patient</option>
                                        <option value="Ambulance">Ambulance</option>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label for="exampleInputWhatYouWant1">WhatYou Want</label>
                                    <input style={{height:'50px'}} type="email" required className="form-control" name='whatYouWant' value={discover.whatYouWant} onChange={ondiscover} id="exampleInputEnter What You Want1" placeholder="Enter What You Want" />
                                    {/* <textarea class="form-control" id="exampleFormControlTextarea1" name='whatYouWant' value={discover.whatYouWant} onChange={ondiscover} placeholder='Enter What You Want' rows="2"></textarea> */}
                                </div>
                                </div>
                                <div className="form-group">
                                    <label for="exampleInputZipCode1">ZipCode</label>
                                    <input style={{height:'50px'}} type="tel" maxLength="6" minLength="4" onKeyPress={(event) => {
                                        if (!/[0-9]/.test(event.key)) {
                                            event.preventDefault();
                                        }
                                    }} className="form-control" name='zipCode' value={discover.zipCode} onChange={ondiscover} id="exampleInputHospital_email1" placeholder="ZipCode" />
                                </div>
                                <button type="submit" className="btn_success">Submit</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Discoverfrom