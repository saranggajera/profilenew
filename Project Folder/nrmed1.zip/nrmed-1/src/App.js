// import React from 'react'
// import 'bootstrap/dist/css/bootstrap.min.css';
// import 'bootstrap/dist/js/bootstrap.js';
// import Docoter from './Component/home/Docoter'
// import {Route,Routes} from "react-router-dom"
// import Homemane from './Component/home/Homemane'
// import Cardiology from './Component/home/Cardiology'
// import Specialists from './Component/home/Specialists'
// import Astrology from './Component/home/Astrology'
// import Neuroanatomy from './Component/home/Neuroanatomy'
// import Screening from './Component/home/Screening'
// import Appoinment from './Component/Appoinment/Appoinment'
// import Doctorlogin from './Component/Doctor Login/Doctorlogin'
// import Emailverify from './Component/Email Verify/Emailverify'
// import Doctorregistration from './Component/Doctor Login/Doctorregistration'
// import { ToastContainer } from 'react-toastify';
// import 'react-toastify/dist/ReactToastify.css';
// import Abouthome from './Component/About/Abouthome'
// import Discoverhome from './Component/Home Page/Discover More/Discoverhome'
// import Contacthome from './Component/Contact/Contacthome'
// import Dentistry from './Component/Departments Ditels/Dentistry'
// import CardiologyDepartments from './Component/Departments Ditels/CardiologyDepartments'
// import Specialistsdepartment from './Component/Departments Ditels/Specialistsdepartment'
// import Astrologydepartment from './Component/Departments Ditels/Astrologydepartment'
// import Neuroanatomydepartment from './Component/Departments Ditels/Neuroanatomydepartment'
// import Screeningdepartments from './Component/Departments Ditels/Screeningdepartments'
// import Discoverdetels from './Component/Home Page/Discover More/Discoverdetels'
// import Patientviewall from './Component/Patient/Patient _View_All/Patientviewall'
// import Patiendetels from './Component/Patient/Patient_detels/Patiendetels'


// const App = () => {
//   return (
//     <>
//       <Routes>
//       <Route path="/" element={<Homemane/>}/>
//         <Route path="/doctor" element={<Docoter/>}/>
//         <Route path="/cardiology" element={<Cardiology/>}/>
//         <Route path="/specialists" element={<Specialists/>}/>
//         <Route path="/astrology" element={<Astrology/>}/>
//         <Route path="/neuroanatomy" element={<Neuroanatomy/>}/>
//         <Route path="/screening" element={<Screening/>}/>
//         <Route path="/appoinment" element={<Appoinment/>}/>
//         <Route path="/doctorlogin" element={<Doctorlogin/>}/>
//         <Route path="/emailverify" element={<Emailverify/>}/>
//         <Route path="/doctorregistration" element={<Doctorregistration/>}/>
//         <Route path="/about" element={<Abouthome/>}/>
//         <Route path="/discoverhome" element={<Discoverhome/>}/>
//         <Route path="/contact" element={<Contacthome/>}/>
//         <Route path="/doctorr" element={<Dentistry/>}/>
//         <Route path="/cardiologyy" element={<CardiologyDepartments/>}/>
//         <Route path="/specialistss" element={<Specialistsdepartment/>}/>
//         <Route path="/astrologyy" element={<Astrologydepartment/>}/>
//         <Route path="/neuroanatomyy" element={<Neuroanatomydepartment/>}/>
//         <Route path="/screeningg" element={<Screeningdepartments/>}/>
//         <Route path="/discoverdetels/:id" element={<Discoverdetels/>}/>
        
//         {/*--------------------------------------Patient------------------------------------*/}
//         <Route path="/patientviewall" element={<Patientviewall/>}/>
//         <Route path="/patiendetels/:id" element={<Patiendetels/>}/>

//       </Routes>
//     <ToastContainer/>

//     </>
//   )
// }

// export default App

import React, { useState, useEffect } from 'react';

const App = () => {
  const [demo, setDemo] = useState([
    { Name: 'data', email: 'demo@gmail.com', number: '634365638363' },
  ]);

  const [hello, setHello] = useState([]);
    console.log("dfgjdhgd",hello)
    const [hellos, setHellos] = useState([]);
    console.log("aaaaaaa",hellos)

  useEffect(() => {
    const getEmail = () => {
      demo.map((item) => {
        console.log(item);
        if (item.email === 'demo@gmail.com' || item.number === '634365638363') {
          setHello(item.email);
          setHellos(item.number)
        }
      });
    };
    getEmail();
  }, [demo]);

  return <div>App</div>;
};

export default App;
