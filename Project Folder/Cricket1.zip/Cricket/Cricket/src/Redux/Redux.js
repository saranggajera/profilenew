import { createSlice } from '@reduxjs/toolkit'

const userDataSlice = createSlice({
  name: 'user',
  initialState: {
    userData: [],
    playersData: {},
    auctionCart: [],
    franchiseData: {},
    Auctsucdataplayerdata: [],
  },
  reducers: {
    setUserData: (state, action) => {
      state.userData = action.payload
    },
    playersDetails: (state, action) => {
      state.playersData = action.payload
    },
    setAuctionCartData: (state, action) => {
      const itemIndex = state.auctionCart.findIndex(
        (item) => item.id === action.payload.id
      );
      if (itemIndex >= 0) {
        state.auctionCart[itemIndex].cartQuantity += 1;
      } else {
        const temProduct = { ...action.payload, cartQuantity: 1 };
        state.auctionCart.push(temProduct);
      }
    },
    deletePlayers: (state, action) => {
      const auctionCart = state.auctionCart.find(
        (item) => item.id === action.payload
      );
      if (auctionCart) {
        state.auctionCart.splice(state.auctionCart.indexOf(auctionCart), 1);
      }
    },
    clearCart: (state) => {
      state.auctionCart = [];
    },
    addCart: (state, action) => {
      state.cart.push(action.payload);
    },
    setFranchiseData: (state, action) => {
      state.franchiseData = action.payload;
    },
    setAuctionplaydata: (state, action) => {
      state.Auctsucdataplayerdata.push(action.payload);
    },
  },
});
export const {
  setUserData,
  playersDetails,
  setAuctionCartData,
  deletePlayers,
  clearCart,
  addCart,
  setFranchiseData,
  setAuctionplaydata,
} = userDataSlice.actions;
export default userDataSlice.reducer;
