import React from 'react'
import Footer from '../components/Footer'
import Navbar from '../components/Navbar'
import Team from '../Pages/Team/Team'

const LandingPage = () => {
  return (
    <div>
      <Navbar />
      <Team />
      <Footer />
    </div>
  )
}

export default LandingPage
