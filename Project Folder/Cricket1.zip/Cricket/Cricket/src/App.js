import './App.css'
import { BrowserRouter, Routes, Route } from 'react-router-dom'
import LandingPage from './LandingPage/LandingPage'
import Players from './Pages/Players/Players'
import Cart from './Pages/Cart/Cart'
import { ToastContainer } from 'react-toastify'
import 'react-toastify/dist/ReactToastify.css'
import Auctioncart from './Pages/AuctionPage/Auctioncart'
import Auctionsuccesspage from './Pages/AuctionPage/Auctionsuccesspage'

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/players/:id" element={<Players />} />
          <Route path="/cart" element={<Cart />} />
          <Route path="/auctioncart" element={<Auctioncart />} />
          <Route path="/auctionsuccess" element={<Auctionsuccesspage />} />
        </Routes>
      </BrowserRouter>
      <ToastContainer />
    </div>
  )
}

export default App
