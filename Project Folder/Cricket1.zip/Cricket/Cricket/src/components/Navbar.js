import React from 'react'
import WindowSharpIcon from '@mui/icons-material/WindowSharp';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart'
import { Link } from 'react-router-dom'
import { useSelector } from 'react-redux'
import { IconButton } from '@mui/material'
import Badge from '@mui/material/Badge'
import '../components/Navbar.css'

const Navbar = () => {
  const { auctionCart } = useSelector(state => state.cricketers)
  return (
    <div>
      <header className="text-gray-600 body-font">
        <div className="container mx-auto flex flex-wrap p-5 flex-col md:flex-row items-center">
          <Link to={'/'}>
            <a className="flex title-font font-medium items-center text-gray-900 mb-4 md:mb-0">
              <WindowSharpIcon color="primary" />
              <span className="ml-3 text-xl text-indigo-600">CRICKET</span>
            </a>
          </Link>
          <nav className="md:ml-auto md:mr-auto flex flex-wrap items-center text-base justify-center"></nav>
          <div className="inline-flex items-center border-0 py-1 px-3 focus:outline-none rounded text-base mt-4 md:mt-0 cursor-pointer">
            <Link to={'/cart'}>
              <Badge badgeContent={auctionCart.length} color="primary">
                <IconButton aria-label="cart" className="iconButton">
                  <ShoppingCartIcon />
                </IconButton>
              </Badge>
            </Link>
          </div>
        </div>
      </header>
    </div>
  )
}

export default Navbar
