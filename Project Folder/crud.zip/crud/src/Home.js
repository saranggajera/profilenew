import React, { useState, useEffect } from "react";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import { pink } from "@mui/material/colors";
import { NavLink } from "react-router-dom";

function Home() {
  const [storedUsers, setStoredUsers] = useState(() => {
    return JSON.parse(localStorage.getItem("userData")) || [];
  });

  useEffect(() => {
    localStorage.setItem("userData", JSON.stringify(storedUsers));
  }, [storedUsers]);

  const onDeleteUserData = (id) => {
    const updatedUsers = storedUsers.filter((user) => user.id !== id);
    setStoredUsers(updatedUsers);
  };

  return (
    <div className="container">
      <div className="row">
        <div className="col-lg-12 text-center">
          <h1>User Data</h1>
        </div>
      </div>
      <div className="row">
        <div className="col-lg-12">
          <table className="table table-striped table-hover">
            <thead>
              <tr>
                <th scope="col">Index</th>
                <th scope="col">First name</th>
                <th scope="col">Last name</th>
                <th scope="col">Date of birth</th>
                <th scope="col">Email address</th>
                <th scope="col">Mobile number</th>
                <th scope="col">Gender</th>
                <th scope="col">Fruits</th>
                <th scope="col">Comments</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
              </tr>
            </thead>
            <tbody>
              {storedUsers.length <= 0 ? (
                <tr>
                  <td colSpan="11" className="text-center">
                    NO DATA FOUND
                  </td>
                </tr>
              ) : (
                storedUsers
                  .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
                  .map((item) => (
                    <tr key={item.id}>
                      <th scope="row">{item.id}</th>
                      <td>{item.firstName}</td>
                      <td>{item.lastName}</td>
                      <td>{item.dob}</td>
                      <td>{item.email}</td>
                      <td>{item.mobile}</td>
                      <td>{item.gender}</td>
                      <td>{item.fruits.join(", ")}</td>
                      <td>{item.comments}</td>
                      <td style={{ cursor: "pointer" }}>
                        <NavLink to="/userform" state={{ user: item }}>
                          <EditIcon />
                        </NavLink>
                      </td>
                      <td style={{ cursor: "pointer" }}>
                        <DeleteIcon
                          sx={{ color: pink[500] }}
                          onClick={() => onDeleteUserData(item.id)}
                        />
                      </td>
                    </tr>
                  ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Home;
