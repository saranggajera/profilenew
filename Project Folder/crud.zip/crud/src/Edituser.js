import React from "react";
import { useNavigate } from "react-router-dom";

function EditUser({ user }) {
  const navigate = useNavigate();

  const handleEditClick = () => {
    navigate("/userform", { state: { user } });
  };

  return (
    <div className="container">
      <h2>Edit User</h2>
      <button className="btn btn-primary" onClick={handleEditClick}>
        Edit User
      </button>
    </div>
  );
}

export default EditUser;
