import React from "react";
import Userform from "./Userform";
import { Routes, Route } from "react-router-dom";
import Home from "./Home";
// import Edituser from "./Edituser";

function App() {
  return (
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/userform" element={<Userform />} />
      {/* <Route path="/edituser" element={<Edituser />} /> */}
    </Routes>
  );
}

export default App;
