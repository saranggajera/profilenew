import React, { useEffect, useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";

function Userform() {
  const navigate = useNavigate();
  const location = useLocation();
  const userToEdit = location.state?.user;

  const isEditing = Boolean(userToEdit);

  const [formData, setFormData] = useState({
    firstName: userToEdit?.firstName || "",
    lastName: userToEdit?.lastName || "",
    dob: userToEdit?.dob || "",
    email: userToEdit?.email || "",
    mobile: userToEdit?.mobile || "",
    gender: userToEdit?.gender || "",
    fruits: userToEdit?.fruits || [],
    comments: userToEdit?.comments || "",
    createdAt: userToEdit?.createdAt || "",
  });

  const [errors, setErrors] = useState({});
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const storedUsers = JSON.parse(localStorage.getItem("userData")) || [];
    setUsers(storedUsers);
  }, []);

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    if (errors[name]) {
      setErrors((prevErrors) => ({ ...prevErrors, [name]: undefined }));
    }

    if (type === "checkbox") {
      setFormData((prev) => {
        const newFruits = checked
          ? [...prev.fruits, value]
          : prev.fruits.filter((fruit) => fruit !== value);
        return { ...prev, fruits: newFruits };
      });
    } else {
      setFormData({ ...formData, [name]: value });
    }
  };

  const validateForm = () => {
    const newErrors = {};
    const emailRegex = /^[a-zA-Z0-9._%+-]+@(gmail\.com|outlook\.com)$/;

    if (!/^[A-Za-z]+$/.test(formData.firstName)) {
      newErrors.firstName = "First name must contain only alphabets.";
    }

    if (!/^[A-Za-z]+$/.test(formData.lastName)) {
      newErrors.lastName = "Last name must contain only alphabets.";
    }

    if (!emailRegex.test(formData.email)) {
      newErrors.email = "Email must be from gmail.com or outlook.com.";
    }

    if (!/^\d{10}$/.test(formData.mobile)) {
      newErrors.mobile = "Mobile number must contain exactly 10 digits.";
    }

    if (formData.fruits.length < 3) {
      newErrors.fruits = "Select at least 3 fruits.";
    }

    if (!formData.comments.trim()) {
      newErrors.comments = "Comments cannot be empty.";
    } else if (/worry|scared|afraid/i.test(formData.comments)) {
      newErrors.comments = "Your comment seems concerning. Please clarify.";
    }

    if (!formData.dob) {
      newErrors.dob = "Date of birth is required.";
    } else {
      const dobDate = new Date(formData.dob);
      const age = new Date().getFullYear() - dobDate.getFullYear();
      if (age < 18) {
        newErrors.dob = "You must be at least 18 years old.";
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (validateForm()) {
      let updatedUsers;
      const currentDate = new Date().toISOString(); // Get current timestamp
      if (isEditing) {
        updatedUsers = users.map((user) =>
          user.id === userToEdit.id ? { ...user, ...formData } : user
        );
      } else {
        const newUser = {
          id: users.length + 1,
          ...formData,
          createdAt: currentDate,
        };
        updatedUsers = [...users, newUser];
      }

      setUsers(updatedUsers);
      localStorage.setItem("userData", JSON.stringify(updatedUsers));

      setFormData({
        firstName: "",
        lastName: "",
        dob: "",
        email: "",
        mobile: "",
        gender: "",
        fruits: [],
        comments: "",
        createdAt: "", // Reset the createdAt field
      });
      setErrors({});
      navigate("/");
    }
  };

  return (
    <div className="container">
      <div className="row">
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label htmlFor="firstName" className="form-label">
              First name
            </label>
            <input
              type="text"
              className="form-control"
              id="firstName"
              name="firstName"
              value={formData.firstName}
              onChange={handleChange}
            />
            {errors.firstName && (
              <small className="text-danger">{errors.firstName}</small>
            )}
          </div>
          <div className="mb-3">
            <label htmlFor="lastName" className="form-label">
              Last name
            </label>
            <input
              type="text"
              className="form-control"
              id="lastName"
              name="lastName"
              value={formData.lastName}
              onChange={handleChange}
            />
            {errors.lastName && (
              <small className="text-danger">{errors.lastName}</small>
            )}
          </div>
          <div className="mb-3">
            <label htmlFor="dob" className="form-label">
              Date of birth
            </label>
            <input
              type="date"
              className="form-control"
              id="dob"
              name="dob"
              value={formData.dob}
              onChange={handleChange}
            />
            {errors.dob && <small className="text-danger">{errors.dob}</small>}
          </div>
          <div className="mb-3">
            <label htmlFor="email" className="form-label">
              Email address
            </label>
            <input
              type="email"
              className="form-control"
              id="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
            />
            {errors.email && (
              <small className="text-danger">{errors.email}</small>
            )}
          </div>
          <div className="mb-3">
            <label htmlFor="mobile" className="form-label">
              Mobile number
            </label>
            <input
              type="text"
              className="form-control"
              id="mobile"
              name="mobile"
              maxLength={10}
              value={formData.mobile}
              onChange={handleChange}
            />
            {errors.mobile && (
              <small className="text-danger">{errors.mobile}</small>
            )}
          </div>
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="gender"
              value="Male"
              id="flexRadioDefault1"
              checked={formData.gender === "Male"}
              onChange={handleChange}
            />
            <label className="form-check-label" htmlFor="flexRadioDefault1">
              Male
            </label>
          </div>
          <div className="form-check">
            <input
              className="form-check-input"
              type="radio"
              name="gender"
              value="Female"
              id="flexRadioDefault2"
              checked={formData.gender === "Female"}
              onChange={handleChange}
            />
            <label className="form-check-label" htmlFor="flexRadioDefault2">
              Female
            </label>
          </div>
          {["Banana", "Apple", "Strawberry", "Avocado", "Pineapple"].map(
            (fruit) => (
              <div className="form-check" key={fruit}>
                <input
                  className="form-check-input"
                  type="checkbox"
                  value={fruit}
                  id={`fruit${fruit}`}
                  checked={formData.fruits.includes(fruit)}
                  onChange={handleChange}
                />
                <label className="form-check-label" htmlFor={`fruit${fruit}`}>
                  {fruit}
                </label>
              </div>
            )
          )}
          {errors.fruits && (
            <small className="text-danger">{errors.fruits}</small>
          )}
          <div className="form-floating mt-4">
            <textarea
              className="form-control"
              placeholder="Leave a comment here"
              id="comments"
              name="comments"
              value={formData.comments}
              onChange={handleChange}
              style={{ height: "100px" }}
            ></textarea>
            <label htmlFor="comments">Comments</label>
            {errors.comments && (
              <small className="text-danger">{errors.comments}</small>
            )}
          </div>
          <button type="submit" className="btn btn-primary mt-5">
            {isEditing ? "Update" : "Submit"}
          </button>
        </form>
      </div>
    </div>
  );
}

export default Userform;
