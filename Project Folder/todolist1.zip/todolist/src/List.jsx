import React from "react";

const List = (props) => {
  return (
    <div>
      <div className="todo_style">
        <button onClick={() => {props.onSelect(props.id);}}>x</button>
        <h6 className="list"> {props.text}</h6>
      </div>
    </div>
  );
};

export default List;
