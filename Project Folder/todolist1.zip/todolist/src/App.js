import React, { useEffect, useState } from "react";
import List from "./List";

const App = () => {
  const [inputs, setInputs] = useState("");
  const [item, setItem] = useState([]);
// console.log("ffff",item);

const itemEvent = (event) => {
  setInputs(event.target.value);
};

  const listadd = () => {
     if (item.indexOf(inputs) === -1) {
      setItem((olditem) => {
        return [...olditem, inputs];
      });
      setInputs("");
     }else{
      alert("This item already exists")
     }
    //  console.log("ffff",item);
  };


  const deleteitem = (id) => {
    setItem((olditem) => {
      return olditem.filter((arrElem, index) => {
        return index !== id;
      });
    });
  };





//   // Every rerender
// useEffect(() => {
// 	console.log("I run everytime this component rerenders")
// });

// // onMount
// useEffect(() => {
// 	console.log("I Only run once (When the component gets mounted)")
// }, []);

// // Condition based 
// useEffect(() => {
// 	console.log("I run everytime my condition is changed")
// }, [condition]);

// // Condition based with "clean up"
// useEffect(() => {
// 	console.log("I run everytime my condition is changed")
	
// 	return () => {
//     	console.log("Use this return as a 'clean up tool' (this runs before the actual code)")
//     }
// }, [condition]);


const [count, setCount] = useState(0);

  useEffect(() => {
    document.title = `You clicked ${count} times`;
  },[count]);




  return (
    <div>
      <div>
      <div>
      <p>You clicked {count} times</p>
      <button onClick={() => setCount(count + 1)}>
        Click me
      </button>
    </div>
        <div>
          <h1>TO DO List</h1>
        </div>
        <div>
          <input
            type="text"
            value={inputs}
            placeholder="Add Items"
            onChange={itemEvent}
          />
          <button onClick={listadd}>+</button>
        </div>
        <div>
            {/* <li> {inputs}</li> */}
            {item.map((lists, index) => {
              return (
                <List
                  key={index}
                  id={index}
                  text={lists}
                  onSelect={deleteitem}
                />
              );
            })}
        </div>
      </div>
    </div>
  );
};

export default App;
