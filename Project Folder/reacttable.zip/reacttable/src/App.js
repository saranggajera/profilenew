import React from 'react'
import './App.css'
import AdjustIcon from '@mui/icons-material/Adjust';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import PermIdentityIcon from '@mui/icons-material/PermIdentity';
import LocalGroceryStoreIcon from '@mui/icons-material/LocalGroceryStore';
import TaskAltIcon from '@mui/icons-material/TaskAlt';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import FiberManualRecordIcon from '@mui/icons-material/FiberManualRecord';
import EmojiEventsIcon from '@mui/icons-material/EmojiEvents';
import TodayIcon from '@mui/icons-material/Today';
import InboxIcon from '@mui/icons-material/Inbox';
import BugReportIcon from '@mui/icons-material/BugReport';
import SettingsIcon from '@mui/icons-material/Settings';
import AppRegistrationIcon from '@mui/icons-material/AppRegistration';
import SearchIcon from '@mui/icons-material/Search';
import FilterListIcon from '@mui/icons-material/FilterList';
import ViewStreamIcon from '@mui/icons-material/ViewStream';
import DehazeIcon from '@mui/icons-material/Dehaze';
import Paper from '@mui/material/Paper';
import Table from '@mui/material/Table';
import TableBody from '@mui/material/TableBody';
import TableCell from '@mui/material/TableCell';
import TableContainer from '@mui/material/TableContainer';
import TableHead from '@mui/material/TableHead';
import TablePagination from '@mui/material/TablePagination';
import TableRow from '@mui/material/TableRow';


const columns = [
  { id: 'name', label: 'Task Name', minWidth: 170 },
  { id: 'code', label: 'ID', minWidth: 100 },
  {
    id: 'population',
    label: 'Brand Name',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toLocaleString('en-US'),
  },
  {
    id: 'size',
    label: 'Tier',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toLocaleString('en-US'),
  },
  {
    id: 'density',
    label: 'Type',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Token Progress',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Target Reach Progress',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Budget',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Impressions',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Reach',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Engagement Rate',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Tokens Dispensed',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Stars Dispensed',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Tickets',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Bonus Set',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Tokens Added',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Viewers',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Incomplete',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Completed',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'Days Active',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'End Date',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
  {
    id: 'density',
    label: 'State',
    minWidth: 170,
    align: 'right',
    format: (value) => value.toFixed(2),
  },
];

function createData(name, code, population, size) {
  const density = population / size;
  return { name, code, population, size, density };
}

const rows = [
  createData('Blue Shoes', '10016', "Nike", "1", "Image", "4555/6000"),
  createData('Blue Shoes', '10016', "Nike", "1", "Image", "4555/6000"),
];

const App = () => {

  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };

  return (
    <div className='app'>
      <div className='container-fluid'>
        <div className='row'>
          <div className='col-md-12 p-0'>
            <div className='table_main_div'>
              <div className='ridim'>
                <h1 className='m-0 logo_div'>RIDIM</h1>

                <div className='profile_div'>
                  <div>
                    <img className='profile_img' src='/images/christophe-rollando-nEuT_lu_PzU-unsplash.jpg' alt='images' />
                  </div>
                  <div>
                    <p className='carlota_text'>Carlota Monteiro <span className='admin_div'>Admin</span></p>
                  </div>
                </div>

                <div>

                  <div className='mb-5'>
                    <h4>GENERAL</h4>
                  </div>

                  <div className='dase_div dasee_div'>
                    <div className=''>
                      <AdjustIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0'>Dashboard</h4>
                    </div>
                    <div className='icons_right'>
                      <ArrowForwardIosIcon />
                    </div>
                  </div>


                  <div className='dasee_div my-5'>
                    <div>
                      <h4 className='m-0'>MANAGEMENT</h4>
                    </div>
                  </div>


                  <div className='dase_div dasee_div'>
                    <div>
                      <PermIdentityIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0'>Users</h4>
                    </div>
                    <div className='icons_right'>
                      <ArrowForwardIosIcon />
                    </div>
                  </div>


                  <div className='dase_div dasee_div'>
                    <div>
                      <LocalGroceryStoreIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0'>Brands</h4>
                    </div>
                    <div className='icons_right'>
                      <ArrowForwardIosIcon />
                    </div>
                  </div>


                  <div className='dase_div dasee_div dasee_div'>
                    <div>
                      <TaskAltIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0'>Tasks</h4>
                    </div>
                    <div className='icons_right'>
                      <KeyboardArrowDownIcon fontSize="large" />
                    </div>
                  </div>


                  <div className='dase_divv dasee_div'>
                    <div>
                      <FiberManualRecordIcon sx={{ fontSize: 23 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Task</h4>
                    </div>
                  </div>


                  <div className='dase_divv dasee_div'>
                    <div>
                      <FiberManualRecordIcon sx={{ fontSize: 20 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Watch</h4>
                    </div>
                  </div>


                  <div className='dase_divv dasee_div'>
                    <div>
                      <FiberManualRecordIcon sx={{ fontSize: 17 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Questions</h4>
                    </div>
                  </div>


                  <div className='dase_divv dasee_div'>
                    <div>
                      <FiberManualRecordIcon sx={{ fontSize: 15 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Learn</h4>
                    </div>
                  </div>


                  <div className='dase_div my-5'>
                    <div>
                      <h4 className='m-0'>ADMIN</h4>
                    </div>
                  </div>


                  <div className='dase_divv dasee_div'>
                    <div className='mr-3'>
                      <EmojiEventsIcon sx={{ fontSize: 30 }} className='dot_divv' />
                    </div>
                    <div>
                      <h4 className='m-0'>Rewards</h4>
                    </div>
                  </div>


                  <div className='dase_div dasee_div'>
                    <div>
                      <TaskAltIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0'>Bouns</h4>
                    </div>
                    <div className='icons_right'>
                      <KeyboardArrowDownIcon fontSize="large" />
                    </div>
                  </div>


                  <div className='dase_divv dasee_div'>
                    <div>
                      <FiberManualRecordIcon sx={{ fontSize: 23 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Bouns Prizes</h4>
                    </div>
                  </div>


                  <div className='dase_divv dasee_div'>
                    <div>
                      <FiberManualRecordIcon sx={{ fontSize: 20 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Bouns Rules</h4>
                    </div>
                  </div>


                  <div className='dase_divv dasee_div'>
                    <div>
                      <FiberManualRecordIcon sx={{ fontSize: 17 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Bouns Set</h4>
                    </div>
                  </div>

                  <div className='dase_divv dasee_div'>
                    <div>
                      <TodayIcon sx={{ fontSize: 30 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Brand Score</h4>
                    </div>
                  </div>

                  <div className='dase_divv dasee_div'>
                    <div>
                      <TodayIcon sx={{ fontSize: 30 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Points</h4>
                    </div>
                  </div>

                  <div className='dase_divv dasee_div'>
                    <div>
                      <TodayIcon sx={{ fontSize: 30 }} className='dot_div' />
                    </div>
                    <div>
                      <h4 className='m-0'>Mini Tasks</h4>
                    </div>
                  </div>

                  <div className='dase_div my-5'>
                    <div>
                      <h4 className='m-0'>ADMIN</h4>
                    </div>
                  </div>


                  <div className='dase_div dasee_div'>
                    <div>
                      <InboxIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0 requst_text'>Inbox</h4>
                    </div>
                    <div className='icons_right'>
                      <ArrowForwardIosIcon className='right_divv' />
                    </div>
                  </div>


                  <div className='dase_div dasee_div'>
                    <div>
                      <BugReportIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0 requst_text'>Report</h4>
                    </div>
                    <div className='icons_right'>
                      <ArrowForwardIosIcon />
                    </div>
                  </div>

                  <div className='dase_div dasee_div'>
                    <div>
                      <SettingsIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0 requst_text'>Settings</h4>
                    </div>
                    <div className='icons_right'>
                      <ArrowForwardIosIcon />
                    </div>
                  </div>

                  <div className='dase_div dasee_div'>
                    <div>
                      <AppRegistrationIcon fontSize="large" />
                    </div>
                    <div>
                      <h4 className='m-0 requst_text'>Requests</h4>
                    </div>
                    <div className='icons_right'>
                      <ArrowForwardIosIcon />
                    </div>
                  </div>


                </div>

              </div>
              <div className='table_div'>
                <h1 className='nike_text'>Nike: Task</h1>

                <div className='mt-5 div_inputs'>
                  <div className='input_main_div'>
                    <form className='input_main'>
                      <SearchIcon />
                      <input className='input_search' type="search" placeholder="Search" />
                    </form>
                  </div>

                  <div className='d-flex'>
                    <div className='d-flex ml-3'>
                      <FilterListIcon className='mr-2' />
                      <h5 className='m-0'>Filters</h5>
                    </div>

                    <div className='d-flex mx-3'>
                      <ViewStreamIcon className='mr-2' />
                      <h5 className='m-0'>Density</h5>
                    </div>

                    <div className='d-flex'>
                      <DehazeIcon className='mr-2' />
                      <h5 className='m-0'>Columns</h5>
                    </div>
                  </div>
                </div>

                <div>

                  <Paper sx={{ width: '100%', overflow: 'hidden' }}>
                    <TableContainer sx={{ maxHeight: 440 }}>
                      <Table stickyHeader aria-label="sticky table">
                        <TableHead>
                          <TableRow>
                            {columns.map((column) => (
                              <TableCell
                                key={column.id}
                                align={column.align}
                                style={{ minWidth: column.minWidth }}
                              >
                                {column.label}
                              </TableCell>
                            ))}
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {rows
                            .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                            .map((row) => {
                              return (
                                <TableRow hover role="checkbox" tabIndex={-1} key={row.code}>
                                  {columns.map((column) => {
                                    const value = row[column.id];
                                    return (
                                      <TableCell key={column.id} align={column.align}>
                                        {column.format && typeof value === 'number'
                                          ? column.format(value)
                                          : value}
                                      </TableCell>
                                    );
                                  })}
                                </TableRow>
                              );
                            })}
                        </TableBody>
                      </Table>
                    </TableContainer>
                    <TablePagination
                      rowsPerPageOptions={[10, 25, 100]}
                      component="div"
                      count={rows.length}
                      rowsPerPage={rowsPerPage}
                      page={page}
                      onPageChange={handleChangePage}
                      onRowsPerPageChange={handleChangeRowsPerPage}
                    />
                  </Paper>




                </div>


              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default App