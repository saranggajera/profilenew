import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Home from './Component/Home/Home'
import Homepages from './Component/HomePage/Homepages'
import Profile from './Component/Profile/Profile'
import Register from './Component/Registerform/Register'

const App = () => {
  return (
    <div>
       <Routes>
          <Route path='/' element={<Home/>}/>
          <Route path='/homepages' element={<Homepages/>}/>
          <Route path='/register' element={<Register/>}/>
          <Route path='/profile' element={<Profile/>}/>
       </Routes>
    </div>
  )
}

export default App