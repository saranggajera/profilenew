import * as types from "./ActionsType"

const initialState = {
    users:[{name:"demo"}],
    loading: true,
}

const usersReducers = (state = initialState, action) => {
    switch (action.type) {
        case types.GET_USERS:
            return{
                ...state,
                users: action.payload,
                loading: false,
            }

            default:
        return state
    }
};

export default usersReducers;