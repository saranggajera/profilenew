import axios from 'axios'
import * as types from './ActionsType'


const getUsers = (users) => ({
    type: types.GET_USERS,
    payload: users,
})



export const loadUsers = () => {
    return function (dispatch) {

        axios.get("http://192.168.29.220:3001/user/userFind")
            .then((res) => {
                dispatch(getUsers(res.data.data[0]))
            })
            .catch((error) => {
                console.log("hello",error);
            })
    }
}