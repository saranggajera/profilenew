import React from 'react'
import Loginform from '../LoginForm/Loginform'

const Home = () => {
  return (
    <div>
        <Loginform/>
    </div>
  )
}

export default Home