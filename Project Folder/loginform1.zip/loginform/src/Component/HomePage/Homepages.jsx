import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { useDispatch, useSelector } from 'react-redux';
import { Link, useNavigate } from 'react-router-dom';
import { loadUsers } from '../../Redux/Actions';
import './home.css'

const Homepages = () => {

  const navigate = useNavigate()

  useEffect(() => {
    if (!localStorage.getItem('userlogin')) {
      navigate('/')
    }
  })

  
  var z = JSON.parse(localStorage.getItem("userlogin"))
  
  const logoutuser = () => {
    localStorage.removeItem("userlogin")
    navigate('/')

  }

  const {users} = useSelector(state => state.users)

  let dispatch = useDispatch();

    const click  = () => {
      dispatch(loadUsers())
    }



  return (
    <div className='homepages'>
      <div className='container'>
        <div className='row'>
          <div className='col-md-12 mt-2'>
            <div className='btn_divs'>
              <button className='btn btn-info mr-4' onClick={logoutuser}>Logout</button>


              <div className="dropdown">
                <button className="btn dropdown-toggle" type="button" data-toggle="dropdown" aria-expanded="false">
                  Dropdown button
                </button>
                <div className="dropdown-menu">
                  <a className="dropdown-item">UserName: {z.username}</a>
                  <a className="dropdown-item">Email: {z.email}</a>
                  <Link className="dropdown-item" to="/profile">Profile</Link>
                </div>
              </div>

            </div>
          </div>
        </div>
        <div className='row'>
          <div className='col-md-12'>
            <div className='user_namee'>
              <h2 className='wel'>welcome</h2>
              <p className='user_name'><span className='spen_div'>User Name:</span> {users.username}</p>
              <p className='user_name'><span className='spen_div'>Email:</span> {users.email}</p>
              <p className='user_name'><span className='spen_div'>Password:</span> {users.password}</p>
              <p className='user_name'><span className='spen_div'>C Password:</span> {users.cpassword}</p>
              <p className='user_name'><span className='spen_div'>Address:</span> {users.address}</p>
              <p className='user_name'><span className='spen_div'>Phone:</span> {users.phone}</p>
              <p className='user_name'><span className='spen_div'>Gender:</span> {users.gender}</p>
            </div>
          </div>
          <button className='btn btn-primary btn_div' onClick={click}>Data</button>
        </div>
      </div>
    </div>
  )
}

export default Homepages