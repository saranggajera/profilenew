import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import './login.css'

const Loginform = () => {

    const navigate = useNavigate()    

    useEffect(() => {
        if (localStorage.getItem('userlogin')) {
            navigate('/homepages')
        }
    }, [])

    const [userlog, setUserlog] = useState({
        username: "",
        password: ""
    })

    

    const userlogin = (event) => {
        const name = event.target.name
        const value = event.target.value

        console.log(name, value)

        setUserlog({ ...userlog, [name]: value })
    }

    const onlogin = async (event) => {
        event.preventDefault()
        console.log(userlog)

        await axios.post("http://192.168.29.220:3001/user/login", userlog)
            .then((res) => {
                console.log(res);

                if (res.status === 200) {
                    navigate("/homepages")
                    localStorage.setItem("userlogin",JSON.stringify(res.data.data))
                }

                setUserlog({
                    username: "",
                    password: ""
                })
            })
            .catch((error) => {
                console.log(error);
            })
    }

    return (
        <div className='main'>
            <div className="backgroundd">
                <div className="shapee"></div>
                <div className="shapee"></div>
            </div>
            <form className='login_form' onSubmit={onlogin}>
                <h3>Login Here</h3>

                <label className='lable_log' for="username">Username</label>
                <input type="text" placeholder="Enter User Name" name='username' value={userlog.username} onChange={userlogin} id="username" />

                <label className='lable_log' for="password">Password</label>
                <input type="password" placeholder="Enter Password" name='password' value={userlog.password} onChange={userlogin} id="password" />

                <button className='log_btn'>Log In</button>

                <div className='text-center mt-4'>
                    <p>Don't have account?<Link to='/register' className='reage_div'>Register</Link></p>
                </div>
            </form>
        </div>
    )
}

export default Loginform