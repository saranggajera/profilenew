import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import './register.css'

const Register = () => {

    const navigate = useNavigate()

    useEffect(() =>{
        if(localStorage.getItem('userlogin')){
            navigate('/homepages')
        }
    })

    

    const [reg, setReg] = useState({
        username: "",
        email: "",
        password: "",
        cpassword: ""
    })


    const reguser = (event) => {
        const name = event.target.name
        const value = event.target.value

        // console.log(name, value)

        setReg({ ...reg, [name]: value })
    }

    const onsubreg = async (event) => {
        event.preventDefault()
        console.log(reg)

        await axios.post("http://192.168.29.220:3001/user/register", reg)
            .then((res) => {
                console.log("cccc", res.status);
                if (res.status === 200) {
                    navigate('/')
                }
                setReg({
                    username: "",
                    email: "",
                    password: "",
                    cpassword: ""
                })
            })
            .catch((error) => {
                console.log(error);
            })
    }


    return (
        <div className='Register main'>
            <div className="background">
                <div className="shape"></div>
                <div className="shape"></div>
            </div>
            <form className='regi_form' onSubmit={onsubreg}>
                <h3>Register Here</h3>

                <label className='lable_reg' for="exampleInputnamel1">User Name</label>
                <input type="text" className="form-controll" name='username' value={reg.username} onChange={reguser} id="exampleInputName1" aria-describedby="nameHelp" placeholder="Enter User Name" />


                <label className='lable_reg' for="exampleInputEmail1">Email</label>
                <input type="email" className="form-controll" name='email' value={reg.email} onChange={reguser} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />


                <label className='lable_reg' for="exampleInputPassword1">Password</label>
                <input type="password" className="form-controll" name='password' value={reg.password} onChange={reguser} id="exampleInputPassword1" placeholder="Password" />

                <label className='lable_reg' for="exampleInputPassword1">Confirm Password</label>
                <input type="password" className="form-controll" name='cpassword' value={reg.cpassword} onChange={reguser} id="exampleInputPassword1" placeholder="Confirm Password" />

                <button type="submit" className="reg_btn">Register</button>
                <p className='text-center mt-4'>Already have an account?<Link to='/' className='reage_div'>Login</Link></p>
            </form>
        </div>
    )
}

export default Register