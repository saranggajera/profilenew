import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useSelector } from 'react-redux'
import { json, useNavigate } from 'react-router-dom'
import './profile.css'

const Profile = () => {

    const navigate = useNavigate()

    const {users} = useSelector(state => state.users)

    const [profile, setProfile] = useState({
        username: users.username,
        email: users.email,
        password: users.password,
        cpassword: users.cpassword,
        address: users.address,
        phone: users.phone,
        gender: users.gender
    })

    const profilecha = (event) => {
        const name = event.target.name
        const value = event.target.value

        console.log(name, value)

        setProfile({ ...profile, [name]: value })
    }

    const subprofile = async (event) => {
        event.preventDefault()
        console.log(profile)

        await axios.post("http://192.168.29.220:3001/user/userUpdate", profile)
            .then((res) => {

                if (res.status === 200) {
                    navigate("/homepages")
                }
                setProfile({
                    username: "",
                    email: "",
                    password: "",
                    cpassword: "",
                    address: "",
                    phone: "",
                    gender: ""
                })
            })
            .catch((error) => {
            })
    }


    return (
        <div className='profile'>
            <div className='container'>
                <div className='row'>
                    <div className='col-md-12'>
                        <div className="backgrounds">
                            <div className="shapes"></div>
                            <div className="shapes"></div>
                        </div>
                        <form className='regi_forms' onSubmit={subprofile}>
                            <h3>Profile Update</h3>

                            <label className='lable_reg' for="exampleInputnamel1">User Name</label>
                            <input type="text" className="form-controll" value={profile.username} name='username' onChange={profilecha} id="exampleInputName1" aria-describedby="nameHelp" placeholder="Enter User Name" />


                            <label className='lable_reg' for="exampleInputEmail1">Email</label>
                            <input type="email" className="form-controll" value={profile.email} name='email' onChange={profilecha} id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />


                            <div className='d-flex justify-content-between'>
                                <div>
                                    <label className='lable_reg' for="exampleInputPassword1">Password</label>
                                    <input type="text" className="form-controll" value={profile.password} name='password' onChange={profilecha} id="exampleInputPassword1" placeholder="Password" />
                                </div>

                                <div>
                                    <label className='lable_reg' for="exampleInputPasswor1">Confirm Password</label>
                                    <input type="text" className="form-controll" value={profile.password} name='cpassword' onChange={profilecha} id="exampleInputPasswor1" placeholder="Confirm Password" />
                                </div>

                            </div>

                            <label className='lable_reg' for="exampleInputAddress1">Address</label>
                            <input type="text" className="form-controll" value={profile.address} name='address' onChange={profilecha} id="exampleInputAddress1" placeholder="Enter Address" />

                            <div className='d-flex justify-content-between'>

                                <div>
                                    <label className='lable_reg' for="exampleInputPhone1">Phone</label>
                                    <input type="number" className="form-controll" value={profile.phone} name='phone' onChange={profilecha} id="exampleInputPhone1" placeholder="Enter Phone Number" />
                                </div>

                                <div>
                                    <label className='lable_reg' for="exampleInputGender1">Gender</label>
                                    <input type="text" className="form-controll" value={profile.gender} name='gender' onChange={profilecha} id="exampleInputGenders1" placeholder="Enter Gender" />
                                </div>

                            </div>

                            <button type="submit" className="reg_btn">Update</button>
                        </form>
                    </div>
                </div>
            </div>

        </div>
    )
}

export default Profile