import React from 'react'
import { Route, Routes } from 'react-router-dom'
import Chawkbazarhome from './Component/ChawkbazarHome/Chawkbazarhome'
import Shops from './Component/Pagechawkbazar/Shops/Shops'
import Woman from './Component/Pagechawkbazar/Woman/Woman'
import Man from './Component/Pagechawkbazar/Man/Man'
import Watch from './Component/Pagechawkbazar/Watch/Watch'
import Kids from './Component/Pagechawkbazar/Kids/Kids'
import Sports from './Component/Pagechawkbazar/Sports/Sports'
import Sunglass from './Component/Pagechawkbazar/Sunglass/Sunglass'
import Bags from './Component/Pagechawkbazar/Bags/Bags'
import Sneakers from './Component/Pagechawkbazar/Sneakers/Sneakers'
import Tshirt from './Component/Pagechawkbazar/MenwearTshirt/Tshirt'
import Maniac from './Component/Pagechawkbazar/Maniac/Maniac'



const App = () => {
  return (
    <div>
       <Routes>
          <Route path='/' element={<Chawkbazarhome/>}/>
          <Route path='/shops' element={<Shops/>}/>
          <Route path='/woman' element={<Woman/>}/>
          <Route path='/man' element={<Man/>}/>
          <Route path='/watch' element={<Watch/>}/>
          <Route path='/kids' element={<Kids/>}/>
          <Route path='/sports' element={<Sports/>}/>
          <Route path='/sunglass' element={<Sunglass/>}/>
          <Route path='/bags' element={<Bags/>}/>
          <Route path='/sneakers' element={<Sneakers/>}/>
          <Route path='/tshirt' element={<Tshirt/>}/>
          <Route path='/maniac' element={<Maniac/>}/>
       </Routes>
    </div>
    // container_div
  )
}

export default App