export const Woomann = [
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fwoman.jpg&w=64&q=75",
        title: "Woman",
        text: "20",
        link:"/woman"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fman.jpg&w=64&q=75",
        title: "Man",
        text: "20",
        link:"/man"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fwatch.jpg&w=64&q=75",
        title: "Watch",
        text: "20",
        link:"/watch"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fkid.jpg&w=64&q=75",
        title: "Kids",
        text: "20",
        link:"/kids"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fsports.jpg&w=64&q=75",
        title: "Sports",
        text: "20",
        link:"/sports"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fsunglass.jpg&w=64&q=75",
        title: "Sunglass",
        text: "20",
        link:"/sunglass"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fbags.jpg&w=64&q=75",
        title: "Bags",
        text: "20",
        link:"/bags"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fsneakers.jpg&w=64&q=75",
        title: "Sneakers",
        text: "20"
        ,link:"/sneakers"
    },
]


export const topproducts = [
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=384&q=100",
        title: "Maniac Red Boys",
        text: "Sporty essentials, these Under Armo...",
        reate: "$15.00$ 20.00"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-22-s.png&w=384&q=100",
        title: "Maniac Red Boys",
        text: "Sporty essentials, these Under Armo...",
        reate: "$15.00$ 20.00"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-25-s.png&w=384&q=100",
        title: "Maniac Red Boys",
        text: "Sporty essentials, these Under Armo...",
        reate: "$15.00$ 20.00"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-24-s.png&w=384&q=100",
        title: "Maniac Red Boys",
        text: "Sporty essentials, these Under Armo...",
        reate: "$15.00",
    },
]

export const BestSellers = [
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-1.png&w=384&q=100",
        title: "Nike Black",
        text: "Casual wear (casual attire or clot...",
        rate: "$11.00",
        noreat: "$15.000"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-2.png&w=384&q=100",
        title: "Hermes Carlton London",
        text: "Off-White self-striped knitted midi...",
        rate: "$12.30",
        noreat: "$16.38"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-8.png&w=384&q=100",
        title: "Gucci Carlton UK",
        text: "Knitted midi A-line dress, has a sc...",
        rate: "$14.99",
        noreat: "$19.99"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-4.png&w=384&q=100",
        title: "Regular Fit Flannel Shirt",
        text: "The garments labelled as Commit...",
        rate: "$8.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-5.png&w=384&q=100",
        title: "12 Eco-Friendly Clothing Bran",
        text: "12 Eco-Friendly Clothing Brands",
        rate: "$20.00",
        noreat: "$28.00"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-6.png&w=384&q=100",
        title: "Oversized W Sweater",
        text: "Constructed in cotton sweat fabric...",
        rate: "$55.00",
        noreat: "$70.00"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-7.png&w=384&q=100",
        title: "Regular Fit Crew-neck T-shirt",
        text: "Self-striped knitted midi A-line dress...",
        rate: "$12.30",
        noreat: "$16.38"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-3.png&w=384&q=100",
        title: "Zara Shoes Green",
        text: "Footwear refers to garments worn...",
        rate: "$50.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-9.png&w=384&q=100",
        title: "Women Fitted Neck T-Shirt",
        text: "All about the crisp cut and excep...",
        rate: "$28.00",
        noreat: "$30.00"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-10.png&w=384&q=100",
        title: "NIKE Shoes",
        text: "NIKE 2020 Black White is a clean...",
        rate: "$39.99",
    },
]


export const newarrivals = [
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-11.png&w=384&q=100",
        title: "Armani Veni Vidi Vici",
        text: "Fendi began life in 1925 as a fur an",
        rat: "$17.99",
        noreat: "$20.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-22.png&w=384&q=100",
        title: "H&M Global Desi",
        text: "Blue solid woven regular top, cu",
        rat: "$30.00",
        noreat: "$40.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-18.png&w=384&q=100",
        title: "Zara Solly White Shirt",
        text: "For a chic and smart look, don t",
        rat: "$25.00",
        noreat: "$32.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-14.png&w=384&q=100",
        title: "Hermes Carlton London",
        text: "Off-White self-striped knitted midi",
        rat: "$15.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-15.png&w=384&q=100",
        title: "Scuba Stand Collar Topper J",
        text: "Zara provides only the highest-q",
        rat: "$12.00",
        noreat: "$16.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-16.png&w=384&q=100",
        title: "Armani Wide-Leg Trousers",
        text: "Monochrome elegance. Made with a",
        rat: "$60.00",
        noreat: "$80.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-17.png&w=384&q=100",
        title: "Short Sleeve Shirts For Men",
        text: "From casual days out to parties,",
        rat: "$12.99",
        noreat: "$18.99",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-13.png&w=384&q=100",
        title: "Blazer And A Neck Scarf",
        text: "blue short sleeve basic midi dress",
        rat: "$13.00",
        noreat: "$23.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-19.png&w=384&q=100",
        title: "Zara Shoes Green",
        text: "Footwear refers to garments worn on ",
        rat: "$250.00",
        noreat: "$300.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=384&q=100",
        title: "Maniac Red Boys",
        text: "Sporty essentials, these Under Ar",
        rat: "$15.00",
        noreat: "$20.00",
    },
]


export const slider = [
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-11.png&w=384&q=100",
        title: "Armani Veni Vidi Vici",
        text: "Fendi began life in 1925 as a fur an",
        rat: "$17.99",
        noreat: "$20.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-22.png&w=384&q=100",
        title: "H&M Global Desi",
        text: "Blue solid woven regular top, cu",
        rat: "$30.00",
        noreat: "$40.00",
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-18.png&w=384&q=100",
        title: "Zara Solly White Shirt",
        text: "For a chic and smart look, don t",
        rat: "$25.00",
        noreat: "$32.00",
    },
]

export const guaranteed = [
    {
        imgaes: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Ffeature%2Fsaving.svg&w=96&q=75",
        title: "Guaranteed Savings",
        text: "If you don’t make your membership fee in savings, we’ll refund the difference",
    },
    {
        imgaes: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Ffeature%2Frisk-free.svg&w=96&q=75",
        title: "Try it risk-free",
        text: "If you don’t make your membership fee in savings, we’ll refund the difference",
    },
    {
        imgaes: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Ffeature%2Fdelivery.svg&w=96&q=75",
        title: "Super Fast Delivery",
        text: "If you don’t make your membership fee in savings, we’ll refund the difference",
    },
    {
        imgaes: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Ffeature%2Fproduct.svg&w=96&q=75",
        title: "1000+ products priced at cost",
        text: "If you don’t make your membership fee in savings, we’ll refund the difference",
    },
]


export const Super = [
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-1.jpg&w=1920&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-2.jpg&w=3840&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-3.jpg&w=3840&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-4.jpg&w=1920&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-5.jpg&w=1920&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-6.jpg&w=1920&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-7.jpg&w=1920&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-8.jpg&w=1920&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
    {
        images: "https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fshop%2Fshop-logo-9.jpg&w=1920&q=75",
        title: "Area 365 Mart",
        text: "115 E 9th St, New York, CA 90079,USA",
        button: "NEW"
    },
]


export const product = [
    {
       images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-1.png&w=384&q=100",
       title:"Nike Black",
       text:"Casual wear (casual attire or clothing) may be a Western code that’s relaxed, occasional, spontaneous and fitted to everyday use. Casual wear became popular within the Western world",
       prize:"$11.00",
       noprize:"$15.00" 
    },
    {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-2.png&w=384&q=100",
        title:"Hermes Carlton London",
        text:"Off-White self-striped knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
        prize:"$12.30",
        noprize:"$16.38" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-3.png&w=384&q=100",
        title:"Zara Shoes Green",
        text:"Footwear refers to garments worn on the feet, which originally serves to purpose of protection against adversities of the environment, usually regarding ground textures and temperature.",
        prize:"$50.00", 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-4.png&w=384&q=100",
        title:"Regular Fit Flannel Shirt",
        text:"The garments labelled as Committed are products that have been produced using sustainable fibers or processes, reducing their environmental impact. Mango's goal is to support the implementation of practices more committed to the environment.",
        prize:"$8.00",
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-5.png&w=384&q=100",
        title:"The garments labelled as Committed are products that have been produced using sustainable fibers or processes, reducing their environmental impact. Mango's goal is to support the implementation of practices more committed to the environment.",
        text:"12 Eco-Friendly Clothing Brands That, has a scoop neck, sleeveless, straight hem",
        prize:"$20.00",
        noprize:"$28.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-6.png&w=384&q=100",
        title:"Oversized W Sweater",
        text:"Constructed in cotton sweat fabric, this lovely piece, lacus eu mattis auctor, dolor lectus venenatis nulla, at tristique eros sem vel ante. Sed leo enim, iaculis ornare tristique non, vulputate sit amet ante.",
        prize:"$55.00",
        noprize:"$70.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-7.png&w=384&q=100",
        title:"Regular Fit Crew-neck T-shirt",
        text:"Self-striped knitted midi A-line dress, has a scoop neck, T-shirt, straight hem",
        prize:"$12.30",
        noprize:"$16.38" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-8.png&w=384&q=100",
        title:"Gucci Carlton UK",
        text:"Knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
        prize:"$14.99",
        noprize:"$19.99" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-9.png&w=384&q=100",
        title:"Women Fitted Neck T-Shirt",
        text:"All about the crisp cut and exceptional quality of the cotton, the Women Fitted V Neck Rib L/S T-Shirt won’t be one you’ll be tossing away ever.",
        prize:"$28.00",
        noprize:"$30.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-10.png&w=384&q=100",
        title:"NIKE Shoes",
        text:"NIKE 2020 Black White is a clean and monochromatic colourway of the label’s latest high-technology silhouette. The model first launched late last year and is currently Jordan Brand’s flagship performance pair.",
        prize:"$39.99",
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-11.png&w=384&q=100",
        title:"Armani Veni Vidi Vici",
        text:"Fendi began life in 1925 as a fur and leather speciality store in Rome.",
        prize:"$17.99",
        noprize:"$20.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-13.png&w=384&q=100",
        title:"Blazer And A Neck Scarf",
        text:"blue short sleeve basic midi dress featuring a crew neckline in a jersey fabric.",
        prize:"$13.00",
        noprize:"$23.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-14.png&w=750&q=100",
        title:"Hermes Carlton London",
        text:"Off-White self-striped knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
        prize:"$15.00", 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-15.png&w=750&q=100",
        title:"Scuba Stand Collar Topper Jacket",
        text:"Zara provides only the highest-quality selection of dresses, womens suits, and suited separates.",
        prize:"$12.00",
        noprize:"$16.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-16.png&w=750&q=100",
        title:"Armani Wide-Leg Trousers",
        text:"Monochrome elegance. Made with a relaxed wide-leg, these trousers are made from a sustainable soft organic cotton with a mechanical stretch making the garment easily recycled.",
        prize:"$60.00",
        noprize:"$80.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-17.png&w=750&q=100",
        title:"Short Sleeve Shirts For Men",
        text:"From casual days out to parties, dinners and other events that call for a dressier look, a short sleeve shirt is a versatile piece that works for all kinds of occasions.",
        prize:"$12.99",
        noprize:"$18.99" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-18.png&w=750&q=100",
        title:"Zara Solly White Shirt",
        text:"For a chic and smart look, don this white shirt from Solly by Allen Solly. Crafted from a cotton-nylon blend with a hint of stretch, this design features a dotted pattern. Wear this 3/4th sleeves shirt with trousers and wedges to a client meeting.",
        prize:"$25.00",
        noprize:"$32.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-19.png&w=750&q=100",
        title:"Zara Shoes Green",
        text:"Footwear refers to garments worn on the feet, which originally serves to purpose of protection against adversities of the environment, usually regarding ground textures and temperature.",
        prize:"$250.00",
        noprize:"$300.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=750&q=100",
        title:"Maniac Red Boys",
        text:"Sporty essentials, these Under Armour athletic shorts are smooth and lightweight in moisture-wicking material.",
        prize:"$15.00",
        noprize:"$20.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-22.png&w=750&q=100",
        title:"H&M Global Desi",
        text:"Blue solid woven regular top, curved hem with tassell detailing has shoulder straps, and sleeveless",
        prize:"$30.00",
        noprize:"$40.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-1.png&w=384&q=100",
        title:"Nike Black",
        text:"Casual wear (casual attire or clothing) may be a Western code that’s relaxed, occasional, spontaneous and fitted to everyday use. Casual wear became popular within the Western world",
        prize:"$11.00",
        noprize:"$15.00" 
     },
     {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-2.png&w=384&q=100",
         title:"Hermes Carlton London",
         text:"Off-White self-striped knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
         prize:"$12.30",
         noprize:"$16.38" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-3.png&w=384&q=100",
         title:"Zara Shoes Green",
         text:"Footwear refers to garments worn on the feet, which originally serves to purpose of protection against adversities of the environment, usually regarding ground textures and temperature.",
         prize:"$50.00", 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-4.png&w=384&q=100",
         title:"Regular Fit Flannel Shirt",
         text:"The garments labelled as Committed are products that have been produced using sustainable fibers or processes, reducing their environmental impact. Mango's goal is to support the implementation of practices more committed to the environment.",
         prize:"$8.00",
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-5.png&w=384&q=100",
         title:"The garments labelled as Committed are products that have been produced using sustainable fibers or processes, reducing their environmental impact. Mango's goal is to support the implementation of practices more committed to the environment.",
         text:"12 Eco-Friendly Clothing Brands That, has a scoop neck, sleeveless, straight hem",
         prize:"$20.00",
         noprize:"$28.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-6.png&w=384&q=100",
         title:"Oversized W Sweater",
         text:"Constructed in cotton sweat fabric, this lovely piece, lacus eu mattis auctor, dolor lectus venenatis nulla, at tristique eros sem vel ante. Sed leo enim, iaculis ornare tristique non, vulputate sit amet ante.",
         prize:"$55.00",
         noprize:"$70.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-7.png&w=384&q=100",
         title:"Regular Fit Crew-neck T-shirt",
         text:"Self-striped knitted midi A-line dress, has a scoop neck, T-shirt, straight hem",
         prize:"$12.30",
         noprize:"$16.38" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-8.png&w=384&q=100",
         title:"Gucci Carlton UK",
         text:"Knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
         prize:"$14.99",
         noprize:"$19.99" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-9.png&w=384&q=100",
         title:"Women Fitted Neck T-Shirt",
         text:"All about the crisp cut and exceptional quality of the cotton, the Women Fitted V Neck Rib L/S T-Shirt won’t be one you’ll be tossing away ever.",
         prize:"$28.00",
         noprize:"$30.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-10.png&w=384&q=100",
         title:"NIKE Shoes",
         text:"NIKE 2020 Black White is a clean and monochromatic colourway of the label’s latest high-technology silhouette. The model first launched late last year and is currently Jordan Brand’s flagship performance pair.",
         prize:"$39.99",
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-11.png&w=384&q=100",
         title:"Armani Veni Vidi Vici",
         text:"Fendi began life in 1925 as a fur and leather speciality store in Rome.",
         prize:"$17.99",
         noprize:"$20.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-13.png&w=384&q=100",
         title:"Blazer And A Neck Scarf",
         text:"blue short sleeve basic midi dress featuring a crew neckline in a jersey fabric.",
         prize:"$13.00",
         noprize:"$23.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-14.png&w=750&q=100",
         title:"Hermes Carlton London",
         text:"Off-White self-striped knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
         prize:"$15.00", 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-15.png&w=750&q=100",
         title:"Scuba Stand Collar Topper Jacket",
         text:"Zara provides only the highest-quality selection of dresses, womens suits, and suited separates.",
         prize:"$12.00",
         noprize:"$16.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-16.png&w=750&q=100",
         title:"Armani Wide-Leg Trousers",
         text:"Monochrome elegance. Made with a relaxed wide-leg, these trousers are made from a sustainable soft organic cotton with a mechanical stretch making the garment easily recycled.",
         prize:"$60.00",
         noprize:"$80.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-17.png&w=750&q=100",
         title:"Short Sleeve Shirts For Men",
         text:"From casual days out to parties, dinners and other events that call for a dressier look, a short sleeve shirt is a versatile piece that works for all kinds of occasions.",
         prize:"$12.99",
         noprize:"$18.99" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-18.png&w=750&q=100",
         title:"Zara Solly White Shirt",
         text:"For a chic and smart look, don this white shirt from Solly by Allen Solly. Crafted from a cotton-nylon blend with a hint of stretch, this design features a dotted pattern. Wear this 3/4th sleeves shirt with trousers and wedges to a client meeting.",
         prize:"$25.00",
         noprize:"$32.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-19.png&w=750&q=100",
         title:"Zara Shoes Green",
         text:"Footwear refers to garments worn on the feet, which originally serves to purpose of protection against adversities of the environment, usually regarding ground textures and temperature.",
         prize:"$250.00",
         noprize:"$300.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=750&q=100",
         title:"Maniac Red Boys",
         text:"Sporty essentials, these Under Armour athletic shorts are smooth and lightweight in moisture-wicking material.",
         prize:"$15.00",
         noprize:"$20.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-22.png&w=750&q=100",
         title:"H&M Global Desi",
         text:"Blue solid woven regular top, curved hem with tassell detailing has shoulder straps, and sleeveless",
         prize:"$30.00",
         noprize:"$40.00" 
      },
]



export const casual = [
    {
       images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-1.png&w=384&q=100",
       title:"Nike Black",
       text:"Casual wear (casual attire or clothing) may be a Western code that’s relaxed, occasional, spontaneous and fitted to everyday use. Casual wear became popular within the Western world",
       prize:"$11.00",
       noprize:"$15.00" 
    },
    {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-2.png&w=384&q=100",
        title:"Hermes Carlton London",
        text:"Off-White self-striped knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
        prize:"$12.30",
        noprize:"$16.38" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-3.png&w=384&q=100",
        title:"Zara Shoes Green",
        text:"Footwear refers to garments worn on the feet, which originally serves to purpose of protection against adversities of the environment, usually regarding ground textures and temperature.",
        prize:"$50.00", 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-4.png&w=384&q=100",
        title:"Regular Fit Flannel Shirt",
        text:"The garments labelled as Committed are products that have been produced using sustainable fibers or processes, reducing their environmental impact. Mango's goal is to support the implementation of practices more committed to the environment.",
        prize:"$8.00",
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-5.png&w=384&q=100",
        title:"The garments labelled as Committed are products that have been produced using sustainable fibers or processes, reducing their environmental impact. Mango's goal is to support the implementation of practices more committed to the environment.",
        text:"12 Eco-Friendly Clothing Brands That, has a scoop neck, sleeveless, straight hem",
        prize:"$20.00",
        noprize:"$28.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-6.png&w=384&q=100",
        title:"Oversized W Sweater",
        text:"Constructed in cotton sweat fabric, this lovely piece, lacus eu mattis auctor, dolor lectus venenatis nulla, at tristique eros sem vel ante. Sed leo enim, iaculis ornare tristique non, vulputate sit amet ante.",
        prize:"$55.00",
        noprize:"$70.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-7.png&w=384&q=100",
        title:"Regular Fit Crew-neck T-shirt",
        text:"Self-striped knitted midi A-line dress, has a scoop neck, T-shirt, straight hem",
        prize:"$12.30",
        noprize:"$16.38" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-8.png&w=384&q=100",
        title:"Gucci Carlton UK",
        text:"Knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
        prize:"$14.99",
        noprize:"$19.99" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-9.png&w=384&q=100",
        title:"Women Fitted Neck T-Shirt",
        text:"All about the crisp cut and exceptional quality of the cotton, the Women Fitted V Neck Rib L/S T-Shirt won’t be one you’ll be tossing away ever.",
        prize:"$28.00",
        noprize:"$30.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-10.png&w=384&q=100",
        title:"NIKE Shoes",
        text:"NIKE 2020 Black White is a clean and monochromatic colourway of the label’s latest high-technology silhouette. The model first launched late last year and is currently Jordan Brand’s flagship performance pair.",
        prize:"$39.99",
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-11.png&w=384&q=100",
        title:"Armani Veni Vidi Vici",
        text:"Fendi began life in 1925 as a fur and leather speciality store in Rome.",
        prize:"$17.99",
        noprize:"$20.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-13.png&w=384&q=100",
        title:"Blazer And A Neck Scarf",
        text:"blue short sleeve basic midi dress featuring a crew neckline in a jersey fabric.",
        prize:"$13.00",
        noprize:"$23.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-14.png&w=750&q=100",
        title:"Hermes Carlton London",
        text:"Off-White self-striped knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
        prize:"$15.00", 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-15.png&w=750&q=100",
        title:"Scuba Stand Collar Topper Jacket",
        text:"Zara provides only the highest-quality selection of dresses, womens suits, and suited separates.",
        prize:"$12.00",
        noprize:"$16.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-16.png&w=750&q=100",
        title:"Armani Wide-Leg Trousers",
        text:"Monochrome elegance. Made with a relaxed wide-leg, these trousers are made from a sustainable soft organic cotton with a mechanical stretch making the garment easily recycled.",
        prize:"$60.00",
        noprize:"$80.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-17.png&w=750&q=100",
        title:"Short Sleeve Shirts For Men",
        text:"From casual days out to parties, dinners and other events that call for a dressier look, a short sleeve shirt is a versatile piece that works for all kinds of occasions.",
        prize:"$12.99",
        noprize:"$18.99" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-18.png&w=750&q=100",
        title:"Zara Solly White Shirt",
        text:"For a chic and smart look, don this white shirt from Solly by Allen Solly. Crafted from a cotton-nylon blend with a hint of stretch, this design features a dotted pattern. Wear this 3/4th sleeves shirt with trousers and wedges to a client meeting.",
        prize:"$25.00",
        noprize:"$32.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-19.png&w=750&q=100",
        title:"Zara Shoes Green",
        text:"Footwear refers to garments worn on the feet, which originally serves to purpose of protection against adversities of the environment, usually regarding ground textures and temperature.",
        prize:"$250.00",
        noprize:"$300.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=750&q=100",
        title:"Maniac Red Boys",
        text:"Sporty essentials, these Under Armour athletic shorts are smooth and lightweight in moisture-wicking material.",
        prize:"$15.00",
        noprize:"$20.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-22.png&w=750&q=100",
        title:"H&M Global Desi",
        text:"Blue solid woven regular top, curved hem with tassell detailing has shoulder straps, and sleeveless",
        prize:"$30.00",
        noprize:"$40.00" 
     },
     {
        images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-1.png&w=384&q=100",
        title:"Nike Black",
        text:"Casual wear (casual attire or clothing) may be a Western code that’s relaxed, occasional, spontaneous and fitted to everyday use. Casual wear became popular within the Western world",
        prize:"$11.00",
        noprize:"$15.00" 
     },
     {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-2.png&w=384&q=100",
         title:"Hermes Carlton London",
         text:"Off-White self-striped knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
         prize:"$12.30",
         noprize:"$16.38" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-3.png&w=384&q=100",
         title:"Zara Shoes Green",
         text:"Footwear refers to garments worn on the feet, which originally serves to purpose of protection against adversities of the environment, usually regarding ground textures and temperature.",
         prize:"$50.00", 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-4.png&w=384&q=100",
         title:"Regular Fit Flannel Shirt",
         text:"The garments labelled as Committed are products that have been produced using sustainable fibers or processes, reducing their environmental impact. Mango's goal is to support the implementation of practices more committed to the environment.",
         prize:"$8.00",
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-5.png&w=384&q=100",
         title:"The garments labelled as Committed are products that have been produced using sustainable fibers or processes, reducing their environmental impact. Mango's goal is to support the implementation of practices more committed to the environment.",
         text:"12 Eco-Friendly Clothing Brands That, has a scoop neck, sleeveless, straight hem",
         prize:"$20.00",
         noprize:"$28.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-6.png&w=384&q=100",
         title:"Oversized W Sweater",
         text:"Constructed in cotton sweat fabric, this lovely piece, lacus eu mattis auctor, dolor lectus venenatis nulla, at tristique eros sem vel ante. Sed leo enim, iaculis ornare tristique non, vulputate sit amet ante.",
         prize:"$55.00",
         noprize:"$70.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-7.png&w=384&q=100",
         title:"Regular Fit Crew-neck T-shirt",
         text:"Self-striped knitted midi A-line dress, has a scoop neck, T-shirt, straight hem",
         prize:"$12.30",
         noprize:"$16.38" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-8.png&w=384&q=100",
         title:"Gucci Carlton UK",
         text:"Knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
         prize:"$14.99",
         noprize:"$19.99" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-9.png&w=384&q=100",
         title:"Women Fitted Neck T-Shirt",
         text:"All about the crisp cut and exceptional quality of the cotton, the Women Fitted V Neck Rib L/S T-Shirt won’t be one you’ll be tossing away ever.",
         prize:"$28.00",
         noprize:"$30.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-10.png&w=384&q=100",
         title:"NIKE Shoes",
         text:"NIKE 2020 Black White is a clean and monochromatic colourway of the label’s latest high-technology silhouette. The model first launched late last year and is currently Jordan Brand’s flagship performance pair.",
         prize:"$39.99",
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-11.png&w=384&q=100",
         title:"Armani Veni Vidi Vici",
         text:"Fendi began life in 1925 as a fur and leather speciality store in Rome.",
         prize:"$17.99",
         noprize:"$20.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-13.png&w=384&q=100",
         title:"Blazer And A Neck Scarf",
         text:"blue short sleeve basic midi dress featuring a crew neckline in a jersey fabric.",
         prize:"$13.00",
         noprize:"$23.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-14.png&w=750&q=100",
         title:"Hermes Carlton London",
         text:"Off-White self-striped knitted midi A-line dress, has a scoop neck, sleeveless, straight hem",
         prize:"$15.00", 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-15.png&w=750&q=100",
         title:"Scuba Stand Collar Topper Jacket",
         text:"Zara provides only the highest-quality selection of dresses, womens suits, and suited separates.",
         prize:"$12.00",
         noprize:"$16.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-16.png&w=750&q=100",
         title:"Armani Wide-Leg Trousers",
         text:"Monochrome elegance. Made with a relaxed wide-leg, these trousers are made from a sustainable soft organic cotton with a mechanical stretch making the garment easily recycled.",
         prize:"$60.00",
         noprize:"$80.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-17.png&w=750&q=100",
         title:"Short Sleeve Shirts For Men",
         text:"From casual days out to parties, dinners and other events that call for a dressier look, a short sleeve shirt is a versatile piece that works for all kinds of occasions.",
         prize:"$12.99",
         noprize:"$18.99" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-18.png&w=750&q=100",
         title:"Zara Solly White Shirt",
         text:"For a chic and smart look, don this white shirt from Solly by Allen Solly. Crafted from a cotton-nylon blend with a hint of stretch, this design features a dotted pattern. Wear this 3/4th sleeves shirt with trousers and wedges to a client meeting.",
         prize:"$25.00",
         noprize:"$32.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-19.png&w=750&q=100",
         title:"Zara Shoes Green",
         text:"Footwear refers to garments worn on the feet, which originally serves to purpose of protection against adversities of the environment, usually regarding ground textures and temperature.",
         prize:"$250.00",
         noprize:"$300.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=750&q=100",
         title:"Maniac Red Boys",
         text:"Sporty essentials, these Under Armour athletic shorts are smooth and lightweight in moisture-wicking material.",
         prize:"$15.00",
         noprize:"$20.00" 
      },
      {
         images:"https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-22.png&w=750&q=100",
         title:"H&M Global Desi",
         text:"Blue solid woven regular top, curved hem with tassell detailing has shoulder straps, and sleeveless",
         prize:"$30.00",
         noprize:"$40.00" 
      },
]