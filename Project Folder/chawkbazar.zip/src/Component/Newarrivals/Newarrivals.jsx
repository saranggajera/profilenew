import React from 'react'
import './newarrivals.css'
import { newarrivals } from '../Data'

const Newarrivals = () => {
    return (
        <div className='newarrivals'>
            <div className='container-fluid container_div'>
                <div className='row'>
                    <div className='col-md-12'>
                        <h2 className='new_text'>New Arrivals</h2>
                    </div>
                </div>

                <div className='row row_newarrivals_div'>
                    {
                        newarrivals.map((eve, ind) => {
                            return (
                                <div key={ind} className='col-lg-3 col-md-4 col-sm-12 mt-4'>
                                    <div className='armani_main_div'>
                                        <img className='newarrivals_div_img' src={eve.images} alt='images' />
                                        <div className='armani_title_div'>
                                            <h5>{eve.title}</h5>
                                            <p>{eve.title}...</p>
                                            <h5>{eve.rat} <span className='norat_div'>{eve.noreat}</span></h5>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
                <hr className='newarrivals_hr_div'/>
            </div>
        </div>
    )
}

export default Newarrivals