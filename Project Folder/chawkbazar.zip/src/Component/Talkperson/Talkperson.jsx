import React from 'react'
import './talkperson.css'
import TextsmsIcon from '@mui/icons-material/Textsms';

const Talkperson = () => {
    return (
        <div className='talkperson'>
            <div className='container-fluid container_div'>
                <div className='row'>
                    <div className='col-md-12 text-center'>
                        <h2>Talk To A Real Person</h2>
                        <p className='mt-3'>
                            Are you on the fence? Have a question? Need a recommendation? <br />
                            Member Services is always here to help. Send us a message.
                        </p>
                    </div>
                </div>

                <div className='row'>
                    <div className='col-md-12'>
                         <div className='img_div_talkperson'>
                         <img src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fsupport.png&w=1080&q=75' alt='images'/>
                         <button className='chat_btn_div'>Chat With Member Services <TextsmsIcon className='ml-2'/></button>
                         </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Talkperson