import React from 'react'
import { Woomann } from '../Data';
import ChevronRightIcon from '@mui/icons-material/ChevronRight';
import { Link } from 'react-router-dom';

const Woman = () => {
    return (
        <div className='woman'>
            <div className='container-fluid'>
                <div className='row'>
                    {
                        Woomann.map((eve, ind) => {
                            return (
                                <div key={ind} className='col-lg-12 mt-3'>
                                    <Link className='link_div' to={`${eve.link}`}>
                                        <div className='woman_div'>
                                            <div className='wom_img_div'>
                                                <img className='wom_img' src={eve.images} alt='images' />
                                                <h5 className='ml-3'>{eve.title}</h5>
                                            </div>
                                            <div className='text_woman_div'>
                                                <div>
                                                    <h6 className='m-0 text_won_div'>{eve.text}</h6>
                                                </div>
                                                <ChevronRightIcon />
                                            </div>
                                        </div>
                                    </Link>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </div>
    )
}

export default Woman