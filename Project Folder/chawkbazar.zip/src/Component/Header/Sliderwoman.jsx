import React from 'react'
import Slider from "react-slick";
import ArrowRightAltIcon from '@mui/icons-material/ArrowRightAlt';

const Sliderwoman = () => {

  var settings = {
    dots: true,
    infinite: true,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    pauseOnHover: false
  };

  return (
    <div className='mt-3 sliderwoman'>
      <div className='container-fluid'>
        <div className='row'>
          <div className='col-lg-12 p-0 col_div_header_main'>
            <div>
              <Slider {...settings}>

                <div className='woman_slider'>
                    <div className='woman_sliderr'>
                      <h2 className='we_div_title'>We Picked Every Item <br /> With Care, <span className='you_text_div'>You must Try</span><br />Atleast Once.</h2>
                      <button className='goto_btn_slider'>Go To Collectionn <ArrowRightAltIcon /></button>
                    </div>
                  <div>
                    <img className='slider_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-25-s.png&w=384&q=100' alt='images' />
                  </div>
                </div>

                <div className='woman_slider'>
                  <div className='woman_sliderr'>
                    <h2 className='we_div_title'>We Picked Every Item <br /> With Care, <span className='you_text_div'>You must Try</span><br />Atleast Once.</h2>
                    <button className='goto_btn_slider'>Go To Collection <ArrowRightAltIcon /></button>
                  </div>
                  <div>
                    <img className='slider_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-22-s.png&w=384&q=100' alt='images' />
                  </div>
                </div>

                <div className='woman_slider'>
                  <div className='woman_sliderr'>
                    <h2 className='we_div_title'>We Picked Every Item <br /> With Care, <span className='you_text_div'>You must Try</span><br />Atleast Once.</h2>
                    <button className='goto_btn_slider'>Go To Collection <ArrowRightAltIcon /></button>
                  </div>
                  <div>
                    <img className='slider_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=384&q=100' alt='images' />
                  </div>
                </div>
              </Slider>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Sliderwoman