import React from 'react'
import './header.css'
import Woman from './Woman'
import Sliderwoman from './Sliderwoman'
import Womann from './Womann'

const Header = () => {
    return (
        <div className='header'>
            <div className='container-fluid container_div'>
                <div className='row'>
                    <div className='col-lg-4 p-0 woman_div_main'>
                        <Woman />
                    </div>
                    <div className='col-lg-8 col-md-12 slider_divv p-0 womann_div_main'>
                        <div className=''>
                            <Sliderwoman />
                        </div>
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12 main_slider_div maiin_slider_div slider_divv'>
                        <Sliderwoman />
                    </div>
                </div>
                <div className='row'>
                    <div className='col-md-12 main_slider_div maiin_slider_div slider_divv'>
                        <Womann />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Header