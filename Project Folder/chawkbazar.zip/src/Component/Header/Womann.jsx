import React from 'react'
import { Link } from 'react-router-dom';
import Slider from "react-slick";

const Womann = () => {

    var settings = {
        dots: true,
        infinite: true,
        slidesToShow: 4,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        pauseOnHover: false,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: false
                }
            },
            {
                breakpoint: 987,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 1,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 692,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 487,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    };

    return (
        <div className='woman'>
            <div className='container-fluid'>
                <div className='row'>
                    <div className='col-md-12 col_woman_main_div'>
                        <div className='woman_main_diiv'>
                            <Slider {...settings}>

                            <Link className="woman_div_links" to="/woman">
                                <div className='woman_div_sliders'>
                                        <div className='main_div_img_wom'>
                                            <img className='woman_div_sliderss' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fwoman.jpg&w=64&q=75' alt='images' />
                                            <h6 className='ml-3'>Woman</h6>
                                        </div>
                                        <div>
                                            <h5 className='m-0'>20</h5>
                                        </div>
                                </div>
                                </Link>

                                <Link className="woman_div_links" to="/man">
                                <div className='woman_div_sliders'>
                                    <div className='main_div_img_wom'>
                                        <img className='woman_div_sliderss' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fman.jpg&w=64&q=75' alt='images' />
                                        <h6 className='ml-3'>Man</h6>
                                    </div>
                                    <div>
                                        <h5>20</h5>
                                    </div>
                                </div>
                                </Link>

                                <Link className="woman_div_links" to="/watch">
                                <div className='woman_div_sliders'>
                                    <div className='main_div_img_wom'>
                                        <img className='woman_div_sliderss' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fwatch.jpg&w=64&q=75' alt='images' />
                                        <h6 className='ml-3'>Watch</h6>
                                    </div>
                                    <div>
                                        <h5>20</h5>
                                    </div>
                                </div>
                                </Link>

                                <Link className="woman_div_links" to="/kids">
                                <div className='woman_div_sliders'>
                                    <div className='main_div_img_wom'>
                                        <img className='woman_div_sliderss' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fkid.jpg&w=64&q=75' alt='images' />
                                        <h6 className='ml-3'>Kids</h6>
                                    </div>
                                    <div>
                                        <h5>20</h5>
                                    </div>
                                </div>
                                </Link>

                                <Link className="woman_div_links" to="sports">
                                <div className='woman_div_sliders'>
                                    <div className='main_div_img_wom'>
                                        <img className='woman_div_sliderss' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fsports.jpg&w=64&q=75' alt='images' />
                                        <h6 className='ml-3'>Sports</h6>
                                    </div>
                                    <div>
                                        <h5>20</h5>
                                    </div>
                                </div>
                                </Link>

                                <Link className="woman_div_links" to="/sunglass">
                                <div className='woman_div_sliders'>
                                    <div className='main_div_img_wom'>
                                        <img className='woman_div_sliderss' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fsunglass.jpg&w=64&q=75' alt='images' />
                                        <h6 className='ml-3'>Sunglass</h6>
                                    </div>
                                    <div>
                                        <h5>20</h5>
                                    </div>
                                </div>
                                </Link>

                                <Link className="woman_div_links" to="/bags">
                                <div className='woman_div_sliders'>
                                    <div className='main_div_img_wom'>
                                        <img className='woman_div_sliderss' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fbags.jpg&w=64&q=75' alt='images' />
                                        <h6 className='ml-3'>Bags</h6>
                                    </div>
                                    <div>
                                        <h5>20</h5>
                                    </div>
                                </div>
                                </Link>

                                <Link className="woman_div_links" to="sneakers">
                                <div className='woman_div_sliders'>
                                    <div className='main_div_img_wom'>
                                        <img className='woman_div_sliderss' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Fsneakers.jpg&w=64&q=75' alt='images' />
                                        <h6 className='ml-3'>Sneakers</h6>
                                    </div>
                                    <div>
                                        <h5>20</h5>
                                    </div>
                                </div>
                                </Link>

                            </Slider>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Womann