import React from 'react'
import './getexpert.css'

const Getexpert = () => {
    return (
        <div className='getexpert'>
            <div className='container-fluid container_div'>
                <div className='row row_div_getexpert'>
                    <div className='col-lg-6 col-md-6 col-sm-12 p-0'>
                        <div className='get_div_text'>
                            <h1>Get Expert Tips In Your Inbox</h1>
                            <p>
                                Subscribe to our newsletter and stay updated.
                            </p>
                        </div>
                    </div>
                    <div className='col-lg-6 col-md-6 col-sm-12 p-0'>
                        <div className='subs_div_btn'>
                            <input className='input_search_div' type="search" placeholder="Write your email here"/>
                            <button className='input_search_btn'>Subscribe</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Getexpert