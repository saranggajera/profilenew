import React from 'react'
import './chawkbazarapp.css'

const Chawkbazarapp = () => {
  return (
    <div className='chawkbazarapp'>
        <div className='container-fluid container_div'>
            <div className='row'>
                 <div className='col-md-12'>
                     <div className='chawkbazarapp_main_div'>
                         <div className='chawkbazar_text_div'>
                            <h2 className='the_app_div'>The ChawkBazar App</h2>
                            <h1 className='share_app_div'>Share Your <span className='ideas_div'>Ideas</span> & Shop <br/> Endless <span className='ideas_div'>Inspiration</span></h1>
                            <div className='play_img_chawkbazarapp'>
                                <img className='play_img_cha' src='https://chawkbazar.vercel.app/assets/images/app-store.svg' alt='images'/>
                                <img className='paly_img_div play_img_cha' src='https://chawkbazar.vercel.app/assets/images/play-store.svg' alt='images'/>
                            </div>
                         </div>
                         <div className='phone_img_chawkbazarapp'>
                            <img  src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fapp.png&w=384&q=75' alt='images'/>
                         </div>
                     </div>
                 </div>
            </div>
        </div>
    </div>
  )
}

export default Chawkbazarapp