import React from 'react'
import Bestsellers from '../Bestsellers/Bestsellers'
import Chawkbazarapp from '../Chawkbazarapp/Chawkbazarapp'
import Downthecore from '../Downthecore/Downthecore'
import Featured from '../Featured/Featured'
import Footer from '../Footer/Footer'
import Getexpert from '../Getexpert/Getexpert'
import Getonselected from '../Getonselected/Getonselected'
import Guaranteed from '../Guaranteed/Guaranteed'
import Header from '../Header/Header'
import Navbar from '../Navbar/Navbar'
import Newarrivals from '../Newarrivals/Newarrivals'
import Talkperson from '../Talkperson/Talkperson'
import Topbrands from '../TopBrands/Topbrands'
import Products from '../TopProductsSection/Products'
import Uptoholidaybit from '../Uptoholidaybit/Uptoholidaybit'
import Wemenstshirts from '../Wemenstshirts/Wemenstshirts'


const Chawkbazarhome = () => {
  return (
    <div>
        <Navbar/>
        <Header/>
        <Products/>
        <Wemenstshirts/>
        <Getonselected/>
        <Featured/>
        <Bestsellers/>
        <Uptoholidaybit/>
        <Newarrivals/>
        <Topbrands/>
        <Guaranteed/>
        <Downthecore/>
        <Chawkbazarapp/>
        <Talkperson/>
        <Getexpert/>
        <Footer/>
    </div>
  )
}

export default Chawkbazarhome