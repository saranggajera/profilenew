import React from 'react'
import './bestsellers.css'
import { BestSellers } from '../Data'

const Bestsellers = () => {
  return (
    <div className='bestsellers'>
      <div className='container_div container-fluid'>
        <div className='row'>
          <div className='col-md-12'>
            <h2 className='best_div_title'>Best Sellers</h2>
          </div>
        </div>

        <div className='row row_div_best_sellers'>
          {
            BestSellers.map((eve, ind) => {
              return (
                <div key={ind} className='col-lg-3 col-md-4 col-sm-12 mt-4'>
                  <div className='black_div_best'>
                    <img className='bestsellers_img_div' src={eve.images} alt='images' />
                    <div className='nike_div'>
                      <h5>{eve.title}</h5>
                      <p>{eve.title}...</p>
                      <h5>{eve.rate} <span className='notavelebl_ret'>{eve.noreat}</span></h5>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
    </div>
  )
}

export default Bestsellers