import React from 'react'
import Slider from "react-slick";

const Flashsale = () => {

    var settings = {
        dots: true,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2000,
        pauseOnHover: false,
        responsive: [
            {
              breakpoint: 990,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 1,
                infinite: true,
                dots: true
              }
            },
            {
              breakpoint: 600,
              settings: {
                slidesToShow: 2,
                slidesToScroll: 2,
                initialSlide: 2
              }
            },
            {
              breakpoint: 480,
              settings: {
                slidesToShow: 1,
                slidesToScroll: 1
              }
            }
          ]
    };

    return (
        <div className='flashsale'>
            <div className='container-flui'>
                <div className='row'>
                    <div className='col-md-12 col_div_flashsale'>
                        <div className='flashsale_div'>
                            <h2>Flash Sale</h2>
                            <div className='flash_sale_div mt-4'>
                                <div>
                                    <Slider {...settings}>
                                        <div className='slider_div_main_flashsale'>
                                            <div className='flash_img_main'>
                                                <img className='flash_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-24-s.png&w=384&q=100' alt='images' />
                                            </div>
                                            <div className='mt-3'>
                                                <h4>Adidas Shoes Black...</h4>
                                                <p>
                                                    men Black Top sleeveless gown
                                                </p>
                                                <h6>$45.00 <span className='ml-2'>$99.99</span></h6>
                                                <div className='d-flex justify-content-between sold_div_text'>
                                                    <h6>Sold: 120</h6>
                                                    <h6>Available: 147</h6>
                                                </div>
                                                <div className='prges_bar_div'>
                                                    <div className='prges_div'></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className='slider_div_main_flashsale'>
                                            <div className='flash_img_main'>
                                                <img className='flash_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-25-s.png&w=384&q=100' alt='images' />
                                            </div>
                                            <div className='mt-3'>
                                                <h4>Adidas Shoes Black...</h4>
                                                <p>
                                                    men Black Top sleeveless gown
                                                </p>
                                                <h6>$45.00 <span className='ml-2'>$99.99</span></h6>
                                                <div className='d-flex justify-content-between sold_div_text'>
                                                    <h6>Sold: 120</h6>
                                                    <h6>Available: 147</h6>
                                                </div>
                                                <div className='prges_bar_div'>
                                                    <div className='prges_div'></div>
                                                </div>
                                            </div>
                                        </div>

                                        <div className='slider_div_main_flashsale'>
                                            <div className='flash_img_main'>
                                                <img className='flash_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-25-s.png&w=384&q=100' alt='images' />
                                            </div>
                                            <div className='mt-3'>
                                                <h4>Adidas Shoes Black...</h4>
                                                <p>
                                                    men Black Top sleeveless gown
                                                </p>
                                                <h6>$45.00 <span className='ml-2'>$99.99</span></h6>
                                                <div className='d-flex justify-content-between sold_div_text'>
                                                    <h6>Sold: 120</h6>
                                                    <h6>Available: 147</h6>
                                                </div>
                                                <div className='prges_bar_div'>
                                                    <div className='prges_div'></div>
                                                </div>
                                            </div>
                                        </div>
                                    </Slider>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Flashsale