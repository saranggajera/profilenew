import React from 'react'
import Flashsale from './Flashsale'
import Topproducts from './Topproducts'

const Products = () => {
  return (
    <div className='products mt-5'>
       <div className='container-fluid container_div'>
            <div className='row row_products_main_div'>
               <div className='col-lg-9 col-md-12'>
                  <Topproducts/>
               </div>
               <div className='col-lg-3 col-md-12'>
                   <Flashsale/>
               </div>
            </div>
       </div>
    </div>
  )
}

export default Products