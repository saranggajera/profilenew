import React, { useState } from 'react'
import './topproducts.css'
import { topproducts } from '../Data'
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import { Link } from 'react-router-dom';


const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 500,
  bgcolor: 'background.paper',
  border: '0px solid #000',
  boxShadow: 24,
  p: 0,
};

const Topproducts = () => {

  const [open, setOpen] = React.useState(false);
  const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);


  const [count, setCount] = useState(1);

  function increment() {
    setCount(function (prevCount) {
      return (prevCount += 1);
    });
  }

  function decrement() {
    setCount(function (prevCount) {
      if (prevCount > 1) {
        return (prevCount -= 1); 
      } else {
        return (prevCount = 1);
      }
    });
  }

  return (
    <div className='topproducts'>
      <div className='container-flui'>
        <div className='row'>
          <div className='col-md-12'>
            <div className='top_produ'>
              <div className='see_top_div'>
                <h3>Top Products</h3>
                <h6>See All Product</h6>
              </div>
            </div>
          </div>
        </div>

        <div className='row'>
          {
            topproducts.map((eve, ind) => {
              return (
                <div key={ind} onClick={handleOpen} className='col-md-6 mt-3'>
                  <div className='shpoe_div'>
                    <div class="shope_div_img">
                      <img src={eve.images} alt="images" />
                    </div>
                    <div className='maniac_text_div'>
                      <h4>{eve.title}</h4>
                      <h6>{eve.text}</h6>
                      <h6>{eve.reate}</h6>
                    </div>
                  </div>
                </div>
              )
            })
          }

          <div>
            <Modal
              open={open}
              onClose={handleClose}
              aria-labelledby="modal-modal-title"
              aria-describedby="modal-modal-description"
            >
              <Box sx={style} className="topproducts_modal">
                <div className='maniac_div_main'>

                  <div>
                    <img className='modal_img_topp' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=384&q=100' alt='images' />
                  </div>

                  <div className='sporty_div_man'>
                    <h3>Maniac Red Boys</h3>
                    <p className='sporty_text'>
                      Sporty essentials, these Under Armour athletic shorts are smooth and <br /> lightweight in moisture-wicking material.
                    </p>
                    <h4>$15.00 <span className='low_reat'><div className='low_line'></div>$20.00</span></h4>

                     <div className='mt-4'>
                        <h5>Size</h5>
                        <div className='size_div_man'>
                           <div className='map_div'><h5 className='m-0'>S</h5></div>
                           <div className='map_div'><h5 className='m-0'>M</h5></div>
                           <div className='map_div'><h5 className='m-0'>L</h5></div>
                           <div className='map_div'><h5 className='m-0'>XL</h5></div>
                        </div>
                     </div>

                     <div className='mt-4'>
                        <h5>Color</h5>
                        <div className='div_main_color'>
                           <div className='color_div'><span className='div_colo_1'></span></div>
                           <div className='color_div'><span className='div_colo_2'></span></div>
                           <div className='color_div'><span className='div_colo_3'></span></div>
                           <div className='color_div'><span className='div_colo_4'></span></div>
                        </div>
                     </div>
                     
                     <div className='ink_btn_div'>
                        <div className='inkr_div'>
                           <div className='dekriment_div' onClick={decrement}><span className='dekrment_div'>-</span></div>
                           <div className='count_div'>{count}</div>
                           <div className='dekrimen_div' onClick={increment}><span className='dekrment_div'>+</span></div>
                        </div>

                        <div>
                          <button className='add_btns'>Add To Cart</button>
                        </div>
                     </div>

                     <div>
                        <Link to="/maniac" className="link_div_min"><button className='view_div_btns'>View Details</button></Link>
                     </div>
                  </div>
                </div>
              </Box>
            </Modal>
          </div>
        </div>

      </div>
    </div>
  )
}

export default Topproducts