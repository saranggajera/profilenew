import React from 'react'
import { slider } from '../Data'
import Slider from "react-slick";
import './topbrands.css'

const Topbrands = () => {

  var settings = {
    dots: true,
    infinite: true,
    slidesToShow: 7,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    pauseOnHover: false,
    responsive: [
      {
        breakpoint: 1406,
        settings: {
          slidesToShow: 6,
          slidesToScroll: 1,
          infinite: true,
          dots: true
        }
      },
      {
        breakpoint: 1041,
        settings: {
          slidesToShow: 5,
          slidesToScroll: 1,
          initialSlide: 2
        }
      },
      {
        breakpoint: 989,
        settings: {
          slidesToShow: 4,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 798,
        settings: {
          slidesToShow: 3,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 607,
        settings: {
          slidesToShow: 2,
          slidesToScroll: 1
        }
      },
      {
        breakpoint: 394,
        settings: {
          slidesToShow: 1,
          slidesToScroll: 1
        }
      },
    ]
  };

  return (
    <div className='topbrands'>
      <div className='container-fluid container_div'>
        <div className='row'>
          <div className='col-md-12'>
            <h2>Top Brands</h2>
          </div>
        </div>
        <div className='row'>
          <div className='col-md-12 col_div_main_topbrands'>
            <div className='slider_topbrands'>
              <Slider {...settings}>
                <div className='slider_topbrands_box'>
                  <img className="topbrands_div_sliders slider_topb" src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbrands%2Fblaze-fashion.png&w=256&q=100' alt='images' />
                  <div>
                    <h5 className='mt-3'>Blaze Fashion</h5>
                  </div>
                </div>
                <div className='slider_topbrands_box'>
                  <img className="topbrands_div_sliders" src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbrands%2Felegance.png&w=256&q=100' alt='images' />
                  <h5 className='mt-3'>Elegance</h5>
                </div>
                <div className='slider_topbrands_box'>
                  <img className="topbrands_div_sliders" src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbrands%2Ffashadil.png&w=256&q=100' alt='images' />
                  <h5 className='mt-3'>Fashadil</h5>
                </div>
                <div className='slider_topbrands_box'>
                  <img className="topbrands_div_sliders" src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbrands%2Fshovia.png&w=256&q=100' alt='images' />
                  <h5 className='mt-3'>Shovia</h5>
                </div>
                <div className='slider_topbrands_box'>
                  <img className="topbrands_div_sliders" src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbrands%2Ffusion.png&w=256&q=100' alt='images' />
                  <h5 className='mt-3'>Fusion</h5>
                </div>
                <div className='slider_topbrands_box'>
                  <img className="topbrands_div_sliders slider_topb" src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbrands%2Fhunter-shoes.png&w=256&q=100' alt='images' />
                  <h5 className='mt-3'>Hunter Shoes</h5>
                </div>
                <div className='slider_topbrands_box'>
                  <img className="topbrands_div_sliders slide_topb" src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbrands%2Fclub-shoes.png&w=256&q=100' alt='images' />
                  <h5 className='mt-3'>Club Shoes</h5>
                </div>
                <div className='slider_topbrands_box'>
                  <img className="topbrands_div_sliders" src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbrands%2Fhoppister.png&w=256&q=100' alt='images' />
                  <h5 className='mt-3'>Hoppister</h5>
                </div>
              </Slider>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Topbrands