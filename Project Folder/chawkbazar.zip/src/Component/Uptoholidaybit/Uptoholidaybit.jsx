import React from 'react'
import './uptoholidaybit.css'

const Uptoholidaybit = () => {
  return (
    <div className='uptoholidaybit'>
        <div className='container_div container-fluid'>
            <div className='row'>
                <div className='col-md-12'>
                   <img className='uptoholidaybit_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbanner%2Fbanner-1.jpg&w=1920&q=100' alt='images'/>
                </div>
            </div>
        </div>
    </div>
  )
}

export default Uptoholidaybit