import React from 'react'
import Footer from '../../Footer/Footer'
import Getexpert from '../../Getexpert/Getexpert'
import Navbar from '../../Navbar/Navbar'
import Product from '../WomanProduct/Product'

const Kids = () => {
  return (
    <div className='kids'>
      <Navbar />
      <div className='container_div container-fluid'>
        <div className='row row_woman_div'>
          <div className='col-md-12'>
            <div className='woman_main_div'>
              <h1 className='woman_text_div'>#Kids</h1>
            </div>
          </div>
        </div>

        <div className='row row_wom_div'>
          <div className='col-md-12'>
            <div className='wom_div_back'>
              <h1>#Kids</h1>
            </div>
          </div>
        </div>

        <div className='row mt-3'>
          <div className='col-md-12'>
             <Product/>
          </div>
        </div>

      </div>
      <Getexpert />
      <Footer />
    </div>
  )
}

export default Kids