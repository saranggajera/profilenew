import React, { useState } from 'react'
import { casual } from '../../Data'

const Casual = () => {

    const [showmor, setShowmor] = useState(16)

    const slice = casual.slice(0, showmor);
    const loadmore = () => {
        setShowmor(showmor + showmor)
    }

    return (
        <div className='casual'>
            <div className='container-fluid'>
                <div className='row'>
                    {
                        slice.map((eve, ind) => {
                            return (
                                <div key={ind} className='col-lg-3 col-md-4 col-sm-6 mt-4'>
                                    <div className='casual_div_main'>
                                        <img className='img_casual' src={eve.images} alt='images' />
                                        <div className='shoes_div_text'>
                                            <h5 className='garment_title_div'>{eve.title}</h5>
                                            <p className='m-0 about_text_casual'>{eve.text}</p>
                                            <h5 className='mt-2'>$30.00</h5>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
                <button className='load_btn_casual' onClick={() => loadmore()}>Load More</button>
            </div>
        </div>
    )
}

export default Casual