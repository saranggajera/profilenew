import React from 'react'
import Navbar from '../../Navbar/Navbar'
import Getexpert from '../../Getexpert/Getexpert'
import Footer from '../../Footer/Footer'
import './tshirt.css'
import { Link } from 'react-router-dom'
import Casual from './Casual'
import FilterListIcon from '@mui/icons-material/FilterList';
import KeyboardBackspaceIcon from '@mui/icons-material/KeyboardBackspace';

const Tshirt = () => {
    return (
        <div className='tshirt'>
            <Navbar />
            <div className='container-fluid container_div'>

                <div className='row row_tshirt_div'>

                    <div className='col-lg-3 filters_div'>
                        <div className='filters'>
                            <div>
                                <Link className='home_link_tshirt' to="/">HOME</Link>
                                <span className='mx-2 desline_div'>/</span>
                                <Link className='ser_div_text'>Search</Link>
                            </div>

                            <div className='filt_div_main'>
                                <h4 className='m-0'>Filters</h4>
                                <h6 className='m-0 clear_all_div'>Clear All</h6>
                            </div>

                            <div>
                                <hr className='mt-5' />
                            </div>

                            <div className='cate_div_tshirt'>
                                <h4>Category</h4>

                                <div className='input_chack_div'>
                                    <label className="cont">Woman
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Man
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Watch
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Kids
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Sports
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Sunglass
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Bags
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Sneakers
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                </div>
                            </div>

                            <div>
                                <hr />
                            </div>

                            <div className='cate_div_tshirt'>
                                <h4>Brands</h4>

                                <div className='input_chack_div'>
                                    <label className="cont">Shovia
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Fusion
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Hunter Shoes
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Club Shoes
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Hoppister
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Blaze Fashion
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Elegance
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Fashadil
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                </div>
                            </div>


                            <div>
                                <hr />
                            </div>

                            <div className='cate_div_tshirt'>
                                <h4>Price</h4>

                                <div className='input_chack_div'>
                                    <label className="cont">Under $50
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">$50 to $100
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">$100 to $150
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">$150 to $200
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">$200 to $300
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">$300 to $500
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">$500 to $1000
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont">Over $1000
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                </div>
                            </div>


                            <div>
                                <hr />
                            </div>

                            <div className='cate_div_tshirt'>
                                <h4>Colors</h4>

                                <div className='input_chack_div'>
                                    <label className="cont"><div><span className='color_black'></span>Black</div>
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont"><div><span className='color_blue'></span>Blue</div>
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont"><div><span className='color_olive'></span>Olive</div>
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont"><div><span className='color_maroon'></span>Maroon</div>
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont"><div><span className='color_brown'></span>Brown</div>
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont"><div><span className='color_white'></span>White</div>
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                    <label className="cont"><div><span className='color_gray'></span>Gray</div>
                                        <input type="checkbox" />
                                        <span className="checkmark"></span>
                                    </label>
                                </div>
                            </div>

                            <div className='mt-5'>
                                <hr />
                            </div>

                        </div>
                    </div>

                    <div className='col-lg-9'>
                        <div className='filters'>

                            <div className='casual_div'>
                                <div>
                                    <h4>Casual Wear</h4>
                                </div>
                                <div className='d-flex align-items-center'>
                                    <p className='m-0'>9,608 items</p>
                                    <div className='ml-5'>
                                        <select className="form-select select_form" aria-label="Default select example">
                                            <option selected>English -EN</option>
                                            <option value="1"><img className='div_img_flag' src='/images/Flag_of_Saudi_Arabia.svg.png' alt='images' />Arabic - AR</option>
                                            <option value="2">Chinese-EN</option>
                                            <option value="4"><span><img className='div_img_flag' src='/images/Flag_of_Saudi_Arabia.svg.png' alt='images' /></span>German -EN</option>
                                            <option value="5">Hebrew -EN</option>
                                            <option value="6">Spanish people</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div>
                            <Casual />
                        </div>
                    </div>

                </div>

                <div className='row row_tshir_div'>
                    <div className='col-lg-12'>

                        <div className='casual_div'>
                            <div>
                                <div>
                                    <div className='filters_btns'>
                                        <label for="togle-Sidebar" class="toggle-ion">
                                            <FilterListIcon /> Filters
                                        </label>
                                    </div>
                                </div>
                                <input type="checkbox" id="togle-Sidebar" className='inpu_chac' />
                                <div className="sidebar_div">

                                    <div className='filter_div_sidr'>
                                        <div>
                                            <label for="togle-Sidebar" class="toggle-icon">
                                                <KeyboardBackspaceIcon />
                                            </label>
                                        </div>
                                        <div>
                                            <h3>Filters</h3>
                                        </div><div></div>
                                    </div>

                                    <div className='filter_div'>
                                        <div>
                                            <h3>Filters</h3>
                                        </div>
                                        <div>
                                            <p>Clear All</p>
                                        </div>
                                    </div>
                                    <hr className='hr_filter_line' />

                                    <div className='p-3'>

                                        <div className='cate_div_tshirt'>
                                            <h4>Category</h4>

                                            <div className='input_chack_div'>
                                                <label className="cont">Woman
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Man
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Watch
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Kids
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Sports
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Sunglass
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Bags
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Sneakers
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                            </div>
                                        </div>

                                        <div>
                                            <hr />
                                        </div>

                                        <div className='cate_div_tshirt'>
                                            <h4>Brands</h4>

                                            <div className='input_chack_div'>
                                                <label className="cont">Shovia
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Fusion
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Hunter Shoes
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Club Shoes
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Hoppister
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Blaze Fashion
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Elegance
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Fashadil
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                            </div>
                                        </div>


                                        <div>
                                            <hr />
                                        </div>

                                        <div className='cate_div_tshirt'>
                                            <h4>Price</h4>

                                            <div className='input_chack_div'>
                                                <label className="cont">Under $50
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">$50 to $100
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">$100 to $150
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">$150 to $200
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">$200 to $300
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">$300 to $500
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">$500 to $1000
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont">Over $1000
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                            </div>
                                        </div>


                                        <div>
                                            <hr />
                                        </div>

                                        <div className='cate_div_tshirt'>
                                            <h4>Colors</h4>

                                            <div className='input_chack_div'>
                                                <label className="cont"><div><span className='color_black'></span>Black</div>
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont"><div><span className='color_blue'></span>Blue</div>
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont"><div><span className='color_olive'></span>Olive</div>
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont"><div><span className='color_maroon'></span>Maroon</div>
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont"><div><span className='color_brown'></span>Brown</div>
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont"><div><span className='color_white'></span>White</div>
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                                <label className="cont"><div><span className='color_gray'></span>Gray</div>
                                                    <input type="checkbox" />
                                                    <span className="checkmark"></span>
                                                </label>
                                            </div>
                                        </div>

                                        <div>
                                            <hr />
                                        </div>
                                    </div>

                                    <div className='items_div_main'>
                                        <h5 className='items_text'>9,608 items</h5>
                                    </div>

                                </div>
                            </div>

                            <div className='d-flex align-items-center'>
                                <div>
                                    <select className="form-select select_form" aria-label="Default select example">
                                        <option selected>Sorting Options</option>
                                        <option value="1"><img className='div_img_flag' src='/images/Flag_of_Saudi_Arabia.svg.png' alt='images' />Arabic - AR</option>
                                        <option value="2">Chinese-EN</option>
                                        <option value="4"><span><img className='div_img_flag' src='/images/Flag_of_Saudi_Arabia.svg.png' alt='images' /></span>German -EN</option>
                                        <option value="5">Hebrew -EN</option>
                                        <option value="6">Spanish people</option>
                                    </select>
                                </div>
                            </div>

                        </div>
                        <Casual />
                    </div>
                </div>
            </div>
            <Getexpert />
            <Footer />
        </div>
    )
}

export default Tshirt