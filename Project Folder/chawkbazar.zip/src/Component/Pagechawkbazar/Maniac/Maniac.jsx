import React from 'react'
import Navbar from '../../Navbar/Navbar'
import Footer from '../../Footer/Footer'
import Getexpert from '../../Getexpert/Getexpert'
import { Link } from 'react-router-dom'
import './maniac.css'

const Maniac = () => {
    return (
        <div className='maniac'>
            <Navbar />
            <div className='container-fluid container_div'>
                <div className='row row_maniac_div'>
                    <div className='col-md-12'>
                        <div>
                            <Link className='home_div_maniac'>Home</Link>
                            <span className='mx-2'>/</span>
                            <Link className='home_div_maniac'>Products</Link>
                            <span className='mx-2'>/</span>
                            <Link className='home_div_maniac'>Maniac Red Boys</Link>
                        </div>
                    </div>
                </div>

                <div className='row mt-5'>
                    <div className='col-lg-6'>
                        <div className='row'>
                            <div className='col-lg-6'>
                               <img className='mani_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=384&q=100' alt=''/>
                            </div>
                            <div className='col-lg-6'>
                            <img className='mani_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=384&q=100' alt=''/>
                            </div>
                        </div>
                        <div className='row mt-3'>
                            <div className='col-lg-6'>
                               <img className='mani_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=384&q=100' alt=''/>
                            </div>
                            <div className='col-lg-6'>
                            <img className='mani_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fproducts%2Fp-20.png&w=384&q=100' alt=''/>
                            </div>
                        </div>
                    </div>
                    <div className='col-lg-6'></div>
                </div>

            </div>
            <Getexpert />
            <Footer />
        </div>
    )
}

export default Maniac