import React, { useEffect, useState } from 'react'
import './product.css'
import { product } from '../../Data'

const Product = () => {

    const [showmor, setShowmor] = useState(16)

    const slice = product.slice(0, showmor);
    const loadmore = () => {
        setShowmor(showmor + showmor)
    }

    useEffect(() => {
        window.scrollTo({top: 0, left: 0,});
      }, []);

    return (
        <div className='product'>
            <div className='container-fluid'>
                <div className='row'>
                    {
                        slice.map((eve, ind) => {
                            return (
                                <div className='col-lg-3 col-md-4 col-sm-6 mt-4'>
                                    <div key={ind} className='product_main_div'>
                                        <div className='product_img_div'>
                                            <img className='product_img' src={eve.images} alt='images' />
                                        </div>
                                        <div className='nike_text_div'>
                                            <h6 className='title_text_div'>{eve.title}</h6>
                                            <p className='m-0 black_p_text'>{eve.text}</p>
                                            <h5 className='mt-2'>{eve.prize} <span className='noprize_number'>{eve.noprize}</span></h5>
                                        </div>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
                <button className='product_load_div' onClick={() => loadmore()}>Load More</button>
            </div>
        </div>
    )
}

export default Product