import React from 'react'
import Footer from '../../Footer/Footer'
import Getexpert from '../../Getexpert/Getexpert'
import Navbar from '../../Navbar/Navbar'
import './shops.css'
import MenuIcon from '@mui/icons-material/Menu';
import WidgetsIcon from '@mui/icons-material/Widgets';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import { Super } from '../../Data'

const Shops = () => {

  return (
    <div className='shops'>
      <Navbar />
      <div className='container-fluid container_div'>
        <div className='row'>
          <div className='col-md-12'>
            <div className='super_div'>
              <div>
                <h2>Super Shops Near You</h2>
              </div>
              <div>
                <MenuIcon />
                <WidgetsIcon className='ml-2' />
              </div>
            </div>
          </div>
        </div>

        <div className='row mt-2'>
          {
            Super.map((eve, ind) => {
              return (
                <div key={ind} className='col-lg-4 col-md-4 col-sm-12 mt-4'>
                  <div className='area_box'>
                    <button className='new_btns'>{eve.button}</button>
                    <div>
                      <img className='box_img_area' src={eve.images} alt='images' />
                    </div>
                    <div className='ml-3 text_arriya'>
                      <h5 className='m-0'>{eve.title}</h5>
                      <p className='mt-2 text_div_new'>
                        <LocationOnIcon fontSize="small" />
                        {eve.text}
                      </p>
                    </div>
                  </div>
                </div>
              )
            })
          }
        </div>
      </div>
      <Getexpert />
      <Footer />
    </div>
  )
}

export default Shops