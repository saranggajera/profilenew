import React from 'react'
import './navbar.css'
import SearchIcon from '@mui/icons-material/Search';
import LocalMallIcon from '@mui/icons-material/LocalMall';
import Badge from '@mui/material/Badge';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import FacebookIcon from '@mui/icons-material/Facebook';
import GoogleIcon from '@mui/icons-material/Google';
import { Link } from 'react-router-dom';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';
import BottomNavigation from '@mui/material/BottomNavigation';
import SegmentIcon from '@mui/icons-material/Segment';
import HomeIcon from '@mui/icons-material/Home';
import PersonIcon from '@mui/icons-material/Person';
import CloseIcon from '@mui/icons-material/Close';
import TwitterIcon from '@mui/icons-material/Twitter';
import YouTubeIcon from '@mui/icons-material/YouTube';
import InstagramIcon from '@mui/icons-material/Instagram';
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';



const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    border: '2px solid #000',
    boxShadow: 24,
    p: 4,
};

const Navbar = () => {

    const [value, setValue] = React.useState(0);

    const [open, setOpen] = React.useState(false);
    const handleOpen = () => { setOpen(true); setVal(1) };
    const handleClose = () => setOpen(false);

    const [val, setVal] = React.useState(1)

    const [passwordShown, setPasswordShown] = React.useState(false);
    const togglePassword = () => {
        setPasswordShown(!passwordShown);
    };

    return (
        <div className='Navbar navbars'>
            <div className='recents_div'>
                <Box sx={{ width: 500 }}>
                    <BottomNavigation
                        showLabels
                        value={value}
                        onChange={(event, newValue) => {
                            setValue(newValue);
                        }}
                    >
                        <div className='segment_div_main'>
                            <div>
                                <label for="toggle-Sidebar" className="toggle-icon">
                                    <SegmentIcon />
                                </label>
                            </div>
                            <div className='search_icons'><SearchIcon /></div>
                            <div><Link className='home_icons' to='/'><HomeIcon /></Link></div>
                            <div className='search_icons'>
                                <Badge badgeContent={1} color="primary">
                                    <LocalMallIcon color="action" />
                                </Badge>
                            </div>
                            <div><PersonIcon onClick={handleOpen} /></div>
                        </div>
                    </BottomNavigation>
                </Box>
            </div>


            <div className="headder">
                <nav className="navbar navbar-expand-lg navbar-light">
                    <div className='d-flex justify-content-center align-items-center'>
                        <div className='toggle_icon'>
                            <label for="toggle-Sidebar" className="toggle-icon">
                                <SegmentIcon />
                            </label>
                        </div>
                        <Link className="navbar-brand" to="/"><img src='https://chawkbazar.vercel.app/assets/images/logo.svg' alt='images' /></Link>
                    </div>
                    <div className="collapse navbar-collapse">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item dropdown">
                                <a className="nav-link link_nav" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Demos
                                </a>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a className="dropdown-item" href="#">Action</a>
                                    <a className="dropdown-item" href="#">Another action</a>
                                    <a className="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link link_nav dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Men Wear
                                </a>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <Link className="dropdown-item" to="/tshirt">T-Shirt</Link>
                                    <a className="dropdown-item" href="#">Another action</a>
                                    <a className="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link link_nav dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Women Wear
                                </a>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a className="dropdown-item" href="#">Action</a>
                                    <a className="dropdown-item" href="#">Another action</a>
                                    <a className="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link link_nav" to='/'>Search</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link link_nav" to="/shops">Shops</Link>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link link_nav dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Pages
                                </a>
                                <div className="dropdown-menu" aria-labelledby="navbarDropdown">
                                    <a className="dropdown-item" href="#">Action</a>
                                    <a className="dropdown-item" href="#">Another action</a>
                                    <a className="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                        </ul>

                    </div>

                    <div className=''>
                        <div className='d-flex'>
                            <div className='dis_flex'>
                                <div className='search_div'>
                                    <select className="form-select select_form" aria-label="Default select example">
                                        <option selected>English -EN</option>
                                        <option value="1"><img className='div_img_flag' src='/images/Flag_of_Saudi_Arabia.svg.png' alt='images' />Arabic - AR</option>
                                        <option value="2">Chinese-EN</option>
                                        <option value="4"><span><img className='div_img_flag' src='/images/Flag_of_Saudi_Arabia.svg.png' alt='images' /></span>German -EN</option>
                                        <option value="5">Hebrew -EN</option>
                                        <option value="6">Spanish people</option>
                                    </select>
                                </div>
                                <div className='search_div search_divv'>
                                    <SearchIcon />
                                </div>
                                <div className='search_div search_divv'>
                                    <button className='sign_div_btn' onClick={handleOpen}>Sign In</button>
                                </div>
                                <div className='search_div search_divv'>
                                    <Badge badgeContent={1} color="primary">
                                        <LocalMallIcon color="action" />
                                    </Badge>
                                </div>
                            </div>
                            <div>
                                <Modal
                                    open={open}
                                    onClose={handleClose}
                                    aria-labelledby="modal-modal-title"
                                    aria-describedby="modal-modal-description"
                                >
                                    <Box sx={style}>
                                        <Typography>
                                            {
                                                val == 1 ?
                                                    <div className='sign_box_div'>
                                                        <div className='logni_form_div'>
                                                            <img src='https://chawkbazar.vercel.app/assets/images/logo.svg' alt='images' />
                                                            <h6 className='login_text'>Login with your email & password</h6>
                                                        </div>

                                                        <div className='mt-3'>
                                                            <form>
                                                                <div className="form-group">
                                                                    <label for="exampleInputEmail1" className='example_email'>Email</label>
                                                                    <input type="email" className="form-control control_form" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                                                </div>
                                                                <div className="form-group group_form">
                                                                    <label for="exampleInputPassword1" className='example_email'>Password</label>
                                                                    <input type={passwordShown ? "text" : "password"} className="form-control control_form" id="exampleInputPassword1" placeholder="Password" />
                                                                    <i className='Pass_login' onClick={togglePassword}>{passwordShown ? <VisibilityOffIcon /> : <VisibilityIcon />}</i>
                                                                </div>
                                                                <div className='d-flex justify-content-between align-items-center main_div_switch'>
                                                                    <div className="custom-control custom-switch">
                                                                        <input type="checkbox" className="custom-control-input" id="customSwitches" />
                                                                        <label className="custom-control-label" for="customSwitches">Remember me</label>
                                                                    </div>
                                                                    <div>
                                                                        <a className='forgot_password' onClick={() => setVal(3)}>Forgot password</a>
                                                                    </div>
                                                                </div>
                                                                <button type="submit" className="btn_login">Login</button>
                                                            </form>
                                                        </div>

                                                        <div className='main_div_login'>
                                                            <div className='line_div_login'></div>
                                                            <div className='m-1'>Or</div>
                                                            <div className='line_div_login'></div>
                                                        </div>

                                                        <div className='login_width_from'>
                                                            <h6 className='don_account'>Don't have any account? <a className='rea_btn_div' onClick={() => setVal(2)}>Register</a></h6>
                                                        </div>
                                                    </div>
                                                    : val == 2 ?
                                                        <div>
                                                            <div className='sign_boox_div'>
                                                                <div className='logni_form_div'>
                                                                    <img src='https://chawkbazar.vercel.app/assets/images/logo.svg' alt='images' />
                                                                    <h6 className='login_text'>By signing up, you agree to our <a href='#' className='trrms_div'>terms</a> & <a href='#' className='trrms_div'>policy</a></h6>
                                                                </div>

                                                                <div className='mt-3'>
                                                                    <form>

                                                                        <div className="form-group">
                                                                            <label for="exampleInputName1" className='example_email'>Name</label>
                                                                            <input type="text" className="form-control control_form" id="exampleInputName1" placeholder="Name" />
                                                                        </div>
                                                                        <div className="form-group">
                                                                            <label for="exampleInputEmail1" className='example_email'>Email</label>
                                                                            <input type="email" className="form-control control_form" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                                                        </div>

                                                                        <div className="form-group group_form">
                                                                            <label for="exampleInputPassword1" className='example_email'>Password</label>
                                                                            <input type={passwordShown ? "text" : "password"} className="form-control control_form" id="exampleInputPassword1" placeholder="Password" />
                                                                            <i className='Pass_login' onClick={togglePassword}>{passwordShown ? <VisibilityOffIcon /> : <VisibilityIcon />}</i>
                                                                        </div>

                                                                        <button type="submit" className="btn_login">Register</button>
                                                                    </form>
                                                                </div>

                                                                <div className='main_div_login'>
                                                                    <div className='line_div_login'></div>
                                                                    <div className='m-1'>Or</div>
                                                                    <div className='line_div_login'></div>
                                                                </div>

                                                                <div className='login_width_from'>
                                                                    <h6 className='don_account'>Already have an account? <a className='rea_btn_div' onClick={() => setVal(1)}>Login</a></h6>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        :
                                                        <div className='forgot_from'>
                                                            <div className='sign_boox_div'>
                                                                <div className='logni_form_div'>
                                                                    <img src='https://chawkbazar.vercel.app/assets/images/logo.svg' alt='images' />
                                                                    <h6 className='login_text'>We'll send you a link to reset your password</h6>
                                                                </div>

                                                                <div className='mt-3'>
                                                                    <form>
                                                                        <div className="form-group">
                                                                            <label for="exampleInputEmail1" className='example_email'>Email</label>
                                                                            <input type="email" className="form-control control_form" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="Enter email" />
                                                                        </div>
                                                                        <button type="submit" className="btn_login">Register</button>
                                                                    </form>
                                                                </div>

                                                                <div className='main_div_login'>
                                                                    <div className='line_div_login'></div>
                                                                    <div className='m-1'>Or</div>
                                                                    <div className='line_div_login'></div>
                                                                </div>

                                                                <div className='login_width_from'>
                                                                    <h6 className='don_account'>Back To <a className='rea_btn_div' onClick={() => setVal(1)}>Login</a></h6>
                                                                </div>
                                                            </div>
                                                        </div>
                                            }
                                        </Typography>
                                    </Box>
                                </Modal>
                            </div>
                        </div>
                    </div>

                </nav>
            </div>


            <input type="checkbox" class="toggle-Sidebar" id="toggle-Sidebar" />
            <div className="sidebar">
                <div>
                    <div className='sidebar_nav'>
                        <div>
                            <img src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Flogo.svg&w=96&q=75' alt='images' />
                        </div>
                        <div className='icon_toggle'>
                            <label for="toggle-Sidebar" className="toggle-icon">
                                <CloseIcon />
                            </label>
                        </div>
                    </div>
                    <hr className='sidebar_line m-0' />
                </div>
                
                <nav className="p-3 navbar-light">
                    <div className="">
                        <ul className="navbar-nav mr-auto">
                            <li className="nav-item dropdown">
                                <a className="nav-link link_nav" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <div className='d-flex justify-content-between align-items-center'>
                                        <div>
                                            Demos
                                        </div>
                                        <div>
                                            <KeyboardArrowDownIcon />
                                        </div>
                                    </div>
                                </a>
                                <div className="dropdown-menu menu_dropdown" aria-labelledby="navbarDropdown">
                                    <a className="dropdown-item" href="#">Action</a>
                                    <a className="dropdown-item" href="#">Another action</a>
                                    <a className="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link link_nav" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <div className='d-flex justify-content-between align-items-center'>
                                        <div>
                                            Men Wear
                                        </div>
                                        <div>
                                            <KeyboardArrowDownIcon />
                                        </div>
                                    </div>
                                </a>
                                <div className="dropdown-menu menu_dropdown" aria-labelledby="navbarDropdown">
                                    <Link className="dropdown-item" to="/tshirt">T-Shirt</Link>
                                    <a className="dropdown-item" href="#">Another action</a>
                                    <a className="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link link_nav" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <div className='d-flex justify-content-between align-items-center'>
                                        <div>
                                            Women Wear
                                        </div>
                                        <div>
                                            <KeyboardArrowDownIcon />
                                        </div>
                                    </div>
                                </a>
                                <div className="dropdown-menu menu_dropdown" aria-labelledby="navbarDropdown">
                                    <a className="dropdown-item" href="#">Action</a>
                                    <a className="dropdown-item" href="#">Another action</a>
                                    <a className="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link link_nav" to='/'>Search</Link>
                            </li>
                            <li className="nav-item">
                                <Link className="nav-link link_nav" to="/shops">Shops</Link>
                            </li>
                            <li className="nav-item dropdown">
                                <a className="nav-link link_nav" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <div className='d-flex justify-content-between align-items-center'>
                                        <div>
                                            Pages
                                        </div>
                                        <div>
                                            <KeyboardArrowDownIcon />
                                        </div>
                                    </div>
                                </a>
                                <div className="dropdown-menu menu_dropdown" aria-labelledby="navbarDropdown">
                                    <a className="dropdown-item" href="#">Action</a>
                                    <a className="dropdown-item" href="#">Another action</a>
                                    <a className="dropdown-item" href="#">Something else here</a>
                                </div>
                            </li>
                        </ul>

                    </div>
                </nav>

                <div className='sosiyal_nav_icons'>
                    <hr className='hr_line_icons m-0' />
                    <div className='p-3'>
                        <FacebookIcon fontSize="small" className='icons_div' />
                        <TwitterIcon className='mx-5 icons_div' fontSize="small" />
                        <YouTubeIcon className='mr-5 icons_div' fontSize="small" />
                        <InstagramIcon fontSize="small" className='icons_div' />
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Navbar