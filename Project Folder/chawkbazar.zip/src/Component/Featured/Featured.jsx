import React from 'react'
import './featured.css'
import Bags from './Bags'
import Jewellers from './Jewellers'
import Featuredmain from './Featuredmain'

const Featured = () => {
    return (
        <div className='featured'>
            <div className='container-fluid container_div'>
                <div className='row'>
                    <div className='col-md-12'>
                        <h2>Featured Categories</h2>
                    </div>
                </div>
                <div className='row row_bags_dib_main'>
                    <div className='col-md-12'>
                        <Bags />
                    </div>
                </div>
                <div className='row row_bags_dib_main'>
                    <div className='col-md-12'>
                        <Jewellers />
                    </div>
                </div>

                <div className='row row_featured_maindisv'>
                   <div className='col-md-12'>
                        <Featuredmain/>
                   </div>
                </div>
                <hr className='hr_line_featured_div' />
            </div>
        </div>
    )
}

export default Featured