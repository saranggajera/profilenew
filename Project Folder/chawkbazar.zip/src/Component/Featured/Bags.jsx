import React from 'react'

const Bags = () => {
    return (
        <div className='bags'>
            <div className='container-fluid'>
                <div className='row'>
                    <div className='col-lg-4 col-md-6 col-sm-12'>
                        <div className='bags_div_main'>
                            <h5>Bags</h5>
                            <div className='bagss_main_divv'>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fbags%2F1.png&w=256&q=75' alt='images' />
                                </div>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fbags%2F2.png&w=256&q=75' alt='images' />
                                </div>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fbags%2F3.png&w=256&q=75' alt='images' />
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-lg-4 col-md-6 col-sm-12'>
                        <div className='bags_div_main'>
                            <h5>Shoes</h5>
                            <div className='bagss_main_divv'>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fshoes%2F1.png&w=256&q=75' alt='images' />
                                </div>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fshoes%2F2.png&w=256&q=75' alt='images' />
                                </div>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fshoes%2F3.png&w=256&q=75' alt='images' />
                                </div>

                            </div>
                        </div>
                    </div>
                    <div className='col-lg-4 col-md-6 col-sm-12'>
                        <div className='bags_div_main'>
                            <h5>Wallets</h5>
                            <div className='bagss_main_divv'>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwallets%2F1.png&w=256&q=75' alt='images' />
                                </div>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwallets%2F2.png&w=256&q=75' alt='images' />
                                </div>

                                <div className='bagss_main_img'>
                                    <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwallets%2F3.png&w=256&q=75' alt='images' />
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Bags