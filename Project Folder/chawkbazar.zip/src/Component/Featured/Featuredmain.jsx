import React from 'react'
import Slider from "react-slick";
import Bags from './Bags';

const Featuredmain = () => {

    var settings = {
        dots: false,
        infinite: true,
        slidesToShow: 3,
        slidesToScroll: 1,
        // autoplay: true,
        // autoplaySpeed: 2000,
        pauseOnHover: true,
        responsive: [
            {
                breakpoint: 1024,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 717,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    initialSlide: 2
                }
            },
            {
                breakpoint: 480,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    }

    return (
        <div className='featuredmain' >
            <div className='container_div container-fluid'>
                <div className='row'>
                    <div className='col-md-12 mt-4 featu_main_div'>
                        <div>
                            <Slider {...settings}>
                                <div className='bags_diiv_main'>
                                    <h5 className='mt-1'>Bags</h5>
                                    <div className='bgs_div_img_main'>
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fbags%2F1.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fbags%2F2.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fbags%2F3.png&w=256&q=75' alt='images' />
                                    </div>
                                </div>
                                <div className='bags_diiv_main'>
                                    <h5 className='mt-1'>shoes</h5>
                                    <div className='bgs_div_img_main'>
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fshoes%2F1.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fshoes%2F2.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fshoes%2F3.png&w=256&q=75' alt='images' />
                                    </div>
                                </div>
                                <div className='bags_diiv_main'>
                                    <h5 className='mt-1'>Wallets</h5>
                                    <div className='bgs_div_img_main'>
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwallets%2F1.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwallets%2F2.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwallets%2F3.png&w=256&q=75' alt='images' />
                                    </div>
                                </div>
                                <div className='bags_diiv_main'>
                                    <h5 className='mt-1'>Jewellers</h5>
                                    <div className='bgs_div_img_main'>
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fjewellers%2F1.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fjewellers%2F2.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fjewellers%2F3.png&w=256&q=75' alt='images' />
                                    </div>
                                </div>
                                <div className='bags_diiv_main'>
                                    <h5 className='mt-1'>Watches</h5>
                                    <div className='bgs_div_img_main'>
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwatches%2F1.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwatches%2F2.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwatches%2F3.png&w=256&q=75' alt='images' />
                                    </div>
                                </div>
                                <div className='bags_diiv_main'>
                                <h5 className='mt-1'>Sun Glasses</h5>
                                    <div className='bgs_div_img_main'>
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fsun-glasses%2F1.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fsun-glasses%2F2.png&w=256&q=75' alt='images' />
                                        <img className='bags_img_slider' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fsun-glasses%2F3.png&w=256&q=75' alt='images' />
                                    </div>
                                </div>
                            </Slider>
                        </div>
                    </div>
                </div>
            </div>
        </div >
    )
}

export default Featuredmain