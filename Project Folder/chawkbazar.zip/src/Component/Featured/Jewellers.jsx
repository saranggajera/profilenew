import React from 'react'

const Jewellers = () => {
  return (
    <div className='jewellers'>
      <div className='container-fluid'>
        <div className='row'>

          <div className='col-md-4 col-sm-12'>
            <div className='jewellers_main_div'>
              <h5>Jewellers</h5>
              <div className='bagss_main_divv'>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fjewellers%2F1.png&w=256&q=75' alt='images' />
                </div>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fjewellers%2F2.png&w=256&q=75' alt='images' />
                </div>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fjewellers%2F3.png&w=256&q=75' alt='images' />
                </div>
              </div>
            </div>
          </div>

          <div className='col-md-4 col-sm-12'>
            <div className='jewellers_main_div'>
              <h5>Watches</h5>
              <div className='bagss_main_divv'>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwatches%2F1.png&w=256&q=75' alt='images' />
                </div>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwatches%2F2.png&w=256&q=75' alt='images' />
                </div>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fwatches%2F3.png&w=256&q=75' alt='images' />
                </div>
              </div>
            </div>
          </div>

          <div className='col-md-4 col-sm-12'>
            <div className='jewellers_main_div'>
              <h5>Sun Glasses</h5>
              <div className='bagss_main_divv'>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fsun-glasses%2F1.png&w=256&q=75' alt='images' />
                </div>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fsun-glasses%2F2.png&w=256&q=75' alt='images' />
                </div>
                <div className='bagss_main_img'>
                  <img className='bags_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcategory%2Ftwo%2Fsun-glasses%2F3.png&w=256&q=75' alt='images' />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Jewellers