import React from 'react'
import './guaranteed.css'
import { guaranteed } from '../Data'

const Guaranteed = () => {
    return (
        <div className='guaranteed'>
            <div className='container-fluid container_div'>
                <div className='row'>
                    {
                        guaranteed.map((eve, ind) => {
                            return (
                                <div key={ind} className='col-lg-3 col-md-6 col-sm-12 p-0'>
                                    <div className='guaranteed_main_div'>
                                        <img src={eve.imgaes} alt='images' />
                                        <h4 className='mt-3'>{eve.title}</h4>
                                        <p className='m-0'>{eve.text}</p>
                                    </div>
                                </div>
                            )
                        })
                    }
                </div>
            </div>
        </div>
    )
}

export default Guaranteed