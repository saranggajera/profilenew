import React from 'react'
import './getonselected.css'

const Getonselected = () => {
  return (
    <div className='getonselected'>
        <div className='container-fluid container_div'>
           <div className='row'>
              <div className='col-md-12'>
                   <img className='getonselected_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbanner%2Fgrid%2Fbanner-3.jpg&w=1920&q=100' alt='images'/>
              </div>
           </div>
        </div>
    </div>
  )
}

export default Getonselected