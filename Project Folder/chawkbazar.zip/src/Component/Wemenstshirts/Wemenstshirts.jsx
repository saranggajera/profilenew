import React from 'react'
import './wemenstshirts.css'
import Wemenstshirtsslider from './Wemenstshirtsslider'

const Wemenstshirts = () => {
  return (
    <div className='wemenstshirts'>
        <div className='container-fluid container_div'>
           <div className='row row_wemensts_div_main'>
               <div className='col-md-6 col-sm-12'>
                  <img className='wemenstshirts_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbanner%2Fgrid%2Fbanner-1.jpg&w=1080&q=100' alt='images'/>
               </div>
               <div className='col-md-6 col-sm-12'>
                  <img className='wemenstshirts_img_div' src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbanner%2Fgrid%2Fbanner-2.jpg&w=1080&q=100' alt='images'/>
               </div>
           </div>

           <div className='row'>
               <div className='col-md-12'>
                   <Wemenstshirtsslider/>
               </div>
           </div>
        </div>
    </div>
  )
}

export default Wemenstshirts