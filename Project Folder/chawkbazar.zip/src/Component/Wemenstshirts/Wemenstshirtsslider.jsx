import React from 'react'
import Slider from "react-slick";

const Wemenstshirtsslider = () => {

    var settings = {
        dots: true,
        infinite: true,
        slidesToShow: 2,
        slidesToScroll: 1,
        autoplay: true,
        autoplaySpeed: 2800,
        pauseOnHover: true,
        responsive: [
            {
                breakpoint: 766,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 1,
                    infinite: true,
                    dots: true
                }
            },
            {
                breakpoint: 600,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    initialSlide: 2
                }
            },
        ]
    };

    return (
        <div className='weme'>
            <div className='container_div container-fluid'>
                <div className='row'>
                    <div className='col-md-12'>
                        <div>
                            <Slider {...settings}>
                                <div className='weme_text_divs'>
                                    <img src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbanner%2Fgrid%2Fbanner-1.jpg&w=1080&q=100' alt='images' />
                                </div>
                                <div className='weme_text_divs'>
                                    <img src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbanner%2Fgrid%2Fbanner-2.jpg&w=1080&q=100' alt='images' />
                                </div>
                                <div className='weme_text_divs'>
                                    <img src='https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fbanner%2Fgrid%2Fbanner-3.jpg&w=1920&q=100' alt='images' />
                                </div>
                            </Slider>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Wemenstshirtsslider