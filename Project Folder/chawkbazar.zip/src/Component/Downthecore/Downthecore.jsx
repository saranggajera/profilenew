import React from 'react'
import './downthecore.css'

const Downthecore = () => {
    return (
        <div className='downthecore'>
            <div className='container-fluid container_div'>
                <div className='row'>
                    <div className='col-lg-4 col-md-6 col-sm-12 new_mainn'>
                        <div className='new_main_div newwinter_mai'>
                            <div class="new_img_main">
                                <img className='img_div_downthecore' src="https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcollection%2F1.jpg&w=640&q=75" alt='images' />
                                <button className='view_btn_colle'>View Collection</button>
                            </div>
                            <div className='new_text_div mt-3'>
                                <h2>New Spring Knits</h2>
                                <p className='m-0'>
                                    Endlessly versatile new styles that say yes to spring. The season’s looking bright.
                                </p>
                            </div>
                        </div>
                    </div>

                    <div className='col-lg-4 col-md-6 col-sm-12 new_mainn'>
                        <div className='down_main_div newwinter_mai'>
                            <div className='new_text_div mb-3'>
                                <h2>Down To The Core</h2>
                                <p className='m-0'>
                                    Endlessly versatile new styles that say yes to spring. The season’s looking bright.
                                </p>
                            </div>
                            <div class="new_img_main">
                                <img className='img_div_downthecore' src="https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcollection%2F2.jpg&w=640&q=75" alt='images' />
                                <button className='view_btn_colle'>View Collection</button>
                            </div>
                        </div>
                    </div>

                    <div className='col-lg-4 col-md-6 col-sm-12 new_mainn'>
                        <div className='newwinter_main_div newwinter_mai'>
                            <div class="new_img_main">
                                <img className='img_div_downthecore' src="https://chawkbazar.vercel.app/_next/image?url=%2Fassets%2Fimages%2Fcollection%2F3.jpg&w=640&q=75" alt='images' />
                                <button className='view_btn_colle'>View Collection</button>
                            </div>
                            <div className='new_text_div mt-3'>
                                <h2>New Winter Knits</h2>
                                <p className='m-0'>
                                    Endlessly versatile new styles that say yes to spring. The season’s looking bright.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Downthecore