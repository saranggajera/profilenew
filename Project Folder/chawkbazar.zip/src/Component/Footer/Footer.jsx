import React from 'react'
import './footer.css'
import InstagramIcon from '@mui/icons-material/Instagram';
import TwitterIcon from '@mui/icons-material/Twitter';
import FacebookIcon from '@mui/icons-material/Facebook';
import YouTubeIcon from '@mui/icons-material/YouTube';

const Footer = () => {

    const year = new Date().getFullYear();

    return (
        <div className='footer'>
            <div className='container-fluid container_div'>
                <div className='row'>

                    <div className='col-lg-2 col-md-4 col-sm-6 col-6'>
                        <div>
                            <h4 className='social_text_div'>Social</h4>
                            <div className='foote_text_div'>
                                <p><span><InstagramIcon /></span> Instagram</p>
                                <p><span><TwitterIcon /></span> Twitter</p>
                                <p><span><FacebookIcon /></span> Facebook</p>
                                <p><span><YouTubeIcon /></span> Youtube</p>
                            </div>
                        </div>
                    </div>

                    <div className='col-lg-2 col-md-4 col-sm-6 col-6'>
                        <div>
                            <h4 className='social_text_div'>Contact</h4>
                            <div className='foote_text_div'>
                                <p>Contact Us</p>
                                <p className='your_div_email'>yourexample@email.com</p>
                                <p className='your_div_email'>example@email.com</p>
                                <p>Call us: +1 254 568-5479</p>
                            </div>
                        </div>
                    </div>

                    <div className='col-lg-2 col-md-4 col-sm-6 col-6'>
                        <div>
                            <h4 className='social_text_div'>About</h4>
                            <div className='foote_text_div'>
                                <p>Support Center</p>
                                <p>Customer Support</p>
                                <p>About Us</p>
                                <p>Copyright</p>
                            </div>
                        </div>
                    </div>

                    <div className='col-lg-2 col-md-4 col-sm-6 col-6'>
                        <div>
                            <h4 className='social_text_div'>Customer Care</h4>
                            <div className='foote_text_div'>
                                <p>FAQ & Helps</p>
                                <p>Shipping & Delivery</p>
                                <p>Return & Exchanges</p>
                            </div>
                        </div>
                    </div>

                    <div className='col-lg-2 col-md-4 col-sm-6 col-6'>
                        <div>
                            <h4 className='social_text_div'>Our Information</h4>
                            <div className='foote_text_div'>
                                <p>Privacy policy update</p>
                                <p>Terms & conditions</p>
                                <p>Return Policy</p>
                                <p>Site Map</p>
                            </div>
                        </div>
                    </div>

                    <div className='col-lg-2 col-md-4 col-sm-6 col-6'>
                        <div>
                            <h4 className='social_text_div'>Top Categories</h4>
                            <div className='foote_text_div'>
                                <p>Men's Wear</p>
                                <p>Men's Wear</p>
                                <p>Kid's Wear</p>
                                <p>Sports Wear</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
            <hr className='hr_line_footer' />

            <div className='container-fluid container_div'>
                <div className='row'>
                    <div className='col-md-12'>
                        <div className='copyright_main_div'>
                            <div>
                                <p className='copyright_div_footer m-0'>
                                    Copyright © {year} <span className='readq_div_footer'>RedQ, Inc.</span>  All rights reserved
                                </p>
                            </div>
                            <div className='payments_div'>
                                <img src='https://chawkbazar.vercel.app/assets/images/payment/mastercard.svg' alt='images'/>
                                <img className='mx-4' src='https://chawkbazar.vercel.app/assets/images/payment/visa.svg' alt='images'/>
                                <img src='https://chawkbazar.vercel.app/assets/images/payment/paypal.svg' alt='images'/>
                                <img className='mx-4' src='https://chawkbazar.vercel.app/assets/images/payment/jcb.svg' alt='images'/>
                                <img src='https://chawkbazar.vercel.app/assets/images/payment/skrill.svg' alt='images'/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default Footer